# CarService (C++/Qt6) — збірка під Windows

Це C++ (Qt 6, Widgets) версія застосунку **Car Service Point G** з локальною SQLite БД, з повторенням ключового UI-патерну (ліва панель, вкладки/сторінки), схемою БД та базовим CRUD по нарядам.

> **Важливо:** це *порт* структури та основних алгоритмів (БД/логіка/звіт PDF). Якщо вам потрібно 1:1 перенести абсолютно всі екранні форми, звіти та специфічні фічі — це окремий великий етап, але цей проєкт дає правильний фундамент: Qt Widgets + SQLite + сторінки + сплеш.

## 1) Встановіть Qt 6

- Рекомендовано **Qt 6.6+** (MSVC 2022 x64).
- Потрібні модулі: **Qt Widgets, Qt SQL, Qt PrintSupport**.

## 2) Встановіть CMake

- CMake 3.21+.

## 3) Збірка (PowerShell)

```powershell
cd <папка_проєкту>

# 1) Налаштування
cmake -S . -B build -G "Ninja" -DCMAKE_BUILD_TYPE=Release `
  -DCMAKE_PREFIX_PATH="C:\Qt\6.6.2\msvc2019_64"

# 2) Збірка
cmake --build build --config Release

# 3) Запуск
.\build\CarService.exe
```

Якщо у вас немає Ninja — використайте генератор Visual Studio:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DCMAKE_PREFIX_PATH="C:\Qt\6.6.2\msvc2019_64"
cmake --build build --config Release
```

## 4) Де лежить база даних

Застосунок створює БД тут:
- `%APPDATA%\CarServicePointG\CarServicePointG.db`

Логи:
- `%APPDATA%\CarServicePointG\logs\app.log`

## 5) Функціонал

- Анімований **сплеш** (кадри `ring_001..ring_096`) та напис **CarService**.
- Схема БД: `masters`, `work_orders`, `work_order_services`, `service_masters`, `work_order_parts`, `outsource_repairs`, `parts_catalog`, `expenses`, `planning_calendar`.
- Сторінки: Планування, Поточні наряди, Історія, Запчастини, Звіти, Статистика, Налаштування.
- Діалог наряду: базові поля + табличні списки робіт/запчастин.
- Експорт простого PDF звіту по періоду.

