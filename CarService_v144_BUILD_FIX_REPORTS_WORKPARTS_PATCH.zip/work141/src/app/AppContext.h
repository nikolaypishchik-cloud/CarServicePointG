#pragma once
#include <memory>

class Settings;
class Database;

// Simple DI/context holder (expand as you modularize).
class AppContext {
public:
    static AppContext& instance();

    // TODO: replace with real owned services as you extract modules.
private:
    AppContext() = default;
};
