#include "app/App.h"

#include <QCoreApplication>
#include <QDir>
#include <QDateTime>
#include <QFile>
#include <QFileInfo>
#include <QMutex>
#include <QMutexLocker>

#include <QStandardPaths>
#include <QtGlobal>
#include <cstdio>

static QFile* g_logFile = nullptr;
static QMutex g_logMutex;
static int g_logLinesSinceFlush = 0;
static const qint64 kMaxLogBytes = 5 * 1024 * 1024; // 5MB
static const int kMaxRotatedLogs = 5;



static void rotateLogsIfNeeded()
{
    if (!g_logFile) return;
    QFileInfo fi(*g_logFile);
    if (!fi.exists()) return;
    if (fi.size() < kMaxLogBytes) return;

    g_logFile->flush();
    g_logFile->close();

    const QString base = App::logFilePath();
    const QString ts = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");
    const QString rotated = base + "." + ts + ".log";
    QFile::rename(base, rotated);

    // Cleanup old rotations
    QDir dir(QFileInfo(base).absolutePath());
    const QString pattern = QFileInfo(base).fileName() + ".*.log";
    QStringList files = dir.entryList(QStringList() << pattern, QDir::Files, QDir::Time); // newest first
    for (int i = kMaxRotatedLogs; i < files.size(); ++i) {
        dir.remove(files.at(i));
    }

    g_logFile->setFileName(base);
    const bool opened = g_logFile->open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text);
    if (!opened) {
        // If we can't open the log file, leave it closed; messageHandler will fallback to stderr.
        return;
    }
    g_logLinesSinceFlush = 0;
}

static void messageHandler(QtMsgType type, const QMessageLogContext& ctx, const QString& msg)
{
    Q_UNUSED(ctx);

    QString level;
    switch (type) {
    case QtDebugMsg: level = "DEBUG"; break;
    case QtInfoMsg: level = "INFO"; break;
    case QtWarningMsg: level = "WARN"; break;
    case QtCriticalMsg: level = "ERROR"; break;
    case QtFatalMsg: level = "FATAL"; break;
    }

    const QString line = QString("%1 [%2] %3\n")
            .arg(QDateTime::currentDateTime().toString(Qt::ISODateWithMs))
            .arg(level)
            .arg(msg);

    {
        QMutexLocker locker(&g_logMutex);
        if (g_logFile && g_logFile->isOpen()) {
            rotateLogsIfNeeded();
            g_logFile->write(line.toUtf8());

            // Flush policy:
            // - always flush WARN/ERROR/FATAL
            // - otherwise flush every N lines to reduce IO pressure
            ++g_logLinesSinceFlush;
            const bool important = (type == QtWarningMsg || type == QtCriticalMsg || type == QtFatalMsg);
            if (important || g_logLinesSinceFlush >= 50) {
                g_logFile->flush();
                g_logLinesSinceFlush = 0;
            }
        }
    }

    // Also print to stderr ONLY when explicitly requested.
    // PowerShell tends to treat stderr output from native apps as an error record.
    // Enable by setting environment variable: CS_LOG_STDERR=1
    const QByteArray env = qgetenv("CS_LOG_STDERR");
    if (!env.isEmpty() && env != "0") {
        fprintf(stderr, "%s", line.toUtf8().constData());
    }

    if (type == QtFatalMsg) {
        abort();
    }
}

QString App::appName() { return QStringLiteral("CarServicePointG"); }
QString App::orgName() { return QStringLiteral("CarServicePointG"); }

QString App::dataDir()
{
    // Prefer Roaming AppData on Windows. Qt maps AppDataLocation accordingly.
    QString base = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (base.isEmpty()) {
        base = QDir::homePath() + QLatin1String("/.carservicepointg");
    }

    // Make path stable and without spaces at tail
    QDir d(base);
    d.mkpath(".");
    return d.absolutePath();
}

QString App::logsDir()
{
    QDir d(dataDir());
    d.mkpath("logs");
    d.cd("logs");
    return d.absolutePath();
}

QString App::logFilePath()
{
    return QDir(logsDir()).filePath("app.log");
}

QString App::dbFilePath()
{
    QDir d(dataDir());
    return d.filePath("CarServicePointG.db");
}

void App::installLogHandler()
{
    // Create/open log
    {
        QMutexLocker locker(&g_logMutex);
        if (!g_logFile) {
            g_logFile = new QFile(logFilePath());
        }
        if (!g_logFile->isOpen()) {
            const bool opened = g_logFile->open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text);
    if (!opened) {
        // If we can't open the log file, leave it closed; messageHandler will fallback to stderr.
        return;
    }
        }
        rotateLogsIfNeeded();
    }

    qInstallMessageHandler(messageHandler);
    qInfo() << "Logging started:" << logFilePath();
    qInfo() << "Data dir:" << dataDir();
}
