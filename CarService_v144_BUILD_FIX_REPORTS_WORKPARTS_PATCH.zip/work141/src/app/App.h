#pragma once

#include <QString>

class App
{
public:
    static QString appName();
    static QString orgName();

    // %APPDATA%/CarServicePointG (Windows) / writable location cross-platform
    static QString dataDir();
    static QString logsDir();
    static QString logFilePath();
    static QString dbFilePath();

    static void installLogHandler();
};
