#pragma once

#include <QObject>
#include <QElapsedTimer>

class ClickSoundFilter : public QObject
{
    Q_OBJECT
public:
    explicit ClickSoundFilter(QObject* parent = nullptr);

    // Call this when settings change (optional). If never called, the filter will refresh periodically.
    void reload();

protected:
    bool eventFilter(QObject* watched, QEvent* event) override;

private:
    bool m_enabled = true;
    QElapsedTimer m_lastRead;
};
