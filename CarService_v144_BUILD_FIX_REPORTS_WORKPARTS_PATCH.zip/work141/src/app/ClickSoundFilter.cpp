#include "app/ClickSoundFilter.h"

#include "infrastructure/db/sqlite/Db.h"

#include <QEvent>
#include <QApplication>
#include <QAbstractButton>
#include <QMouseEvent>
#include <QKeyEvent>

ClickSoundFilter::ClickSoundFilter(QObject* parent)
    : QObject(parent)
{
    m_lastRead.start();
    reload();
}

void ClickSoundFilter::reload()
{
    // Read once from DB (not on every click).
    m_enabled = Database::getSetting("settings.sounds.enabled", true).toBool();
    m_lastRead.restart();
}

bool ClickSoundFilter::eventFilter(QObject* watched, QEvent* event)
{
    Q_UNUSED(watched);

    if (!m_lastRead.isValid() || m_lastRead.elapsed() > 2000) {
        reload();
    }
    if (!m_enabled) return QObject::eventFilter(watched, event);

    // Mouse click on any QAbstractButton (QPushButton, QToolButton, etc.)
    if (event->type() == QEvent::MouseButtonRelease) {
        auto* me = static_cast<QMouseEvent*>(event);
        if (me->button() == Qt::LeftButton) {
            auto* btn = qobject_cast<QAbstractButton*>(watched);
            if (btn && btn->isEnabled() && btn->isVisible()) {
                if (!btn->property("no_click_sound").toBool()) {
                    QApplication::beep();
                }
            }
        }
    }

    // Keyboard activation (Space / Enter)
    if (event->type() == QEvent::KeyRelease) {
        auto* ke = static_cast<QKeyEvent*>(event);
        if (ke->key() == Qt::Key_Space || ke->key() == Qt::Key_Return || ke->key() == Qt::Key_Enter) {
            auto* btn = qobject_cast<QAbstractButton*>(watched);
            if (btn && btn->isEnabled() && btn->isVisible()) {
                if (!btn->property("no_click_sound").toBool()) {
                    QApplication::beep();
                }
            }
        }
    }

    return QObject::eventFilter(watched, event);
}
