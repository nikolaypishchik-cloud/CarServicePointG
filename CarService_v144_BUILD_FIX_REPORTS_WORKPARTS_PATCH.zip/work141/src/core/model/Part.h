#pragma once
#include <QString>

struct Part {
    int id = 0;
    QString name;
    QString sku;
    double price = 0.0;
};
