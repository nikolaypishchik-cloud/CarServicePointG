#pragma once
#include <QString>
#include <QDateTime>

struct Order {
    int id = 0;
    QString clientName;
    QString plate;
    QDateTime createdAt;
};
