#include "core/util/FormatUtils.h"

#include <QtMath>
#include <QStringList>

static QString groupThousands(const QString& digits)
{
    QString out;
    out.reserve(digits.size() + digits.size() / 3);

    int n = digits.size();
    for (int i = 0; i < n; ++i) {
        out.append(digits[i]);
        int left = n - i - 1;
        if (left > 0 && (left % 3) == 0) {
            out.append(' ');
        }
    }
    return out;
}

QString FormatUtils::formatNumberSpaces(double value, int maxDecimals)
{
    if (!qIsFinite(value)) return QStringLiteral("0");

    const bool neg = value < 0;
    double abs = qAbs(value);

    // Render with fixed maxDecimals, then trim trailing zeros.
    QString s = QString::number(abs, 'f', qMax(0, maxDecimals));
    int dot = s.indexOf('.');
    QString intPart = (dot >= 0) ? s.left(dot) : s;
    QString fracPart = (dot >= 0) ? s.mid(dot + 1) : QString();

    // Trim trailing zeros in frac
    while (!fracPart.isEmpty() && fracPart.endsWith('0')) fracPart.chop(1);

    QString grouped = groupThousands(intPart);
    QString out = grouped;
    if (!fracPart.isEmpty()) {
        out += '.' + fracPart;
    }
    if (neg) out.prepend('-');
    return out;
}

QString FormatUtils::money(double value, int maxDecimals)
{
    // In the python app most sums are displayed as integers (грн), but keep optional decimals.
    return formatNumberSpaces(value, maxDecimals);
}

QString FormatUtils::smartQty(double qty, int maxDecimals)
{
    // Display integer quantities without decimals; keep fractional when needed.
    const double q = qty;
    if (!qIsFinite(q)) return QStringLiteral("0");
    const double r = qRound64(q);
    if (qFabs(q - r) < 1e-9) {
        return QString::number((qint64)r);
    }
    return formatNumberSpaces(q, maxDecimals);
}


static double _clamp(double v, double lo, double hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

double FormatUtils::inferDiscountPercent(double discountRaw, double worksSum)
{
    const double d = double(discountRaw);
    const double w = double(worksSum);
    if (d <= 0.0) return 0.0;

    // Likely percent in normal business range
    if (d <= 30.0) return _clamp(d, 0.0, 100.0);

    // Ambiguous 31..100: could be percent OR old UAH.
    if (d <= 100.0) {
        // If works are big enough, a 31..100 UAH discount is common, while 31..100% is rare.
        if (w >= 500.0 && d < (w * 0.30)) {
            return _clamp((w > 0.0) ? (d / w) * 100.0 : 0.0, 0.0, 100.0);
        }
        return _clamp(d, 0.0, 100.0);
    }

    // >100 is almost certainly old UAH
    return _clamp((w > 0.0) ? (d / w) * 100.0 : 0.0, 0.0, 100.0);
}

