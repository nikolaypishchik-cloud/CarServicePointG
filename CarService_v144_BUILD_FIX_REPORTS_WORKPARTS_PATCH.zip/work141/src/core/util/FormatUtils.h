#pragma once

#include <QString>

namespace FormatUtils {
    QString formatNumberSpaces(double value, int maxDecimals = 2);
    QString money(double value, int maxDecimals = 0);
    QString smartQty(double qty, int maxDecimals = 2);
    double inferDiscountPercent(double discountRaw, double worksSum);
}
