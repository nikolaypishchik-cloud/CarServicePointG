#pragma once

#include <QSqlDatabase>
#include <QString>
#include <QVariant>
#include <QList>
#include <QMap>

struct MasterRow {
    QString id;
    QString name;
    QString role;   // master/admin
    double adminPercent = 0.0;
    bool active = true;
};

class Database
{
public:
    static bool open();
    static void close();
    static QSqlDatabase db();

    static bool ensureSchema();

    // Masters
    static QList<MasterRow> masters(bool onlyActive = true);
    static bool upsertMaster(const MasterRow& m);

    static bool setMasterActive(const QString& id, bool active);
    static bool deleteMasterIfUnusedOrArchive(const QString& id);

    // Payroll percents per master (stored in settings JSON)
    static QMap<QString, double> payrollPercents();
    static bool setPayrollPercent(const QString& masterId, double percent);
    static bool removePayrollPercent(const QString& masterId);

    // Summary for unpaid parts (qty, sum client amount)
    static bool unpaidPartsSummary(double& qtyOut, double& sumOut);
    static bool setPartPaid(int partId, bool paid);

    // Simple key-value settings (stored in DB)
    static QVariant getSetting(const QString& key, const QVariant& def = QVariant());
    static bool setSetting(const QString& key, const QVariant& value);

private:
    static bool ensureColumn(const QString& table, const QString& colName, const QString& ddl);
    static bool tableExists(const QString& table);
};
