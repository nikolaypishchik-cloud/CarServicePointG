#include "infrastructure/db/sqlite/Db.h"
#include "app/App.h"

#include <QSqlError>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QFile>
#include <QDir>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>

static const char* kConnName = "carservice_main";

QSqlDatabase Database::db()
{
    return QSqlDatabase::database(kConnName);
}

bool Database::open()
{
    if (QSqlDatabase::contains(kConnName)) {
        auto d = QSqlDatabase::database(kConnName);
        if (d.isOpen()) {
            return true;
        }
    }

    QSqlDatabase d = QSqlDatabase::addDatabase("QSQLITE", kConnName);
    d.setDatabaseName(App::dbFilePath());
    if (!d.open()) {
        qCritical() << "DB open failed:" << d.lastError().text();
        return false;
    }

    // Foreign keys
    {
        QSqlQuery q(d);
        q.exec("PRAGMA foreign_keys = ON;");
    }

    return ensureSchema();
}

void Database::close()
{
    if (!QSqlDatabase::contains(kConnName)) return;

    // IMPORTANT (Qt SQL): removeDatabase() must be called only when no QSqlDatabase/QSqlQuery objects
    // that reference this connection are alive.
    {
        QSqlDatabase d = QSqlDatabase::database(kConnName);
        if (d.isOpen()) d.close();
    } // d destroyed here

    QSqlDatabase::removeDatabase(kConnName);
}

bool Database::tableExists(const QString& table)
{
    QSqlQuery q(db());
    q.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?");
    q.addBindValue(table);
    if (!q.exec()) {
        qWarning() << "tableExists query failed:" << q.lastError().text();
        return false;
    }
    return q.next();
}

bool Database::ensureColumn(const QString& table, const QString& colName, const QString& ddl)
{
    if (!tableExists(table)) return true;

    QSqlQuery q(db());
    if (!q.exec(QString("PRAGMA table_info(%1)").arg(table))) {
        qWarning() << "PRAGMA table_info failed" << table << q.lastError().text();
        return false;
    }
    bool has = false;
    while (q.next()) {
        if (q.value(1).toString() == colName) { has = true; break; }
    }
    if (has) return true;

    QSqlQuery a(db());
    const QString sql = QString("ALTER TABLE %1 ADD COLUMN %2;").arg(table, ddl);
    if (!a.exec(sql)) {
        qWarning() << "ALTER TABLE failed" << sql << a.lastError().text();
        return false;
    }
    return true;
}

bool Database::ensureSchema()
{
    QSqlDatabase d = db();
    QSqlQuery q(d);

    // masters
    if (!q.exec(
            "CREATE TABLE IF NOT EXISTS masters ("
            "  id TEXT PRIMARY KEY,"
            "  name TEXT NOT NULL,"
            "  role TEXT NOT NULL DEFAULT 'master',"
            "  admin_percent REAL NOT NULL DEFAULT 0,"
            "  active INTEGER NOT NULL DEFAULT 1"
            ");")) {
        qCritical() << "Create masters failed" << q.lastError().text();
        return false;
    }

    // work_orders
    if (!q.exec(
            "CREATE TABLE IF NOT EXISTS work_orders ("
            "  number INTEGER PRIMARY KEY,"
            "  opened_at TEXT NOT NULL,"
            "  closed_at TEXT,"
            "  status TEXT NOT NULL,"
            "  plate TEXT NOT NULL,"
            "  plate_norm TEXT NOT NULL,"
            "  vin TEXT NOT NULL DEFAULT '',"
            "  car_year INTEGER NOT NULL DEFAULT 0,"
            "  odometer INTEGER NOT NULL DEFAULT 0,"
            "  engine_type TEXT NOT NULL DEFAULT '',"
            "  engine_volume TEXT NOT NULL DEFAULT '',"
            "  fuel_type TEXT NOT NULL DEFAULT '',"
            "  car TEXT NOT NULL,"
            "  client TEXT NOT NULL,"
            "  client_phone TEXT NOT NULL DEFAULT '',"
            "  master_id TEXT NOT NULL,"
            "  works_sum REAL NOT NULL DEFAULT 0,"
            "  parts_sum REAL NOT NULL DEFAULT 0,"
            "  discount REAL NOT NULL DEFAULT 0,"
            "  master_name_closed TEXT NOT NULL DEFAULT '',"
            "  FOREIGN KEY(master_id) REFERENCES masters(id)"
            ");")) {
        qCritical() << "Create work_orders failed" << q.lastError().text();
        return false;
    }

    // services
    if (!q.exec(
            "CREATE TABLE IF NOT EXISTS work_order_services ("
            "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "  order_number INTEGER NOT NULL,"
            "  title TEXT NOT NULL,"
            "  qty REAL NOT NULL DEFAULT 1,"
            "  price REAL NOT NULL DEFAULT 0,"
            "  amount REAL NOT NULL DEFAULT 0,"
            "  FOREIGN KEY(order_number) REFERENCES work_orders(number) ON DELETE CASCADE"
            ");")) {
        qCritical() << "Create work_order_services failed" << q.lastError().text();
        return false;
    }

    // service_masters
    if (!q.exec(
            "CREATE TABLE IF NOT EXISTS service_masters ("
            "  service_id INTEGER NOT NULL,"
            "  master_id TEXT NOT NULL,"
            "  share_percent REAL NOT NULL DEFAULT 100,"
            "  role TEXT NOT NULL DEFAULT 'master',"
            "  master_name_closed TEXT NOT NULL DEFAULT '',"
            "  PRIMARY KEY(service_id, master_id),"
            "  FOREIGN KEY(service_id) REFERENCES work_order_services(id) ON DELETE CASCADE,"
            "  FOREIGN KEY(master_id) REFERENCES masters(id)"
            ");")) {
        qCritical() << "Create service_masters failed" << q.lastError().text();
        return false;
    }


// Backfill service_masters for legacy rows (fallback to work_orders.master_id)
// This enables multi-master payroll/reporting even for older orders that were saved before service-level assignment existed.
if (!q.exec(
        "INSERT OR IGNORE INTO service_masters(service_id, master_id, share_percent, role, master_name_closed) "
        "SELECT s.id, wo.master_id, 100.0, 'master', COALESCE(wo.master_name_closed, m.name, '') "
        "FROM work_order_services s "
        "JOIN work_orders wo ON wo.number = s.order_number "
        "LEFT JOIN masters m ON m.id = wo.master_id "
        "WHERE wo.master_id IS NOT NULL AND wo.master_id <> '' "
        "AND NOT EXISTS (SELECT 1 FROM service_masters sm WHERE sm.service_id = s.id)"
        ";")) {
    qWarning() << "Backfill service_masters failed" << q.lastError().text();
    // non-fatal
}

    // parts
    if (!q.exec(
            "CREATE TABLE IF NOT EXISTS work_order_parts ("
            "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "  order_number INTEGER NOT NULL,"
            "  ordered_at TEXT NOT NULL DEFAULT '',"
            "  store TEXT NOT NULL DEFAULT '',"
            "  part_number TEXT,"
            "  name TEXT NOT NULL,"
            "  note TEXT NOT NULL DEFAULT '',"
            "  qty REAL NOT NULL DEFAULT 1,"
            "  price REAL NOT NULL DEFAULT 0,"
            "  amount REAL NOT NULL DEFAULT 0,"
            "  service_id INTEGER NOT NULL DEFAULT 0,"
            "  ordered_by_admin INTEGER NOT NULL DEFAULT 1,"
            "  paid INTEGER NOT NULL DEFAULT 0,"
            "  FOREIGN KEY(order_number) REFERENCES work_orders(number) ON DELETE CASCADE"
            ");")) {
        qCritical() << "Create work_order_parts failed" << q.lastError().text();
        return false;
    }

    // backfill/migrate: paid column (older DBs)
    ensureColumn("work_order_parts", "paid", "paid INTEGER NOT NULL DEFAULT 0");
    ensureColumn("work_order_parts", "part_number", "part_number TEXT");
    ensureColumn("work_order_parts", "purchase_price", "purchase_price REAL NOT NULL DEFAULT 0");
    ensureColumn("work_order_parts", "purchase_amount", "purchase_amount REAL NOT NULL DEFAULT 0");
    ensureColumn("work_order_parts", "markup_percent", "markup_percent REAL NOT NULL DEFAULT 0");

    // Backfill purchase/client fields for older DBs.
    q.exec("UPDATE work_order_parts SET purchase_price = CASE WHEN purchase_price <= 0 THEN price ELSE purchase_price END WHERE purchase_price <= 0");
    q.exec("UPDATE work_order_parts SET purchase_amount = CASE WHEN purchase_amount <= 0 THEN amount ELSE purchase_amount END WHERE purchase_amount <= 0");

    // outsource
    if (!q.exec(
            "CREATE TABLE IF NOT EXISTS outsource_repairs ("
            "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "  order_number INTEGER NOT NULL,"
            "  sent_at TEXT NOT NULL DEFAULT '',"
            "  company TEXT NOT NULL DEFAULT '',"
            "  part_name TEXT NOT NULL DEFAULT '',"
            "  repair_cost REAL NOT NULL DEFAULT 0,"
            "  client_price REAL NOT NULL DEFAULT 0,"
            "  note TEXT NOT NULL DEFAULT '',"
            "  created_at TEXT NOT NULL DEFAULT (datetime('now')),"
            "  FOREIGN KEY(order_number) REFERENCES work_orders(number) ON DELETE CASCADE"
            ");")) {
        qCritical() << "Create outsource_repairs failed" << q.lastError().text();
        return false;
    }

    // catalog
    if (!q.exec(
            "CREATE TABLE IF NOT EXISTS parts_catalog ("
            "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "  part_number TEXT NOT NULL,"
            "  name TEXT NOT NULL,"
            "  brand TEXT NOT NULL DEFAULT '',"
            "  price REAL NOT NULL DEFAULT 0"
            ");")) {
        qCritical() << "Create parts_catalog failed" << q.lastError().text();
        return false;
    }

    // expenses
    if (!q.exec(
            "CREATE TABLE IF NOT EXISTS expenses ("
            "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "  period_from TEXT NOT NULL,"
            "  period_to TEXT NOT NULL,"
            "  elec_prev REAL NOT NULL DEFAULT 0,"
            "  elec_curr REAL NOT NULL DEFAULT 0,"
            "  elec_tariff REAL NOT NULL DEFAULT 0,"
            "  cleaning REAL NOT NULL DEFAULT 0,"
            "  heating REAL NOT NULL DEFAULT 0,"
            "  rent REAL NOT NULL DEFAULT 0,"
            "  amortization REAL NOT NULL DEFAULT 0,"
            "  sw_opendatabot REAL NOT NULL DEFAULT 0,"
            "  sw_tecalliance REAL NOT NULL DEFAULT 0,"
            "  created_at TEXT NOT NULL DEFAULT (datetime('now'))"
            ");")) {
        qCritical() << "Create expenses failed" << q.lastError().text();
        return false;
    }

    
// settings (key-value)
if (!q.exec(
        "CREATE TABLE IF NOT EXISTS settings ("
        "  key TEXT PRIMARY KEY,"
        "  value TEXT NOT NULL DEFAULT ''"
        ");")) {
    qCritical() << "Create settings failed" << q.lastError().text();
    return false;
}

// deleted_imports (to remember removed external rows and never import again)
if (!q.exec(
        "CREATE TABLE IF NOT EXISTS deleted_imports ("
        "  source TEXT NOT NULL,"
        "  external_id TEXT NOT NULL,"
        "  deleted_at TEXT NOT NULL DEFAULT (datetime('now')),"
        "  PRIMARY KEY(source, external_id)"
        ");")) {
    qCritical() << "Create deleted_imports failed" << q.lastError().text();
    return false;
}

// planning_calendar
    if (!q.exec(
            "CREATE TABLE IF NOT EXISTS planning_calendar ("
            "  day TEXT PRIMARY KEY,"
            "  note TEXT NOT NULL DEFAULT ''"
            ");")) {
        qCritical() << "Create planning_calendar failed" << q.lastError().text();
        return false;
    }

    // Ensure columns (migrations)
    ensureColumn("work_orders", "car_model", "car_model TEXT NOT NULL DEFAULT ''");
    ensureColumn("work_orders", "vin", "vin TEXT NOT NULL DEFAULT ''");
    ensureColumn("work_orders", "engine_type", "engine_type TEXT NOT NULL DEFAULT ''");
    ensureColumn("work_orders", "engine_volume", "engine_volume TEXT NOT NULL DEFAULT ''");
    ensureColumn("masters", "role", "role TEXT NOT NULL DEFAULT 'master'");
    ensureColumn("masters", "admin_percent", "admin_percent REAL NOT NULL DEFAULT 0");
    ensureColumn("masters", "active", "active INTEGER NOT NULL DEFAULT 1");
    ensureColumn("work_order_parts", "ordered_by_admin", "ordered_by_admin INTEGER NOT NULL DEFAULT 1");
    ensureColumn("work_orders", "master_name_closed", "master_name_closed TEXT NOT NULL DEFAULT ''");
    ensureColumn("service_masters", "master_name_closed", "master_name_closed TEXT NOT NULL DEFAULT ''");
    { QSqlQuery qfix(db()); qfix.exec("UPDATE service_masters SET role='master' WHERE role IS NULL OR TRIM(role)=''"); }

    // Seed at least one master for fresh DB
    {
        QSqlQuery m(d);
        m.exec("SELECT COUNT(*) FROM masters");
        if (m.next() && m.value(0).toInt() == 0) {
            QSqlQuery ins(d);
            ins.prepare("INSERT INTO masters(id, name, role, admin_percent, active) VALUES(?,?,?,?,?)");
            ins.addBindValue("m1");
            ins.addBindValue(QString::fromUtf8("Майстер 1"));
            ins.addBindValue("master");
            ins.addBindValue(0.0);
            ins.addBindValue(1);
            if (!ins.exec()) {
                qWarning() << "Seed master failed" << ins.lastError().text();
            }
        }
    }

    
// Indexes (best-effort). Note: LIKE '%term%' cannot fully use indexes, but these still help for exact/prefix filters and joins.
q.exec("CREATE INDEX IF NOT EXISTS idx_work_orders_status_opened ON work_orders(status, opened_at)");
q.exec("CREATE INDEX IF NOT EXISTS idx_work_orders_status_closed ON work_orders(status, closed_at)");
q.exec("CREATE INDEX IF NOT EXISTS idx_work_orders_plate_norm ON work_orders(plate_norm)");
q.exec("CREATE INDEX IF NOT EXISTS idx_work_orders_vin ON work_orders(vin)");
q.exec("CREATE INDEX IF NOT EXISTS idx_work_orders_client ON work_orders(client)");
q.exec("CREATE INDEX IF NOT EXISTS idx_work_orders_car ON work_orders(car)");

q.exec("CREATE INDEX IF NOT EXISTS idx_parts_order_number ON work_order_parts(order_number)");
q.exec("CREATE INDEX IF NOT EXISTS idx_parts_ordered_at ON work_order_parts(ordered_at)");
q.exec("CREATE INDEX IF NOT EXISTS idx_parts_store ON work_order_parts(store)");
q.exec("CREATE INDEX IF NOT EXISTS idx_parts_part_number ON work_order_parts(part_number)");
q.exec("CREATE INDEX IF NOT EXISTS idx_parts_name ON work_order_parts(name)");

// FTS5 (best-effort). If the SQLite build lacks FTS5, we'll continue without it.
auto tableExists = [&](const QString& name) -> bool {
    QSqlQuery tq(d);
    tq.prepare("SELECT 1 FROM sqlite_master WHERE type IN ('table','view') AND name=? LIMIT 1");
    tq.addBindValue(name);
    if (!tq.exec()) return false;
    return tq.next();
};

if (!tableExists("work_orders_fts")) {
    if (!q.exec("CREATE VIRTUAL TABLE work_orders_fts USING fts5("
                "plate, car, vin, client, "
                "content='work_orders', content_rowid='number' )")) {
        qWarning() << "FTS create failed (work_orders_fts):" << q.lastError().text();
    } else {
        // initial build
        q.exec("INSERT INTO work_orders_fts(work_orders_fts) VALUES('rebuild')");
        // triggers
        q.exec("CREATE TRIGGER work_orders_ai AFTER INSERT ON work_orders BEGIN "
               "  INSERT INTO work_orders_fts(rowid, plate, car, vin, client) "
               "  VALUES (new.number, new.plate, new.car, new.vin, new.client); "
               "END;");
        q.exec("CREATE TRIGGER work_orders_ad AFTER DELETE ON work_orders BEGIN "
               "  INSERT INTO work_orders_fts(work_orders_fts, rowid, plate, car, vin, client) "
               "  VALUES('delete', old.number, old.plate, old.car, old.vin, old.client); "
               "END;");
        q.exec("CREATE TRIGGER work_orders_au AFTER UPDATE ON work_orders BEGIN "
               "  INSERT INTO work_orders_fts(work_orders_fts, rowid, plate, car, vin, client) "
               "  VALUES('delete', old.number, old.plate, old.car, old.vin, old.client); "
               "  INSERT INTO work_orders_fts(rowid, plate, car, vin, client) "
               "  VALUES (new.number, new.plate, new.car, new.vin, new.client); "
               "END;");
    }
}

if (!tableExists("work_order_parts_fts")) {
    if (!q.exec("CREATE VIRTUAL TABLE work_order_parts_fts USING fts5("
                "name, part_number, store, "
                "content='work_order_parts', content_rowid='id' )")) {
        qWarning() << "FTS create failed (work_order_parts_fts):" << q.lastError().text();
    } else {
        q.exec("INSERT INTO work_order_parts_fts(work_order_parts_fts) VALUES('rebuild')");
        q.exec("CREATE TRIGGER work_order_parts_ai AFTER INSERT ON work_order_parts BEGIN "
               "  INSERT INTO work_order_parts_fts(rowid, name, part_number, store) "
               "  VALUES (new.id, new.name, new.part_number, new.store); "
               "END;");
        q.exec("CREATE TRIGGER work_order_parts_ad AFTER DELETE ON work_order_parts BEGIN "
               "  INSERT INTO work_order_parts_fts(work_order_parts_fts, rowid, name, part_number, store) "
               "  VALUES('delete', old.id, old.name, old.part_number, old.store); "
               "END;");
        q.exec("CREATE TRIGGER work_order_parts_au AFTER UPDATE ON work_order_parts BEGIN "
               "  INSERT INTO work_order_parts_fts(work_order_parts_fts, rowid, name, part_number, store) "
               "  VALUES('delete', old.id, old.name, old.part_number, old.store); "
               "  INSERT INTO work_order_parts_fts(rowid, name, part_number, store) "
               "  VALUES (new.id, new.name, new.part_number, new.store); "
               "END;");
    }
}

qInfo() << "DB schema OK";
    return true;
}

QList<MasterRow> Database::masters(bool onlyActive)
{
    QList<MasterRow> out;
    QSqlQuery q(db());
    QString sql = "SELECT id, name, role, admin_percent, active FROM masters";
    if (onlyActive) {
        sql += " WHERE active=1";
    }
    sql += " ORDER BY name COLLATE NOCASE";

    if (!q.exec(sql)) {
        qWarning() << "masters query failed" << q.lastError().text();
        return out;
    }

    while (q.next()) {
        MasterRow m;
        m.id = q.value(0).toString();
        m.name = q.value(1).toString();
        m.role = q.value(2).toString();
        m.adminPercent = q.value(3).toDouble();
        m.active = q.value(4).toInt() != 0;
        out.push_back(m);
    }
    return out;
}

bool Database::upsertMaster(const MasterRow& m)
{
    QSqlQuery q(db());
    q.prepare(
        "INSERT INTO masters(id, name, role, admin_percent, active) "
        "VALUES(?,?,?,?,?) "
        "ON CONFLICT(id) DO UPDATE SET "
        "name=excluded.name, role=excluded.role, admin_percent=excluded.admin_percent, active=excluded.active"
    );
    q.addBindValue(m.id);
    q.addBindValue(m.name);
    q.addBindValue(m.role);
    q.addBindValue(m.adminPercent);
    q.addBindValue(m.active ? 1 : 0);

    if (!q.exec()) {
        qWarning() << "upsertMaster failed" << q.lastError().text();
        return false;
    }
    return true;
}


bool Database::setMasterActive(const QString& id, bool active)
{
    QSqlQuery q(db());
    q.prepare("UPDATE masters SET active=? WHERE id=?");
    q.addBindValue(active ? 1 : 0);
    q.addBindValue(id);
    if (!q.exec()) {
        qWarning() << "setMasterActive failed" << q.lastError().text();
        return false;
    }
    return true;
}

bool Database::deleteMasterIfUnusedOrArchive(const QString& id)
{
    QSqlDatabase d = db();

    // Check references in work_orders
    int refs = 0;
    {
        QSqlQuery q(d);
        q.prepare("SELECT COUNT(*) FROM work_orders WHERE master_id=?");
        q.addBindValue(id);
        if (q.exec() && q.next()) refs += q.value(0).toInt();
    }
    // Check references in service_masters
    {
        QSqlQuery q(d);
        q.prepare("SELECT COUNT(*) FROM service_masters WHERE master_id=?");
        q.addBindValue(id);
        if (q.exec() && q.next()) refs += q.value(0).toInt();
    }

    if (refs > 0) {
        // Preserve data integrity: archive instead of hard delete
        return setMasterActive(id, false);
    }

    QSqlQuery del(d);
    del.prepare("DELETE FROM masters WHERE id=?");
    del.addBindValue(id);
    if (!del.exec()) {
        qWarning() << "deleteMaster failed" << del.lastError().text();
        return false;
    }

    // Also remove percent setting (if any)
    removePayrollPercent(id);
    return true;
}

static QString payrollPercentsKey() { return QStringLiteral("payroll_percents"); }

QMap<QString, double> Database::payrollPercents()
{
    QMap<QString, double> out;
    const QVariant v = getSetting(payrollPercentsKey(), QStringLiteral("{}"));
    const QString s = v.toString().trimmed();
    if (s.isEmpty()) return out;

    QJsonParseError pe;
    const QJsonDocument doc = QJsonDocument::fromJson(s.toUtf8(), &pe);
    if (pe.error != QJsonParseError::NoError || !doc.isObject()) {
        return out;
    }
    const QJsonObject obj = doc.object();
    for (auto it = obj.begin(); it != obj.end(); ++it) {
        out[it.key()] = it.value().toDouble(0.0);
    }
    return out;
}

static bool savePayrollPercents(const QMap<QString, double>& m)
{
    QJsonObject obj;
    for (auto it = m.begin(); it != m.end(); ++it) {
        obj.insert(it.key(), it.value());
    }
    const QJsonDocument doc(obj);
    return Database::setSetting(payrollPercentsKey(), QString::fromUtf8(doc.toJson(QJsonDocument::Compact)));
}

bool Database::setPayrollPercent(const QString& masterId, double percent)
{
    QMap<QString, double> m = payrollPercents();
    m[masterId] = percent;
    return savePayrollPercents(m);
}

bool Database::removePayrollPercent(const QString& masterId)
{
    QMap<QString, double> m = payrollPercents();
    if (!m.contains(masterId)) return true;
    m.remove(masterId);
    return savePayrollPercents(m);
}


bool Database::unpaidPartsSummary(double& qtyOut, double& sumOut)
{
    qtyOut = 0.0;
    sumOut = 0.0;

    QSqlQuery q(db());
    const QString sql =
        "SELECT COALESCE(SUM(p.qty),0), COALESCE(SUM(p.amount),0) "
        "FROM work_order_parts p "
        "WHERE COALESCE(p.paid,0)=0";

    if (!q.exec(sql)) {
        qWarning() << "unpaidPartsSummary failed" << q.lastError().text();
        return false;
    }
    if (q.next()) {
        qtyOut = q.value(0).toDouble();
        sumOut = q.value(1).toDouble();
        return true;
    }
    return false;
}

bool Database::setPartPaid(int partId, bool paid)
{
    QSqlQuery q(db());
    q.prepare("UPDATE work_order_parts SET paid=? WHERE id=?");
    q.addBindValue(paid ? 1 : 0);
    q.addBindValue(partId);
    if (!q.exec()) {
        qWarning() << "setPartPaid failed" << q.lastError().text();
        return false;
    }
    return true;
}


QVariant Database::getSetting(const QString& key, const QVariant& def)
{
    QSqlQuery q(Database::db());
    q.prepare("SELECT value FROM settings WHERE key=?");
    q.addBindValue(key);
    if (!q.exec()) {
        qWarning() << "getSetting failed:" << q.lastError().text();
        return def;
    }
    if (!q.next()) return def;
    return q.value(0);
}

bool Database::setSetting(const QString& key, const QVariant& value)
{
    QSqlQuery q(Database::db());
    q.prepare("INSERT INTO settings(key, value) VALUES(?, ?) "
              "ON CONFLICT(key) DO UPDATE SET value=excluded.value");
    q.addBindValue(key);
    q.addBindValue(value);
    if (!q.exec()) {
        qWarning() << "setSetting failed:" << q.lastError().text();
        return false;
    }
    return true;
}
