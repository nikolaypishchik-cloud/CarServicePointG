#include "app/App.h"
#include "app/ClickSoundFilter.h"
#include "infrastructure/db/sqlite/Db.h"
#include "ui/splash/SplashScreen.h"
#include "ui/main/MainWindow.h"
#include "ui/theme/ThemeManager.h"

#include <QApplication>
#include <QGuiApplication>
#include <QTimer>
#include <QScreen>

#include <exception>
#include <cstdlib>

static void ensureOnScreen(QWidget& w)
{
    // Make sure the window is not off-screen (multi-monitor / DPI edge cases).
    const QRect win = w.frameGeometry();
    QScreen* sc = QGuiApplication::primaryScreen();
    if (!sc) return;
    const QRect screen = sc->availableGeometry();
    if (!screen.intersects(win)) {
        w.resize(1200, 760);
        w.move(screen.center() - QPoint(w.width() / 2, w.height() / 2));
    }
}

int main(int argc, char *argv[])
{
    try {
        QApplication app(argc, argv);
        QApplication::setApplicationName(App::appName());
        QApplication::setOrganizationName(App::orgName());

        // Prevent a rare quit-between-splash-and-main race (no visible top-level widget moment).
        app.setQuitOnLastWindowClosed(false);

        App::installLogHandler();

        // If something terminates the process via std::terminate, write at least one line to app.log.

        qInfo() << "App starting...";

        QObject::connect(&app, &QCoreApplication::aboutToQuit, []() {
            qInfo() << "App aboutToQuit";
        });

        if (!Database::open()) {
            qCritical() << "DB open failed - exiting";
            return 1;
        }

        ThemeManager::applySavedTheme();

        ClickSoundFilter clickSoundFilter;
        app.installEventFilter(&clickSoundFilter);

        SplashScreen splash;
        MainWindow w;

        // Open directly in full screen.

        auto showMain = [&]() {
            if (!w.isVisible()) {
                qInfo() << "Showing MainWindow";
                w.showMaximized();
                w.raise();
                w.activateWindow();
                // Now allow normal quit behavior when the user closes the window.
                qApp->setQuitOnLastWindowClosed(true);
            }
        };

        QObject::connect(&splash, &SplashScreen::finished, &w, showMain);

        // Safety fallback: even if splash never emits (timer/resource issues), show main after 6s.
        QTimer::singleShot(6000, &w, showMain);

        splash.start(5200);

        return app.exec();
    } catch (const std::exception& e) {
        qCritical() << "Fatal std::exception:" << e.what();
        return 1;
    } catch (...) {
        qCritical() << "Fatal unknown exception.";
        return 1;
    }
}