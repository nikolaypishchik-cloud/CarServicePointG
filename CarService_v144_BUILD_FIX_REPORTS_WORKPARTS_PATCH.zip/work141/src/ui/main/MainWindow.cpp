#include "ui/main/MainWindow.h"

#include "infrastructure/db/sqlite/Db.h"
#include "ui/common/widgets/UnpaidBannerWidget.h"
#include "ui/common/widgets/GlossyButton.h"

#include "ui/tabs/schedule/PlanningPage.h"
#include "ui/tabs/orders/CurrentOrdersPage.h"
#include "ui/tabs/masters/MastersPage.h"
#include "ui/tabs/history/HistoryPage.h"
#include "ui/tabs/parts/PartsPage.h"
#include "ui/tabs/reports/ReportsPage.h"
#include "ui/tabs/statistics/StatsPage.h"
#include "ui/tabs/settings/SettingsPage.h"
#include "ui/common/dialogs/OrderDialog.h"
#include "core/util/FormatUtils.h"
#include "ui/theme/ThemeManager.h"

#include <QApplication>
#include <QIcon>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFrame>
#include <QLabel>
#include <QPushButton>
#include <QSpacerItem>
#include <QMessageBox>
#include <QGraphicsOpacityEffect>
#include <QPropertyAnimation>

static QPushButton* mkMenuButton(const QString& text, QButtonGroup* group, QWidget* parent, bool checked=false)
{
    auto* b = new QPushButton(text, parent);
    b->setCheckable(true);
    b->setChecked(checked);
    b->setMinimumHeight(36);
    b->setCursor(Qt::PointingHandCursor);
    group->addButton(b);
    return b;
}

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
{
    setWindowTitle(QString::fromUtf8("Car Service Point G — Windows (локальна база)"));
    setWindowIcon(QIcon(":/assets/app_icon.png"));

    buildUi();
    applyStyle();

    // banner updates
    m_bannerTimer.setInterval(2000);
    connect(&m_bannerTimer, &QTimer::timeout, this, &MainWindow::updateUnpaidBanner);
    m_bannerTimer.start();
    updateUnpaidBanner();

    refreshAll();
}

void MainWindow::buildUi()
{
    m_root = new QWidget(this);
    auto* rootL = new QHBoxLayout(m_root);
    rootL->setContentsMargins(0,0,0,0);
    rootL->setSpacing(0);

    // Sidebar
    m_sidebar = new QFrame(m_root);
    m_sidebar->setObjectName("sidebar");
    m_sidebar->setFixedWidth(255);
    auto* sbL = new QVBoxLayout(m_sidebar);
    sbL->setContentsMargins(14,14,14,14);
    sbL->setSpacing(10);

    m_banner = new UnpaidBannerWidget(m_sidebar);
    sbL->addWidget(m_banner);
    sbL->addSpacing(8);

    // Menu
    m_menu = new QButtonGroup(this);
    m_menu->setExclusive(true);

    auto* btnPlanning = mkMenuButton(QString::fromUtf8("Планування"), m_menu, m_sidebar);
    auto* btnNewOrder = new GlossyButton(QString::fromUtf8("Відкрити новий наряд"), m_sidebar);
    btnNewOrder->setObjectName("sb_btn_primary");

    auto* btnCurrent = mkMenuButton(QString::fromUtf8("Поточні наряди"), m_menu, m_sidebar, true);
    auto* btnParts   = mkMenuButton(QString::fromUtf8("Замовлення запчастин"), m_menu, m_sidebar);
    auto* btnHistory = mkMenuButton(QString::fromUtf8("База виконаних нарядів"), m_menu, m_sidebar);
    auto* btnReports = mkMenuButton(QString::fromUtf8("Звіти"), m_menu, m_sidebar);
    auto* btnStats   = mkMenuButton(QString::fromUtf8("Статистика"), m_menu, m_sidebar);
    auto* btnSettings= mkMenuButton(QString::fromUtf8("Налаштування"), m_menu, m_sidebar);

    sbL->addWidget(btnPlanning);
    sbL->addWidget(btnNewOrder);
    sbL->addWidget(btnCurrent);
    sbL->addWidget(btnParts);
    sbL->addWidget(btnHistory);
    sbL->addWidget(btnReports);
    sbL->addWidget(btnStats);
    sbL->addStretch(1);
    sbL->addWidget(btnSettings);

    // Content
    m_content = new QWidget(m_root);
    m_content->setObjectName("content");
    auto* cL = new QVBoxLayout(m_content);
    cL->setContentsMargins(14,14,14,14);
    cL->setSpacing(12);

    // Top header pill
    auto* top = new QFrame(m_content);
    top->setObjectName("top_pill");
    top->setFixedHeight(52);
    auto* topL = new QHBoxLayout(top);
    topL->setContentsMargins(18,10,18,10);
    topL->setSpacing(10);

    auto* title = new QLabel(QString::fromUtf8("Поточні наряди"), top);
    title->setObjectName("top_title");
    title->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    topL->addWidget(title);
    cL->addWidget(top);

    m_stack = new QStackedWidget(m_content);
    m_stack->setObjectName("pages");

    m_pagePlanning = new PlanningPage(m_stack);
    m_pageCurrent = new CurrentOrdersPage(m_stack);
    m_pageMasters = new MastersPage(m_stack);
    m_pageHistory = new HistoryPage(m_stack);
    m_pageParts = new PartsPage(m_stack);
    m_pageReports = new ReportsPage(m_stack);
    m_pageStats = new StatsPage(m_stack);
    m_pageSettings = new SettingsPage(m_stack);

    
m_stack->addWidget(m_pagePlanning); // 0
m_stack->addWidget(m_pageCurrent);  // 1
m_stack->addWidget(m_pageMasters);  // 2
m_stack->addWidget(m_pageHistory);  // 3
m_stack->addWidget(m_pageParts);    // 4
m_stack->addWidget(m_pageReports);  // 5
m_stack->addWidget(m_pageStats);    // 6
m_stack->addWidget(m_pageSettings); // 7

    m_stack->setCurrentIndex(1);
    cL->addWidget(m_stack, 1);

    rootL->addWidget(m_sidebar);
    rootL->addWidget(m_content, 1);

    setCentralWidget(m_root);

    // Navigation
    connect(btnPlanning, &QPushButton::clicked, this, [this, title]() { title->setText(QString::fromUtf8("Планування")); gotoPage(0); });
    connect(btnCurrent,  &QPushButton::clicked, this, [this, title]() { title->setText(QString::fromUtf8("Поточні наряди")); gotoPage(1); });
    connect(btnHistory,  &QPushButton::clicked, this, [this, title]() { title->setText(QString::fromUtf8("База виконаних нарядів")); gotoPage(3); });
    connect(btnParts,    &QPushButton::clicked, this, [this, title]() { title->setText(QString::fromUtf8("Замовлення запчастин")); gotoPage(4); });
    connect(btnReports,  &QPushButton::clicked, this, [this, title]() { title->setText(QString::fromUtf8("Звіти")); gotoPage(5); });
    connect(btnStats,    &QPushButton::clicked, this, [this, title]() { title->setText(QString::fromUtf8("Статистика")); gotoPage(6); });
    connect(btnSettings, &QPushButton::clicked, this, [this, title]() { title->setText(QString::fromUtf8("Налаштування")); gotoPage(7); });

    connect(btnNewOrder, &QPushButton::clicked, this, &MainWindow::openNewOrder);

    // Page refresh hooks
    connect(m_pageCurrent, &CurrentOrdersPage::requestRefreshAll, this, &MainWindow::refreshAll);
    connect(m_pageMasters, &MastersPage::requestRefreshAll, this, &MainWindow::refreshAll);
    connect(m_pageHistory, &HistoryPage::requestRefreshAll, this, &MainWindow::refreshAll);
    connect(m_pageParts, &PartsPage::requestRefreshAll, this, &MainWindow::refreshAll);
    connect(m_pageSettings, &SettingsPage::requestRefreshAll, this, &MainWindow::refreshAll);

}

void MainWindow::applyStyle()
{
    // Styling is controlled by Theme (DB setting: ui.theme).
    ThemeManager::applySavedTheme();
}

void MainWindow::gotoPage(int idx)
{
    if (!m_stack) return;
    
QWidget* w = m_stack->widget(idx);
const bool anim = Database::getSetting("settings.ui.animations", true).toBool();
const int dur = Database::getSetting("settings.ui.anim_duration_ms", 180).toInt();

if (anim && w) {
    // Fade-in animation for the target page.
    auto* eff = new QGraphicsOpacityEffect(w);
    w->setGraphicsEffect(eff);
    eff->setOpacity(0.0);

    m_stack->setCurrentIndex(idx);

    auto* a = new QPropertyAnimation(eff, "opacity", w);
    int duration = dur;
        if (duration < 80) duration = 80;
        if (duration > 1200) duration = 1200;
        a->setDuration(duration);
    a->setStartValue(0.0);
    a->setEndValue(1.0);
    connect(a, &QPropertyAnimation::finished, w, [w]() {
        // QWidget owns the graphics effect; setGraphicsEffect(nullptr) deletes it.
        w->setGraphicsEffect(nullptr);
    });
    a->start(QAbstractAnimation::DeleteWhenStopped);
} else {
    m_stack->setCurrentIndex(idx);
}

    // light refresh on navigation
    switch (idx) {
    case 1: m_pageCurrent->refresh(); break;
    case 2: m_pageHistory->refresh(); break;
    case 3: m_pageParts->refresh(); break;
    case 4: m_pageReports->refresh(); break;
    default: break;
    }

    updateUnpaidBanner();
}

void MainWindow::openNewOrder()
{
    OrderDialog dlg(this);
    dlg.setWindowTitle(QString::fromUtf8("Новий наряд"));
    if (dlg.exec() == QDialog::Accepted) {
        refreshAll();
    }
}

void MainWindow::refreshAll()
{
    if (m_pageCurrent) m_pageCurrent->refresh();
    if (m_pageMasters) m_pageMasters->refresh();
    if (m_pageHistory) m_pageHistory->refresh();
    if (m_pageParts) m_pageParts->refresh();
    if (m_pageReports) m_pageReports->refresh();
    updateUnpaidBanner();
}

void MainWindow::updateUnpaidBanner()
{
    double qty = 0.0, sum = 0.0;
    if (!Database::unpaidPartsSummary(qty, sum)) {
        m_banner->setDebt(false, QString(), QString());
        return;
    }

    const bool has = (qty > 0.0001 && sum > 0.0001);
    if (has) {
        m_banner->setDebt(true, FormatUtils::formatNumberSpaces(qty, 0), FormatUtils::money(sum, 0));
    } else {
        m_banner->setDebt(false, QString(), QString());
    }
}
