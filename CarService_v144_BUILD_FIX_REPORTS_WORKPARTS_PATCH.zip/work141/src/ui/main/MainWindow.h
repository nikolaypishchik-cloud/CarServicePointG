#pragma once

#include <QMainWindow>
#include <QButtonGroup>
#include <QStackedWidget>
#include <QTimer>

class UnpaidBannerWidget;
class PlanningPage;
class CurrentOrdersPage;
class HistoryPage;
class PartsPage;
class MastersPage;
class ReportsPage;
class StatsPage;
class SettingsPage;

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent=nullptr);

private slots:
    void gotoPage(int idx);
    void openNewOrder();
    void refreshAll();
    void updateUnpaidBanner();

private:
    void buildUi();
    void applyStyle();

    QWidget* m_root = nullptr;
    QWidget* m_sidebar = nullptr;
    QWidget* m_content = nullptr;

    QStackedWidget* m_stack = nullptr;

    QButtonGroup* m_menu = nullptr;

    UnpaidBannerWidget* m_banner = nullptr;

    PlanningPage* m_pagePlanning = nullptr;
    CurrentOrdersPage* m_pageCurrent = nullptr;
    HistoryPage* m_pageHistory = nullptr;
    PartsPage* m_pageParts = nullptr;
    MastersPage* m_pageMasters = nullptr;
    ReportsPage* m_pageReports = nullptr;
    StatsPage* m_pageStats = nullptr;
    SettingsPage* m_pageSettings = nullptr;

    QTimer m_bannerTimer;
};
