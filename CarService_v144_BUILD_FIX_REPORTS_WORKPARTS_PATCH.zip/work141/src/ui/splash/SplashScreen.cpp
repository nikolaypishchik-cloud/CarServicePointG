#include "ui/splash/SplashScreen.h"

#include <QApplication>
#include <QGuiApplication>
#include <QPainter>
#include <QPainterPath>
#include <QLinearGradient>
#include <QScreen>
#include <QtMath>

static inline double clamp01(double v) { return v < 0.0 ? 0.0 : (v > 1.0 ? 1.0 : v); }

SplashScreen::SplashScreen(QWidget* parent)
    : QWidget(parent)
{
    // Transparent overlay, like in the reference video: desktop is visible behind.
    setWindowFlags(Qt::Tool | Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
    setAttribute(Qt::WA_TranslucentBackground, true);
    setAttribute(Qt::WA_ShowWithoutActivating, true);
    setAttribute(Qt::WA_TransparentForMouseEvents, true);
    setFocusPolicy(Qt::NoFocus);

    loadFrames();

    m_tick.setInterval(16); // ~60 FPS
    connect(&m_tick, &QTimer::timeout, this, [this]() {
        const qint64 t = m_elapsed.isValid() ? m_elapsed.elapsed() : 0;
        if (t >= m_durationMs) {
            m_tick.stop();
            emit finished();
            QTimer::singleShot(0, this, [this]() { this->hide(); });
            return;
        }
        update();
    });
}

void SplashScreen::loadFrames()
{
    // ring_001..ring_096 in resources
    m_frames.clear();
    for (int i = 1; i <= 96; ++i) {
        const QString path = QString(":/assets/splash_ring_frames/alpha/ring_%1.png").arg(i, 3, 10, QLatin1Char('0'));
        QPixmap px(path);
        if (!px.isNull()) {
            m_frames.push_back(px);
        }
    }
}

void SplashScreen::start(int durationMs)
{
    m_durationMs = durationMs;
    // Per the reference: the splash title must be fixed.
    m_title = QStringLiteral("CarServicePointG");

    // Ensure frames are loaded even if the ctor ran before resources were ready.
    if (m_frames.isEmpty()) {
        loadFrames();
    }

    // Fullscreen transparent overlay (so you see the desktop behind).
    if (QScreen* sc = QGuiApplication::primaryScreen()) {
        setGeometry(sc->geometry());
    }

    show();
    raise();

    m_elapsed.restart();
    m_tick.start();
}

void SplashScreen::paintEvent(QPaintEvent* e)
{
    Q_UNUSED(e);

    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);
    p.setRenderHint(QPainter::TextAntialiasing, true);
    p.setRenderHint(QPainter::SmoothPixmapTransform, true);

    const qint64 t = m_elapsed.isValid() ? m_elapsed.elapsed() : 0;

    // Timing (ms) tuned to match the uploaded reference clip:
    const int fadeIn = 260;
    const int fadeOut = 520;

    const int textStart = 320;
    const int msPerChar = 95;

    const int titleLen = m_title.size();
    const int textDone = textStart + msPerChar * qMax(1, titleLen);

    const int ringStart = textDone + 260;
    const int ringFadeIn = 240;

    // Global alpha (fade-in / fade-out)
    double alpha = 1.0;
    if (t < fadeIn) alpha = clamp01(double(t) / double(fadeIn));
    if (t > (m_durationMs - fadeOut)) alpha = qMin(alpha, clamp01(double(m_durationMs - t) / double(fadeOut)));

    // Scale with screen size (reference looks good on 1080p)
    const double scale = qMin(width() / 1920.0, height() / 1080.0);

    const QPointF center = rect().center();

    // -------- Ring (smoke circle) --------
    // Appears AFTER the title finishes typing; draw behind the text.
    if (!m_frames.isEmpty() && t >= ringStart) {
        double ringA = 1.0;
        if (t < ringStart + ringFadeIn) {
            ringA = clamp01(double(t - ringStart) / double(ringFadeIn));
        }

        // frame index ~30 fps
        const int idx = int((t - ringStart) / 33) % m_frames.size();
        const QPixmap ring = m_frames[idx];

        // Larger so it is clearly visible.
        const int ringSize = int(520.0 * scale);
        const QPixmap scaled = ring.scaled(ringSize, ringSize, Qt::KeepAspectRatio, Qt::SmoothTransformation);

        const QPoint topLeft(int(center.x() - scaled.width() / 2.0),
                             int((center.y() - 10.0 * scale) - scaled.height() / 2.0));

        p.save();
        p.setOpacity(alpha * ringA);
        p.drawPixmap(topLeft, scaled);
        p.restore();
    }

    // -------- Title (gold with red stroke + shadow) --------
    int chars = 0;
    if (t >= textStart) {
        chars = int((t - textStart) / msPerChar);
        if (chars > titleLen) chars = titleLen;
        if (chars < 0) chars = 0;
    }
    const QString shown = m_title.left(chars);

    QFont f("Times New Roman");
    f.setBold(true);
    f.setItalic(true);
    f.setPointSizeF(72.0 * scale);

    QPainterPath textPath;
    textPath.addText(0, 0, f, shown);

    QRectF tb = textPath.boundingRect();

    // Center the text; slight upward bias looks closer to the clip.
    const QPointF targetCenter(center.x(), center.y() - 10.0 * scale);
    QTransform tr;
    tr.translate(targetCenter.x() - tb.center().x(), targetCenter.y() - tb.center().y());
    textPath = tr.map(textPath);
    tb = textPath.boundingRect();

    p.save();
    p.setOpacity(alpha);

    // Shadow
    QPainterPath shadow = textPath.translated(3.0 * scale, 3.0 * scale);
    p.setPen(Qt::NoPen);
    p.setBrush(QColor(0, 0, 0, 160));
    p.drawPath(shadow);

    // Outer stroke (reddish)
    QPen outer(QColor(120, 20, 18, 220), 6.5 * scale, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    p.setPen(outer);
    p.setBrush(Qt::NoBrush);
    p.drawPath(textPath);

    // Fill (gold gradient)
    QLinearGradient gold(tb.topLeft(), tb.bottomLeft());
    gold.setColorAt(0.00, QColor(255, 245, 205));
    gold.setColorAt(0.35, QColor(245, 195, 90));
    gold.setColorAt(0.70, QColor(190, 120, 35));
    gold.setColorAt(1.00, QColor(120, 70, 20));
    p.setPen(Qt::NoPen);
    p.setBrush(gold);
    p.drawPath(textPath);

    // Subtle highlight
    QLinearGradient hl(tb.topLeft(), tb.topRight());
    hl.setColorAt(0.0, QColor(255, 255, 255, 120));
    hl.setColorAt(1.0, QColor(255, 255, 255, 0));
    p.setOpacity(alpha * 0.45);
    p.setBrush(hl);
    p.drawPath(textPath);

    p.restore();
}
