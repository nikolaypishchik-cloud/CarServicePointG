#pragma once

#include <QWidget>
#include <QVector>
#include <QPixmap>
#include <QTimer>
#include <QElapsedTimer>
#include <QString>

class SplashScreen : public QWidget
{
    Q_OBJECT
public:
    explicit SplashScreen(QWidget* parent=nullptr);

    // Default matches the reference animation (~5s)
    void start(int durationMs = 5200);

signals:
    void finished();

protected:
    void paintEvent(QPaintEvent* e) override;

private:
    void loadFrames();

    QVector<QPixmap> m_frames;
    QTimer m_tick;
    QElapsedTimer m_elapsed;
    int m_durationMs = 5200;
    QString m_title;
};
