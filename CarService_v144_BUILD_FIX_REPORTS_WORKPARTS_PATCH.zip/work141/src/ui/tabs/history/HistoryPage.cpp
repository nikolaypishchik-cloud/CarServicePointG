#include "ui/tabs/history/HistoryPage.h"

#include "infrastructure/db/sqlite/Db.h"
#include "ui/common/dialogs/OrderDialog.h"
#include "core/util/FormatUtils.h"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QToolButton>
#include <QTableView>
#include <QHeaderView>
#include <QLineEdit>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QSortFilterProxyModel>
#include <QDate>
#include <algorithm>


namespace {
static QString displayDateShort(const QVariant& v)
{
    const QString raw = v.toString().trimmed();
    if (raw.isEmpty()) return QString();
    QString t = raw;
    const int tpos = t.indexOf('T');
    if (tpos > 0) t = t.left(tpos);
    for (const QString& fmt : {QStringLiteral("yyyy-MM-dd"), QStringLiteral("dd.MM.yy"), QStringLiteral("dd.MM.yyyy")}) {
        const QDate d = QDate::fromString(t, fmt);
        if (d.isValid()) return d.toString(QStringLiteral("dd.MM.yy"));
    }
    return raw;
}

class HistoryDisplayProxy final : public QSortFilterProxyModel {
public:
    using QSortFilterProxyModel::QSortFilterProxyModel;
    QVariant data(const QModelIndex& index, int role) const override
    {
        if (!index.isValid()) return QSortFilterProxyModel::data(index, role);
        if (role == Qt::DisplayRole) {
            const QVariant src = QSortFilterProxyModel::data(index, role);
            switch (index.column()) {
            case 1:
            case 2: return displayDateShort(src);
            case 8:
            case 9: return FormatUtils::money(src.toDouble(), 0);
            default: break;
            }
        }
        return QSortFilterProxyModel::data(index, role);
    }
};
}

HistoryPage::HistoryPage(QWidget* parent)
    : QWidget(parent)
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(0,0,0,0);
    root->setSpacing(10);

    auto* bar = new QHBoxLayout();
    bar->setContentsMargins(0,0,0,0);

    auto* btnOpen = new QToolButton(this);
    btnOpen->setText(QString::fromUtf8("👁️ Відкрити"));
    auto* btnDelete = new QToolButton(this);
    btnDelete->setText(QString::fromUtf8("🗑️ Видалити"));
    auto* btnPdf = new QToolButton(this);
    btnPdf->setText(QString::fromUtf8("PDF"));

    m_search = new QLineEdit(this);
    m_search->setPlaceholderText(QString::fromUtf8("Пошук: марка, номер, VIN, клієнт…"));

    bar->addWidget(btnOpen);
    bar->addWidget(btnDelete);
    bar->addWidget(btnPdf);
    bar->addStretch(1);
    bar->addWidget(m_search, 1);

    root->addLayout(bar);

    m_table = new QTableView(this);
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::ExtendedSelection);
    m_table->setAlternatingRowColors(false);
    m_table->setSortingEnabled(true);

    m_model = new QSqlQueryModel(this);
    auto* proxy = new HistoryDisplayProxy(this);
    proxy->setSourceModel(m_model);
    proxy->setDynamicSortFilter(true);
    proxy->setSortCaseSensitivity(Qt::CaseInsensitive);
    m_table->setModel(proxy);
    m_table->verticalHeader()->setVisible(false);
    m_table->horizontalHeader()->setStretchLastSection(true);
    m_table->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    root->addWidget(m_table, 1);

    connect(btnOpen, &QToolButton::clicked, this, [this]() {
        int num = selectedOrderNumber();
        if (num <= 0) return;
        OrderDialog dlg(this, num);
        dlg.setWindowTitle(QString::fromUtf8("Редагування наряду"));
        dlg.openWorkPartsTab();
        const int rc = dlg.exec();
        Q_UNUSED(rc);
        emit requestRefreshAll();
    });

    connect(m_table, &QTableView::doubleClicked, this, [this](const QModelIndex& index) {
        if (!index.isValid() || !m_table || !m_table->model()) return;
        const QModelIndex numIdx = m_table->model()->index(index.row(), 0);
        bool ok = false;
        const int num = m_table->model()->data(numIdx).toInt(&ok);
        if (!ok || num <= 0) return;
        m_table->selectRow(index.row());
        OrderDialog dlg(this, num);
        dlg.setWindowTitle(QString::fromUtf8("Редагування наряду"));
        dlg.openWorkPartsTab();
        const int rc = dlg.exec();
        Q_UNUSED(rc);
        emit requestRefreshAll();
    });


    connect(btnPdf, &QToolButton::clicked, this, [this]() {
        int num = selectedOrderNumber();
        if (num <= 0) return;
        OrderDialog dlg(this, num);
        dlg.openWorkPartsTab();
        dlg.exportPdfPreviewAndOpen();
    });

    connect(btnDelete, &QToolButton::clicked, this, [this]() {
    const QList<int> nums = selectedOrderNumbers();
    if (nums.isEmpty()) return;

    QString list;
    for (int n : nums) list += QString::number(n) + ", ";
    if (list.endsWith(", ")) list.chop(2);

    if (QMessageBox::question(this, QString::fromUtf8("Підтвердження"),
                              QString::fromUtf8("Видалити %1 закритих нарядів?\n№: %2\n\nДія незворотна.")
                                  .arg(nums.size()).arg(list))
        != QMessageBox::Yes) {
        return;
    }

    QSqlDatabase d = Database::db();
    if (!d.transaction()) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не можу відкрити транзакцію"));
        return;
    }

    QSqlQuery q(d);
    q.prepare("DELETE FROM work_orders WHERE number=?");
    for (int n : nums) {
        q.addBindValue(n);
        if (!q.exec()) {
            d.rollback();
            QMessageBox::critical(this, QString::fromUtf8("Помилка"), q.lastError().text());
            return;
        }
        q.finish();
    }

    d.commit();
    emit requestRefreshAll();
});

    connect(m_search, &QLineEdit::textChanged, this, [this]() { refresh(); });

    refresh();
}

int HistoryPage::selectedOrderNumber() const
{
    if (!m_table || !m_model) return -1;
    QModelIndex idx = m_table->currentIndex();
    if (!idx.isValid()) return -1;
    const QModelIndex numIdx = m_table->model()->index(idx.row(), 0);
    bool ok = false;
    int num = m_table->model()->data(numIdx).toInt(&ok);
    return ok ? num : -1;

}

QList<int> HistoryPage::selectedOrderNumbers() const
{
    QList<int> out;
    if (!m_table || !m_model) return out;
    auto* sel = m_table->selectionModel();
    if (!sel) return out;
    const QModelIndexList rows = sel->selectedRows(0);
    for (const QModelIndex& idx : rows) {
        bool ok = false;
        int num = m_table->model()->data(idx).toInt(&ok);
        if (ok) out.append(num);
    }
    std::sort(out.begin(), out.end());
    out.erase(std::unique(out.begin(), out.end()), out.end());
    return out;
}

void HistoryPage::refresh()
{
    const QString filter = m_search ? m_search->text().trimmed() : QString();

    auto escapeLike = [](const QString& s) {
        QString out = s;
        out.replace(QStringLiteral("\\"), QStringLiteral("\\\\"));
        out.replace(QStringLiteral("%"),  QStringLiteral("\\%"));
        out.replace(QStringLiteral("_"),  QStringLiteral("\\_"));
        return out;
    };
    auto makeFtsQuery = [](const QString& s) {
        // Turn user input into: token1* AND token2* ...
        QStringList toks = s.simplified().split(' ', Qt::SkipEmptyParts);
        for (QString& tok : toks) {
            tok.replace('"', ' ');
            tok = tok.trimmed();
            if (tok.isEmpty()) continue;
            // Prefix match
            if (!tok.endsWith('*')) tok += '*';
        }
        toks.removeAll(QString());
        return toks.isEmpty() ? QString() : toks.join(QStringLiteral(" AND "));
    };

    QSqlQuery q(Database::db());

QString sql =
    "SELECT o.number AS '№', "
    "       o.opened_at AS 'Відкрито', "
            "       o.closed_at AS 'Закрито', "
        "       o.status AS 'Статус', "
        "       o.plate AS 'Номер', "
        "       o.car AS 'Авто', "
        "       o.client AS 'Клієнт', "
        "       COALESCE(NULLIF(o.master_name_closed,''), (SELECT name FROM masters m WHERE m.id=o.master_id), '') AS 'Майстер', "
        "       o.works_sum AS 'Роботи', "
        "       o.parts_sum AS 'Запчастини' "
        "FROM work_orders o "
        "WHERE o.status = 'closed'";

    QString whereExtra;
    QString fts = makeFtsQuery(filter);
    if (!fts.isEmpty()) {
        whereExtra += " AND o.number IN (SELECT rowid FROM work_orders_fts WHERE work_orders_fts MATCH :m)";
    } else if (!filter.isEmpty()) {
        whereExtra += " AND (o.car LIKE :p ESCAPE '\\' "
                      " OR o.plate LIKE :p ESCAPE '\\' "
                      " OR o.vin LIKE :p ESCAPE '\\' "
                      " OR o.client LIKE :p ESCAPE '\\' "
                      " OR CAST(o.number AS TEXT) LIKE :p ESCAPE '\\')";
    }

    sql += whereExtra;
    sql += " ORDER BY o.closed_at DESC";

    q.prepare(sql);
    if (!fts.isEmpty()) {
        q.bindValue(":m", fts);
    } else if (!filter.isEmpty()) {
        q.bindValue(":p", "%" + escapeLike(filter) + "%");
    }

    if (!q.exec()) {
        qWarning() << "HistoryPage query error" << q.lastError().text();
    }
    m_model->setQuery(q);

    if (m_model->lastError().isValid()) {
        qWarning() << "HistoryPage model error" << m_model->lastError().text();
    }
}

