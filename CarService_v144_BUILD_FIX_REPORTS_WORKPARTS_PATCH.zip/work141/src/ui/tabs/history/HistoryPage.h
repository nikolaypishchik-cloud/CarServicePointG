#pragma once

#include <QWidget>
#include <QSqlQueryModel>
#include <QList>

class QTableView;
class QLineEdit;

class HistoryPage : public QWidget
{
    Q_OBJECT
public:
    explicit HistoryPage(QWidget* parent=nullptr);

    void refresh();

signals:
    void requestRefreshAll();

private:
    int selectedOrderNumber() const;
    QList<int> selectedOrderNumbers() const;

    QSqlQueryModel* m_model = nullptr;
    QTableView* m_table = nullptr;
    QLineEdit* m_search = nullptr;
};
