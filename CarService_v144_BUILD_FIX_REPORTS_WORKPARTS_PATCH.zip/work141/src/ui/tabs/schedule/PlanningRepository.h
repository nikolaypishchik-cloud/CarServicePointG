#pragma once
#include <QDate>
#include <QString>
#include <QMap>

// SQL-only repository for planning_calendar(day,note).
// note format: plain text lines "HH:00 some text"
class PlanningRepository {
public:
    QString getNote(const QDate& day) const;
    void setNote(const QDate& day, const QString& note) const;

    QMap<int, QString> getDayMap(const QDate& day) const;      // hour -> text
    void setDayMap(const QDate& day, const QMap<int, QString>& map) const;
};
