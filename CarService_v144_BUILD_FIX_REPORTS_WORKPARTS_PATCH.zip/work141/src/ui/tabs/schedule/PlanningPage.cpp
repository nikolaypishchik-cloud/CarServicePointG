#include "ui/tabs/schedule/PlanningPage.h"
#include "ui/tabs/schedule/PlanningRepository.h"
#include "core/util/PlateUtils.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QComboBox>
#include <QSpinBox>
#include <QScrollArea>
#include <QFrame>
#include <QLineEdit>
#include <QDate>
#include <QTime>
#include <QDateTime>
#include <QMessageBox>
#include <QMenu>
#include <QDialog>
#include <QDateEdit>
#include <QDialogButtonBox>
#if CS_HAS_MULTIMEDIA
#include <QSoundEffect>
#endif
#include <QSet>
#include <QEvent>
#include <QMouseEvent>
#include <QApplication>
#include <QScreen>
#include <QWindow>
#include <QSpacerItem>
#include <QGraphicsOpacityEffect>
#include <QPropertyAnimation>
#include <QParallelAnimationGroup>
#include <QEasingCurve>
#include <QAbstractAnimation>
#include <algorithm>

namespace {

// Monday=1 .. Sunday=7
static QString uaWeekday(int dow)
{
    switch (dow) {
    case 1: return QString::fromUtf8("Понеділок");
    case 2: return QString::fromUtf8("Вівторок");
    case 3: return QString::fromUtf8("Середа");
    case 4: return QString::fromUtf8("Четвер");
    case 5: return QString::fromUtf8("Пʼятниця");
    case 6: return QString::fromUtf8("Субота");
    case 7: return QString::fromUtf8("Неділя");
    default: return QString();
    }
}

static QString uaMonth(int m)
{
    static const char* months[] = {
        "Січень","Лютий","Березень","Квітень","Травень","Червень",
        "Липень","Серпень","Вересень","Жовтень","Листопад","Грудень"
    };
    if (m < 1 || m > 12) return QString();
    return QString::fromUtf8(months[m-1]);
}


static QString normalizePlanningSlotText(const QString& input)
{
    const QString trimmed = input.trimmed();
    if (trimmed.isEmpty()) return QString();
    if (!PlateUtils::isLikelyPlateInput(trimmed)) return input;
    return PlateUtils::formatPlateProgressive(trimmed);
}

static QString compactPlanLine(int hour, const QString& raw)
{
    QString txt = raw.trimmed();
    if (txt.isEmpty()) return QString();
    QString icon = txt.contains(QString::fromUtf8("✕")) || txt.contains(QString::fromUtf8("❌"))
        ? QString::fromUtf8("❌")
        : QString::fromUtf8("✅");
    txt.remove(QString::fromUtf8("✕"));
    txt.remove(QString::fromUtf8("❌"));
    txt.remove(QString::fromUtf8("✓"));
    txt.remove(QString::fromUtf8("✅"));
    txt = txt.simplified();
    return QString("%1:00 %2 %3")
        .arg(hour, 2, 10, QChar('0'))
        .arg(icon)
        .arg(txt);
}

class DayCell final : public QFrame
{
public:
    explicit DayCell(const QDate& d, QWidget* parent=nullptr)
        : QFrame(parent), m_date(d)
    {
        setObjectName("planning_daycell");
        setAttribute(Qt::WA_StyledBackground, true);
        setAutoFillBackground(true);
        setStyleSheet(R"QSS(
            #planning_daycell {
                background: #ffffff;
                border: 1px solid #7f858c;
                border-radius: 8px;
            }
            #planning_daycell[current="true"] {
                border: 2px solid #2e9d45;
            }
            #planning_daycell[selected="true"] {
                border: 2px solid #2e7d32;
            }
            #planning_daycell_header {
                background: #f2f2f2;
                color: #111111;
                font-weight: 700;
                padding-left: 0px;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                border-bottom: 1px solid #c9ced4;
            }
            #planning_daycell_header[current="true"] {
                background: #d7f2d6;
            }
            #planning_daycell_body {
                background: transparent;
                color: #111111;
                font-size: 11pt;
            }
        )QSS");
        setFrameShape(QFrame::NoFrame);
        setCursor(Qt::PointingHandCursor);
        setMouseTracking(true);

        auto* l = new QVBoxLayout(this);
        l->setContentsMargins(0,0,0,0);
        l->setSpacing(0);

        m_header = new QLabel(this);
        m_header->setObjectName("planning_daycell_header");
        m_header->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        m_header->setContentsMargins(8,4,8,4);
        m_header->setAttribute(Qt::WA_TransparentForMouseEvents, true);
        l->addWidget(m_header);

        m_body = new QLabel(this);
        m_body->setObjectName("planning_daycell_body");
        m_body->setAlignment(Qt::AlignLeft | Qt::AlignTop);
        m_body->setContentsMargins(8,6,8,6);
        m_body->setWordWrap(true);
        m_body->setTextFormat(Qt::PlainText);
        m_body->setAttribute(Qt::WA_TransparentForMouseEvents, true);
        l->addWidget(m_body, 1);

        refreshText();
        setMinimumSize(176, 150);
    }

    QDate date() const { return m_date; }

    void setSelected(bool on)
    {
        m_selected = on;
        setProperty("selected", on);
        repolish();
    }

    void setCurrentDate(bool on)
    {
        m_current = on;
        setProperty("current", on);
        m_header->setProperty("current", on);
        repolish();
    }

    void setPreviewText(const QString& t)
    {
        m_body->setText(t);
    }

    void refreshText()
    {
        const QString title = QString("%1.%2.%3 - %4")
            .arg(m_date.day(), 2, 10, QChar('0'))
            .arg(m_date.month(), 2, 10, QChar('0'))
            .arg(m_date.year()%100, 2, 10, QChar('0'))
            .arg(uaWeekday(m_date.dayOfWeek()));
        m_header->setText(title);
    }

private:
    void repolish()
    {
        style()->unpolish(this);
        style()->polish(this);
        style()->unpolish(m_header);
        style()->polish(m_header);
        update();
    }

    QDate m_date;
    QLabel* m_header{};
    QLabel* m_body{};
    bool m_selected=false;
    bool m_current=false;
};

} // namespace

PlanningPage::PlanningPage(QWidget* parent)
    : QWidget(parent)
{
    m_repo = new PlanningRepository();

    buildUi();

    const QDate today = QDate::currentDate();
    setMonth(today);

    m_hoverTimer.setSingleShot(true);
    m_hoverTimer.setInterval(300);
    connect(&m_hoverTimer, &QTimer::timeout, this, [this]() {
        if (m_hoverDate.isValid()) showPreviewFor(m_hoverDate);
    });
    // reminders (15 minutes before planned time)
    m_reminderDay = QDate::currentDate();
    m_reminderTimer.setInterval(30 * 1000);
    connect(&m_reminderTimer, &QTimer::timeout, this, &PlanningPage::checkReminders);
    m_reminderTimer.start();

    #if CS_HAS_MULTIMEDIA
    m_reminderSound = new QSoundEffect(this);
    m_reminderSound->setSource(QUrl("qrc:/assets/sounds/notify.wav"));
    m_reminderSound->setLoopCount(1);
    m_reminderSound->setVolume(0.9f);
#else
    m_reminderSound = nullptr;
#endif
}

void PlanningPage::buildUi()
{
    setObjectName("planning_page");
    setAttribute(Qt::WA_StyledBackground, true);
    setAutoFillBackground(true);
    // Local stylesheet for Planning page (kept on the widget so it wins over app stylesheet)
    // (removed old page-level stylesheet; styles are applied locally per-widget above)

    auto* rootL = new QVBoxLayout(this);
    rootL->setContentsMargins(12,12,12,12);
    rootL->setSpacing(10);

    // top bar
    auto* top = new QFrame(this);
    top->setObjectName("planning_topbar");
    top->setAttribute(Qt::WA_StyledBackground, true);
    top->setStyleSheet(R"QSS(
        #planning_topbar {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #9f9f9f, stop:0.22 #d2d2d2, stop:0.5 #8e8e8e,
                stop:0.78 #c8c8c8, stop:1 #767676);
            border: 1px solid rgba(0,0,0,120);
            border-radius: 14px;
        }
        #planning_title {
            color: #ffffff;
            font-size: 16pt;
            font-weight: 700;
            background: transparent;
        }
        QPushButton {
            background: #efefef;
            border: 1px solid rgba(0,0,0,140);
            border-radius: 10px;
            color: #000000;
            font-weight: 600;
            padding: 8px 12px;
        }
        QPushButton:hover { background: #f7f7f7; }
        QComboBox, QSpinBox {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,120);
            border-radius: 10px;
            padding: 6px 10px;
            color: #000000;
            font-weight: 600;
        }
        QComboBox::drop-down {
            border: none;
            width: 24px;
        }
        QComboBox::down-arrow {
            image: none;
            border-left: 6px solid transparent;
            border-right: 6px solid transparent;
            border-top: 8px solid #000000;
            margin-right: 8px;
        }
    )QSS");
    top->setAttribute(Qt::WA_StyledBackground, true);
    auto* topL = new QHBoxLayout(top);
    topL->setContentsMargins(12,10,12,10);
    topL->setSpacing(10);

    m_btnPrev = new QPushButton(QString::fromUtf8("◀"), top);
    m_btnPrev->setObjectName("planning_nav_btn");
    m_btnPrev->setFixedSize(36,36);

    m_btnNext = new QPushButton(QString::fromUtf8("▶"), top);
    m_btnNext->setObjectName("planning_nav_btn");
    m_btnNext->setFixedSize(36,36);

    m_lblMonthTitle = new QLabel(top);
    m_lblMonthTitle->setObjectName("planning_month_title");
    m_lblMonthTitle->setMinimumWidth(180);

    topL->addWidget(m_btnPrev);
    topL->addWidget(m_btnNext);
    topL->addSpacing(10);
    topL->addWidget(m_lblMonthTitle);
    topL->addStretch(1);

    m_cbMonth = new QComboBox(top);
    m_cbMonth->setObjectName("planning_month_cb");
    for (int m=1; m<=12; ++m) m_cbMonth->addItem(uaMonth(m), m);

    m_spYear = new QSpinBox(top);
    m_spYear->setObjectName("planning_year_sp");
    m_spYear->setRange(2000, 2100);

    m_btnToday = new QPushButton(QString::fromUtf8("Сьогодні"), top);
    m_btnToday->setObjectName("planning_today_btn");
    m_btnToday->setFixedHeight(36);

    topL->addWidget(m_cbMonth);
    topL->addWidget(m_spYear);
    topL->addWidget(m_btnToday);

    rootL->addWidget(top);

    // grid
    m_scroll = new QScrollArea(this);
    m_scroll->setObjectName("planning_scroll");
    m_scroll->setWidgetResizable(true);
    m_scroll->setFrameShape(QFrame::NoFrame);

    m_gridHost = new QWidget(m_scroll);
    m_gridHost->setObjectName("planning_grid_host");
    m_gridHost->setAttribute(Qt::WA_StyledBackground, true);
    m_grid = new QGridLayout(m_gridHost);
    m_grid->setContentsMargins(1,1,1,1);
    m_grid->setHorizontalSpacing(2);
    m_grid->setVerticalSpacing(2);

    m_scroll->setWidget(m_gridHost);
    rootL->addWidget(m_scroll, 1);

    // preview popup (tool)
    m_preview = new QFrame(window(), Qt::Tool | Qt::FramelessWindowHint);
    m_preview->setWindowFlags(Qt::Tool | Qt::FramelessWindowHint);
    m_preview->setAttribute(Qt::WA_ShowWithoutActivating);
    m_preview->setAttribute(Qt::WA_StyledBackground);
    m_preview->setObjectName("planning_preview");
    m_preview->setAttribute(Qt::WA_StyledBackground, true);
    m_preview->setAutoFillBackground(true);
    m_preview->setStyleSheet(R"QSS(
        #planning_preview {
            background: rgba(255,255,255,245);
            border: 2px solid #000000;
            border-radius: 18px;
        }

        /*
           ВАЖЛИВО: глобальна темна тема може задавати QLabel/QAbstractButton фон або колір.
           Тут примусово робимо текст видимим і фон прозорим.
        */
        QLabel#planning_preview_title,
        QLabel#planning_preview_body,
        QLabel#planning_preview_hint {
            background: transparent;
            color: #000000;
        }

        QLabel#planning_preview_title {
            font-size: 16pt;
            font-weight: 700;
        }
        #planning_preview_line {
            background: #e6e6e6;
            border: 1px solid #c9c9c9;
            border-radius: 10px;
            padding: 6px 14px;
            color: #000000;
            font-size: 13pt;
        }
        QLabel#planning_preview_body {
            font-size: 13pt;
        }
        QLabel#planning_preview_hint {
            font-size: 12pt;
        }
    )QSS");
    m_preview->setAttribute(Qt::WA_StyledBackground, true);

    auto* pvL = new QVBoxLayout(m_preview);
    pvL->setContentsMargins(18,14,18,14);
    pvL->setSpacing(10);

    m_previewTitle = new QLabel(m_preview);
    m_previewTitle->setObjectName("planning_preview_title");
    m_previewTitle->setAlignment(Qt::AlignHCenter);
    pvL->addWidget(m_previewTitle);

    auto* pvBox = new QFrame(m_preview);
    pvBox->setObjectName("planning_preview_line");
    pvBox->setAttribute(Qt::WA_StyledBackground, true);
    auto* pvBoxL = new QVBoxLayout(pvBox);
    pvBoxL->setContentsMargins(14,10,14,10);

    m_previewBody = new QLabel(pvBox);
    m_previewBody->setObjectName("planning_preview_body");
    m_previewBody->setWordWrap(true);
    pvBoxL->addWidget(m_previewBody);

    pvL->addWidget(pvBox);

    m_previewHint = new QLabel(QString::fromUtf8("Клікніть — щоб відкрити/редагувати"), m_preview);
    m_previewHint->setObjectName("planning_preview_hint");
    m_previewHint->setObjectName("planning_preview_hint");
    m_previewHint->setAlignment(Qt::AlignHCenter);
    pvL->addWidget(m_previewHint);

    m_preview->hide();

    // editor overlay (child, centered)
    m_editor = new QFrame(this);
    m_editor->setObjectName("planning_editor");
    m_editor->setAttribute(Qt::WA_StyledBackground, true);
    m_editor->setAutoFillBackground(true);
    m_editor->setStyleSheet(R"QSS(
        #planning_editor {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #d4d7dc, stop:0.18 #f4f5f7, stop:0.48 #cfd3d8,
                stop:0.72 #eceef0, stop:1 #bcc2c8);
            border: 2px solid #2e7d32;
            border-radius: 18px;
        }
        #planning_editor_header {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #bfc5cb, stop:0.22 #eef0f2, stop:0.52 #c9ced3, stop:1 #adb4bb);
            border-bottom: 1px solid #b9c0c7;
            border-top-left-radius: 18px;
            border-top-right-radius: 18px;
        }
        /* Контрастний текст (не залежить від глобальних тем) */
        QLabel#planning_editor_date {
            background: transparent;
            color: #111111; /* світлий фон -> темний текст */
            font-size: 14pt;
            font-weight: 700;
        }
        QLabel#planning_editor_info {
            background: transparent;
            color: #222222; /* світлий фон -> темний текст */
            font-style: italic;
            font-size: 12pt;
        }
        QLabel#planning_editor_time {
            background: transparent;
            color: #000000;
        }
        #planning_editor_clear {
            background: #efefef;
            border: 1px solid #8a8a8a;
            border-radius: 8px;
            padding: 8px 16px;
            color: #000000;
            font-weight: 600;
        }
        #planning_editor_clear:hover {
            background: #f7f7f7;
        }
        #planning_editor_close {
            background: transparent;
            border: none;
            color: #000000;
            font-size: 18pt;
            font-weight: 900;
            padding: 0px 10px;
        }
        #planning_editor_close:hover {
            background: rgba(0,0,0,30);
            border-radius: 8px;
        }
        QLabel#planning_editor_time {
            font-size: 12pt;
            font-weight: 600;
        }
        QLineEdit {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #fbfbfc, stop:0.25 #ffffff, stop:0.68 #eef1f4, stop:1 #e0e5ea);
            border: 1px solid #b0b7bf;
            border-radius: 10px;
            padding: 6px 12px;
            color: #000000;
            font-size: 12pt;
        }
        QLineEdit:focus {
            border: 2px solid #2e7d32;
        }
    )QSS");
    m_editor->setAttribute(Qt::WA_StyledBackground);
    m_editor->hide();

    // editor open/close animation
    m_editorOpacity = new QGraphicsOpacityEffect(m_editor);
    m_editorOpacity->setOpacity(0.0);
    m_editor->setGraphicsEffect(m_editorOpacity);

    m_editorGeomAnim = new QPropertyAnimation(m_editor, "geometry", m_editor);
    m_editorOpacityAnim = new QPropertyAnimation(m_editorOpacity, "opacity", m_editor);
    m_editorAnimGroup = new QParallelAnimationGroup(m_editor);
    m_editorAnimGroup->addAnimation(m_editorGeomAnim);
    m_editorAnimGroup->addAnimation(m_editorOpacityAnim);
    m_editorGeomAnim->setDuration(220);
    m_editorOpacityAnim->setDuration(220);
    m_editorGeomAnim->setEasingCurve(QEasingCurve::OutCubic);
    m_editorOpacityAnim->setEasingCurve(QEasingCurve::OutCubic);

    connect(m_editorAnimGroup, &QParallelAnimationGroup::finished, this, [this]() {
        // if opacity is 0 at end, ensure it's hidden (close animation)
        if (m_editorOpacity && m_editorOpacity->opacity() <= 0.001) {
            m_editor->hide();
        }
    });

    auto* edRoot = new QVBoxLayout(m_editor);
    edRoot->setContentsMargins(14,14,14,14);
    edRoot->setSpacing(6);

    auto* edHeader = new QFrame(m_editor);
    edHeader->setObjectName("planning_editor_header");
    auto* edHL = new QHBoxLayout(edHeader);
    edHL->setContentsMargins(14,10,14,10);
    edHL->setSpacing(8);

    m_editorDate = new QLabel(edHeader);
    m_editorDate->setObjectName("planning_editor_date");
    m_editorDate->setMinimumWidth(120);

    edHL->addWidget(m_editorDate);
    edHL->addStretch(1);

    m_btnClear = new QPushButton(QString::fromUtf8("Очистити"), edHeader);
    m_btnClear->setObjectName("planning_editor_clear");
    m_btnClear->setFixedHeight(34);

    m_btnClose = new QPushButton(QString::fromUtf8("✕"), edHeader);
    m_btnClose->setObjectName("planning_editor_close");
    m_btnClose->setFixedSize(34,34);

    edHL->addWidget(m_btnClear);
    edHL->addWidget(m_btnClose);

    edRoot->addWidget(edHeader);

    m_editorInfo = new QLabel(QString::fromUtf8("Запланованих робіт нема"), m_editor);
    m_editorInfo->setObjectName("planning_editor_info");
    edRoot->addWidget(m_editorInfo);

    auto* slotsHost = new QWidget(m_editor);
    auto* slotsL = new QGridLayout(slotsHost);
    slotsL->setContentsMargins(0,0,0,0);
    slotsL->setHorizontalSpacing(1);
    slotsL->setVerticalSpacing(1);

    const int startHour = 9;
    const int endHour = 16;
    for (int h=startHour, row=0; h<=endHour; ++h, ++row) {
        SlotRow r;
        r.timeLabel = new QLabel(QString("%1:00").arg(h, 2, 10, QChar('0')), slotsHost);
        r.timeLabel->setObjectName("planning_editor_time");
        r.timeLabel->setFixedWidth(56);
        r.timeLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);

        r.edit = new QLineEdit(slotsHost);
        r.edit->setObjectName("planning_editor_edit");
        r.edit->setMinimumHeight(32);
        connect(r.edit, &QLineEdit::textChanged, this, [edit=r.edit](const QString& text) {
            const QString formatted = normalizePlanningSlotText(text);
            if (formatted == text) return;
            const int oldCursor = edit->cursorPosition();
            const int delta = formatted.size() - text.size();
            QSignalBlocker blocker(edit);
            edit->setText(formatted);
            const int newCursor = std::max(0, std::min(static_cast<int>(formatted.size()), oldCursor + delta));
            edit->setCursorPosition(newCursor);
        });
        connect(r.edit, &QLineEdit::editingFinished, this, [edit=r.edit]() {
            const QString formatted = normalizePlanningSlotText(edit->text());
            if (formatted != edit->text()) edit->setText(formatted);
        });

        r.edit->setContextMenuPolicy(Qt::CustomContextMenu);
        const int slotHour = h;
        connect(r.edit, &QWidget::customContextMenuRequested, this, [this, slotHour, edit=r.edit](const QPoint& pos) {
            QMenu menu;
            QAction* actMove = menu.addAction(QString::fromUtf8("Перенести…"));
            QAction* actCancel = menu.addAction(QString::fromUtf8("Скасувати запис"));
            menu.addSeparator();
            QAction* actCopy = menu.addAction(QString::fromUtf8("Копіювати текст"));
            QAction* actPaste = menu.addAction(QString::fromUtf8("Вставити текст"));
            QAction* picked = menu.exec(edit->mapToGlobal(pos));
            if (!picked) return;

            if (picked == actCopy) { edit->copy(); return; }
            if (picked == actPaste) { edit->paste(); return; }

            if (picked == actCancel) {
                if (edit->text().trimmed().isEmpty()) return;
                if (QMessageBox::question(this,
                        QString::fromUtf8("Підтвердження"),
                        QString::fromUtf8("Скасувати запис о %1:00 на %2?")
                            .arg(slotHour,2,10,QChar('0'))
                            .arg(m_editDate.toString("dd.MM.yy")))
                    != QMessageBox::Yes) return;
                edit->clear();
                updateEditorHeader();
                return;
            }

            if (picked == actMove) {
                if (edit->text().trimmed().isEmpty()) return;
                QDialog dlg(this);
                dlg.setWindowTitle(QString::fromUtf8("Перенесення запису"));
                QVBoxLayout* l = new QVBoxLayout(&dlg);
                QDateEdit* d = new QDateEdit(m_editDate, &dlg);
                d->setCalendarPopup(true);
                QSpinBox* hh = new QSpinBox(&dlg);
                hh->setRange(0,23);
                hh->setValue(slotHour);
                hh->setSuffix(QString::fromUtf8(" год"));
                QHBoxLayout* row = new QHBoxLayout();
                row->addWidget(new QLabel(QString::fromUtf8("Дата:"), &dlg));
                row->addWidget(d);
                row->addSpacing(12);
                row->addWidget(new QLabel(QString::fromUtf8("Час:"), &dlg));
                row->addWidget(hh);
                l->addLayout(row);
                QDialogButtonBox* bb = new QDialogButtonBox(QDialogButtonBox::Ok|QDialogButtonBox::Cancel, &dlg);
                l->addWidget(bb);
                connect(bb, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
                connect(bb, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
                if (dlg.exec() != QDialog::Accepted) return;

                const QDate nd = d->date();
                const int nh = hh->value();
                const QString txt = edit->text().trimmed();

                // remove from source slot
                edit->clear();

                // load destination map from cache/db
                QMap<int, QString> dest = m_plan.value(nd);
                if (dest.isEmpty() && m_repo) dest = m_repo->getDayMap(nd);
                dest[nh] = txt;
                m_plan[nd] = dest;
                if (m_repo) m_repo->setDayMap(nd, dest);

                updateEditorHeader();
                rebuildGrid();
                if (nd.year()==m_year && nd.month()==m_month) openEditorFor(nd);
                return;
            }
        });

        slotsL->addWidget(r.timeLabel, row, 0);
        slotsL->addWidget(r.edit, row, 1);

        m_rows.push_back(r);
    }

    edRoot->addWidget(slotsHost, 1);

    // connections
    connect(m_btnToday, &QPushButton::clicked, this, [this]() {
        setMonth(QDate::currentDate());
    });
    connect(m_btnPrev, &QPushButton::clicked, this, [this]() {
        setMonth(QDate(m_year, m_month, 1).addMonths(-1));
    });
    connect(m_btnNext, &QPushButton::clicked, this, [this]() {
        setMonth(QDate(m_year, m_month, 1).addMonths(1));
    });
    connect(m_cbMonth, &QComboBox::currentIndexChanged, this, [this](int) {
        const int m = m_cbMonth->currentData().toInt();
        if (m != m_month) setMonth(QDate(m_year, m, 1));
    });
    connect(m_spYear, QOverload<int>::of(&QSpinBox::valueChanged), this, [this](int y) {
        if (y != m_year) setMonth(QDate(y, m_month, 1));
    });

    connect(m_btnClose, &QPushButton::clicked, this, [this]() { closeEditor(true); });
    connect(m_btnClear, &QPushButton::clicked, this, [this]() {
        if (!m_editDate.isValid()) return;
        if (QMessageBox::question(this,
                QString::fromUtf8("Підтвердження"),
                QString::fromUtf8("Скасувати всі записи на %1?\n\nДія незворотна.")
                    .arg(m_editDate.toString("dd.MM.yy")))
            != QMessageBox::Yes) {
            return;
        }
        for (auto& r : m_rows) r.edit->clear();
        m_plan.remove(m_editDate);
        if (m_repo) m_repo->setDayMap(m_editDate, {});
        updateEditorHeader();
    });

    // style (local to planning)
    setStyleSheet(QString::fromUtf8(R"QSS(
        #planning_topbar {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #8f8f8f, stop:0.20 #d0d0d0, stop:0.48 #8d8d8d,
                stop:0.72 #c6c6c6, stop:1 #707070);
            border: 1px solid rgba(0,0,0,0.35);
            border-radius: 16px;
        }
        #planning_nav_btn, #planning_today_btn {
            background: #f5f5f5;
            border: 2px solid rgba(0,0,0,0.35);
            border-radius: 10px;
            font-weight: 700;
        }
        #planning_nav_btn:hover, #planning_today_btn:hover { background: #ffffff; }
        #planning_month_title {
            color: #ffffff;
            font-weight: 800;
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 rgba(35,38,43,0.96), stop:0.35 rgba(64,70,78,0.96),
                stop:0.52 rgba(175,175,175,0.78), stop:0.7 rgba(60,66,72,0.96), stop:1 rgba(35,38,43,0.96));
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 14px;
            padding: 8px 18px;
        }
        #planning_month_cb, #planning_year_sp {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #f8f8f8, stop:0.18 #ffffff, stop:0.5 #dcdcdc,
                stop:0.82 #f3f3f3, stop:1 #d0d0d0);
            border: 1px solid rgba(0,0,0,0.30);
            border-radius: 12px;
            padding: 6px 10px;
            min-height: 32px;
            color: #111111;
            font-weight: 700;
        }

        #planning_grid_host { background: transparent; }
        #planning_daycell {
            background: #ffffff;
            border: 1px solid rgba(76,84,92,0.55);
            border-radius: 8px;
        }
        #planning_daycell[selected="true"] {
            border: 2px solid #2e7d32;
        }
        #planning_daycell_header {
            background: #f2f2f2;
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            border-bottom: 1px solid rgba(120,128,136,0.45);
            color: #111111;
            font-weight: 800;
        }
        #planning_daycell_body { color: rgba(0,0,0,0.55); }

        /* preview */
        #planning_preview {
            background: #ffffff;
            border: 2px solid rgba(0,0,0,0.70);
            border-radius: 14px;
        }
        #planning_preview_title { font-weight: 800; color: #111; }
        #planning_preview_box {
            background: #f1f1f1;
            border: 1px solid rgba(0,0,0,0.18);
            border-radius: 10px;
        }
        #planning_preview_body { color: rgba(0,0,0,0.75); }
        #planning_preview_hint { color: rgba(0,0,0,0.65); }

        /* editor overlay */
        #planning_editor {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #d4d7dc, stop:0.18 #f4f5f7, stop:0.48 #cfd3d8,
                stop:0.72 #eceef0, stop:1 #bcc2c8);
            border: 2px solid #2e7d32;
            border-radius: 18px;
        }
        #planning_editor_header {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #bfc5cb, stop:0.22 #eef0f2, stop:0.52 #c9ced3, stop:1 #adb4bb);
            border: 1px solid rgba(120,128,136,0.28);
            border-radius: 12px;
        }
        QLabel#planning_editor_date {
            font-size: 18px;
            font-weight: 900;
            background: transparent;
            color: #111111;
            border: none;
            border-radius: 0px;
            padding: 2px 6px;
        }
        #planning_editor_clear, #planning_editor_close {
            background: #f0f0f0;
            border: 1px solid rgba(0,0,0,0.35);
            border-radius: 10px;
            font-weight: 800;
            color: #111111;
        }
        #planning_editor_clear:hover, #planning_editor_close:hover { background: #ffffff; }
        QLabel#planning_editor_info {
            color: rgba(0,0,0,0.92);
            font-style: italic;
            background: transparent;
            margin-left: 0px;
            margin-bottom: 0px;
        }
        QLabel#planning_editor_time {
            font-size: 18px;
            font-weight: 800;
            background: transparent;
            color: #000000;
            border: none;
            border-radius: 0px;
            padding: 0px 2px 0px 0px;
        }
        #planning_editor_edit {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #fbfbfc, stop:0.25 #ffffff, stop:0.68 #eef1f4, stop:1 #e0e5ea);
            border: 1px solid rgba(120,128,136,0.35);
            border-radius: 12px;
            padding-left: 8px;
            color: #111111;
        }
        #planning_editor_edit:focus { border: 1px solid #2e7d32; }
    )QSS"));
}

QRect PlanningPage::editorTargetRect() const
{
    const QRect area = m_scroll->viewport()->rect();
    const QSize sz(std::max(760, area.width()-60), std::max(520, area.height()-60));
    const QPoint p = m_scroll->viewport()->mapTo(const_cast<PlanningPage*>(this),
        QPoint((area.width()-sz.width())/2, (area.height()-sz.height())/2));
    return QRect(p, sz);
}

void PlanningPage::animateEditorOpen()
{
    if (!m_editor || !m_editorAnimGroup) return;
    m_editorAnimGroup->stop();

    const QRect target = editorTargetRect();
    const QPoint c = target.center();
    const QSize startSz(std::max(420, target.width()/2), std::max(280, target.height()/2));
    const QRect start(QPoint(c.x() - startSz.width()/2, c.y() - startSz.height()/2), startSz);

    m_editor->setGeometry(start);
    m_editor->show();
    m_editor->raise();

    m_editorGeomAnim->setStartValue(start);
    m_editorGeomAnim->setEndValue(target);

    m_editorOpacityAnim->setStartValue(0.0);
    m_editorOpacityAnim->setEndValue(1.0);

    m_editorAnimGroup->start();
}

void PlanningPage::animateEditorClose(bool hideOnly)
{
    if (!m_editor || !m_editorAnimGroup || !m_editorOpacity) {
        if (!hideOnly && m_editor) m_editor->hide();
        return;
    }
    if (!m_editor->isVisible()) return;

    m_editorAnimGroup->stop();

    const QRect cur = m_editor->geometry();
    const QPoint c = cur.center();
    const QSize endSz(std::max(380, cur.width()/2), std::max(240, cur.height()/2));
    const QRect end(QPoint(c.x() - endSz.width()/2, c.y() - endSz.height()/2), endSz);

    m_editorGeomAnim->setStartValue(cur);
    m_editorGeomAnim->setEndValue(end);
    m_editorOpacityAnim->setStartValue(m_editorOpacity->opacity());
    m_editorOpacityAnim->setEndValue(0.0);
    m_editorAnimGroup->start();

    if (hideOnly) {
        // nothing else
    }
}

void PlanningPage::setMonth(const QDate& anyDayInMonth)
{
    if (!anyDayInMonth.isValid()) return;
    m_year = anyDayInMonth.year();
    m_month = anyDayInMonth.month();

    m_lblMonthTitle->setText(QString::fromUtf8("%1 %2").arg(uaMonth(m_month)).arg(m_year));

    // block signals to avoid recursion
    const bool b1 = m_cbMonth->blockSignals(true);
    const bool b2 = m_spYear->blockSignals(true);
    const int idx = m_cbMonth->findData(m_month);
    if (idx >= 0) m_cbMonth->setCurrentIndex(idx);
    m_spYear->setValue(m_year);
    m_cbMonth->blockSignals(b1);
    m_spYear->blockSignals(b2);


    // Load month from DB (planning_calendar)
    if (m_repo) {
        QList<QDate> toRemove;
        for (auto it = m_plan.cbegin(); it != m_plan.cend(); ++it) {
            if (it.key().year() == m_year && it.key().month() == m_month) toRemove.push_back(it.key());
        }
        for (const QDate& d : toRemove) m_plan.remove(d);

        const int dim = QDate(m_year, m_month, 1).daysInMonth();
        for (int day = 1; day <= dim; ++day) {
            const QDate d(m_year, m_month, day);
            const auto map = m_repo->getDayMap(d);
            bool any=false;
            for (auto it = map.cbegin(); it != map.cend(); ++it) { if (!it.value().trimmed().isEmpty()) { any=true; break; } }
            if (any) m_plan[d] = map;
        }
    }
    rebuildGrid();

    const QDate today = QDate::currentDate();
    if (today.year() == m_year && today.month() == m_month) {
        QTimer::singleShot(0, this, [this, today]() {
            for (QObject* obj : m_gridHost->children()) {
                if (auto* w = dynamic_cast<DayCell*>(obj)) {
                    if (w->date() == today) {
                        m_scroll->ensureWidgetVisible(w, 0, 0);
                        break;
                    }
                }
            }
        });
    }
}

void PlanningPage::rebuildGrid()
{
    // clear old grid
    while (QLayoutItem* it = m_grid->takeAt(0)) {
        if (auto* w = it->widget()) w->deleteLater();
        delete it;
    }

    hidePreview();
    closeEditor(false);

    const QDate first(m_year, m_month, 1);
    QDate start = first;
    while (start.dayOfWeek() != 1) start = start.addDays(1); // first Monday inside month
    // if month starts after Monday and we skipped into month, ok (sunday excluded)

    QDate last(m_year, m_month, first.daysInMonth());
    while (last.dayOfWeek() != 6) last = last.addDays(1); // extend to Saturday

    int row = 0;
    int col = 0;

    for (QDate d = start; d <= last; d = d.addDays(1)) {
        if (d.dayOfWeek() == 7) continue; // skip Sunday
        col = (d.dayOfWeek() - 1); // Monday=0 .. Saturday=5

        if (col == 0 && d != start) row++;

        auto* cell = new DayCell(d, m_gridHost);

        // preview text inside cell: simple status
        const auto it = m_plan.constFind(d);
        if (it == m_plan.cend() || it->isEmpty()) {
            cell->setPreviewText(QString());
        } else {
            QStringList lines;
            for (auto v = it->cbegin(); v != it->cend(); ++v) {
                const QString line = compactPlanLine(v.key(), v.value());
                if (!line.isEmpty()) lines << line;
                if (lines.size() >= 3) break;
            }
            cell->setPreviewText(lines.join("\n"));
        }

        cell->setCurrentDate(d == QDate::currentDate());
        m_grid->addWidget(cell, row, col);

        // hover handling
        cell->installEventFilter(this);
    }

    // make columns equal stretch
    for (int c=0;c<6;++c) m_grid->setColumnStretch(c, 1);
}

bool PlanningPage::event(QEvent* e)
{
    // keep editor centered on resize
    if (e->type() == QEvent::Resize) {
        if (m_editor && m_editor->isVisible()) {
            // if we're mid-animation, let it finish; otherwise snap to the new target rect
            const bool animRunning = (m_editorAnimGroup && m_editorAnimGroup->state() == QAbstractAnimation::Running);
            if (!animRunning) m_editor->setGeometry(editorTargetRect());
        }
    } else if (e->type() == QEvent::WindowDeactivate || e->type() == QEvent::Hide || e->type() == QEvent::Leave) {
        m_hoverTimer.stop();
        m_hoverDate = QDate();
        hidePreview();
    }
    return QWidget::event(e);
}

void PlanningPage::hideEvent(QHideEvent* e)
{
    m_hoverTimer.stop();
    m_hoverDate = QDate();
    hidePreview();
    QWidget::hideEvent(e);
}

void PlanningPage::showEvent(QShowEvent* e)
{
    hidePreview();
    QWidget::showEvent(e);
}

bool PlanningPage::eventFilter(QObject* watched, QEvent* ev)
{
    auto* cell = dynamic_cast<DayCell*>(watched);
    if (!cell) return QWidget::eventFilter(watched, ev);

    if (m_editor && m_editor->isVisible()) {
        if (ev->type() == QEvent::Enter || ev->type() == QEvent::Leave) {
            m_hoverTimer.stop();
            m_hoverDate = QDate();
            hidePreview();
        }
        if (ev->type() == QEvent::MouseButtonPress) {
            auto* me = static_cast<QMouseEvent*>(ev);
            if (me->button() == Qt::LeftButton) {
                openEditorFor(cell->date());
                return true;
            }
        }
        return QWidget::eventFilter(watched, ev);
    }

    if (ev->type() == QEvent::Enter) {
        m_hoverDate = cell->date();
        m_hoverTimer.start();
    } else if (ev->type() == QEvent::Leave) {
        const QPoint gp = QCursor::pos();
        const QRect globalRect(cell->mapToGlobal(QPoint(0,0)), cell->size());
        if (!globalRect.adjusted(-2,-2,2,2).contains(gp)) {
            m_hoverTimer.stop();
            m_hoverDate = QDate();
            QTimer::singleShot(40, this, [this, cell]() {
                const QRect checkRect(cell->mapToGlobal(QPoint(0,0)), cell->size());
                if (!checkRect.adjusted(-2,-2,2,2).contains(QCursor::pos())) hidePreview();
            });
        }
    } else if (ev->type() == QEvent::MouseButtonPress) {
        auto* me = static_cast<QMouseEvent*>(ev);
        if (me->button() == Qt::LeftButton) {
            m_hoverTimer.stop();
            hidePreview();
            openEditorFor(cell->date());
            return true;
        }
    }
    return QWidget::eventFilter(watched, ev);
}

void PlanningPage::showPreviewFor(const QDate& d)
{
    if (!d.isValid()) return;
    if (!isVisible() || !window() || !window()->isActiveWindow()) {
        hidePreview();
        return;
    }
    if (QApplication::activeModalWidget()) {
        hidePreview();
        return;
    }
    if (m_editor && m_editor->isVisible()) {
        hidePreview();
        return;
    }
    if (m_preview && m_preview->parentWidget() != window()) {
        m_preview->setParent(window(), Qt::Tool | Qt::FramelessWindowHint);
    }

    DayCell* anchorCell = nullptr;
    for (QObject* obj : m_gridHost->children()) {
        if (auto* w = dynamic_cast<DayCell*>(obj)) {
            if (w->date() == d) {
                anchorCell = w;
                break;
            }
        }
    }
    if (!anchorCell || !anchorCell->isVisible()) {
        hidePreview();
        return;
    }
    const QPoint gp = QCursor::pos();
    const QRect globalRect(anchorCell->mapToGlobal(QPoint(0,0)), anchorCell->size());
    if (!globalRect.adjusted(-2,-2,2,2).contains(gp)) {
        hidePreview();
        return;
    }

    m_previewTitle->setText(QString("%1.%2.%3 - %4")
        .arg(d.day(),2,10,QChar('0'))
        .arg(d.month(),2,10,QChar('0'))
        .arg(d.year()%100,2,10,QChar('0'))
        .arg(uaWeekday(d.dayOfWeek())));

    const auto it = m_plan.constFind(d);
    if (it == m_plan.cend() || it->isEmpty()) {
        m_previewBody->setText(QString::fromUtf8("Запланованих робіт нема"));
    } else {
        QStringList lines;
        for (auto v = it->cbegin(); v != it->cend(); ++v) {
            const QString txt = v.value().trimmed();
            if (txt.isEmpty()) continue;
            lines << QString("%1:00 — %2").arg(v.key(),2,10,QChar('0')).arg(txt);
            if (lines.size() >= 3) break;
        }
        if (lines.isEmpty()) m_previewBody->setText(QString::fromUtf8("Запланованих робіт нема"));
        else m_previewBody->setText(lines.join("\n"));
    }

    m_preview->adjustSize();

    QPoint pos;
    bool anchored = false;
    if (anchorCell) {
        const QRect cellRect = anchorCell->rect();
        const QPoint globalBottomLeft = anchorCell->mapToGlobal(QPoint(8, cellRect.height() + 10));
        pos = QPoint(globalBottomLeft.x(), globalBottomLeft.y());
        anchored = true;
    }

    if (!anchored) {
        const QRect vp = m_scroll->viewport()->rect();
        const QPoint fallback = m_scroll->viewport()->mapToGlobal(QPoint(24, 24));
        pos = QPoint(fallback.x(), fallback.y());
    }

    QScreen* screen = QGuiApplication::screenAt(QCursor::pos());
    if (!screen && window() && window()->windowHandle()) screen = window()->windowHandle()->screen();
    if (!screen) screen = QApplication::primaryScreen();
    const QRect avail = screen ? screen->availableGeometry() : QRect(0, 0, 1920, 1080);
    pos.setX(std::max(avail.left() + 8, std::min(pos.x(), avail.right() - m_preview->width() - 8)));
    pos.setY(std::max(avail.top() + 8, std::min(pos.y(), avail.bottom() - m_preview->height() - 8)));

    m_preview->move(pos);
    m_preview->show();
    m_preview->raise();
}

void PlanningPage::hidePreview()
{
    if (m_preview && m_preview->isVisible()) m_preview->hide();
}

void PlanningPage::openEditorFor(const QDate& d)
{
    if (!d.isValid()) return;
    m_hoverTimer.stop();
    m_hoverDate = QDate();
    hidePreview();
    m_editDate = d;

    // select cell visual
    // NOTE: DayCell lives in an anonymous namespace and does NOT have Q_OBJECT,
    // so QObject::findChildren<DayCell*>() is not allowed (Qt enforces Q_OBJECT).
    // Iterate over direct children and use RTTI instead.
    for (QObject* obj : m_gridHost->children()) {
        if (auto* w = dynamic_cast<DayCell*>(obj)) {
            w->setSelected(w->date() == d);
        }
    }

    // load data
    const auto it = m_plan.constFind(d);
    for (auto& r : m_rows) r.edit->clear();
    if (it != m_plan.cend()) {
        for (auto v = it->cbegin(); v != it->cend(); ++v) {
            const int hour = v.key();
            for (auto& r : m_rows) {
                if (r.timeLabel->text().startsWith(QString("%1").arg(hour,2,10,QChar('0')))) {
                    r.edit->setText(v.value());
                    break;
                }
            }
        }
    }

    updateEditorHeader();

    // animated open (expand + fade-in)
    animateEditorOpen();

    // focus first field
    if (!m_rows.isEmpty()) m_rows.first().edit->setFocus(Qt::TabFocusReason);
    hidePreview();
}

void PlanningPage::closeEditor(bool save)
{
    if (!m_editor || !m_editor->isVisible()) return;

    // fast hide path (used while rebuilding UI/month)
    if (!save) {
        if (m_editorAnimGroup) m_editorAnimGroup->stop();
        if (m_editorOpacity) m_editorOpacity->setOpacity(0.0);
        m_editor->hide();
        m_editDate = QDate();
        return;
    }

    if (save && m_editDate.isValid()) {
        QMap<int, QString> day;
        for (auto& r : m_rows) {
            const QString t = r.timeLabel->text();
            const int hour = t.left(2).toInt();
            const QString txt = r.edit->text().trimmed();
            if (!txt.isEmpty()) day[hour] = txt;
        }
        if (day.isEmpty()) m_plan.remove(m_editDate);
        else m_plan[m_editDate] = day;
    }


    // persist to DB
    if (m_repo && m_editDate.isValid()) {
        m_repo->setDayMap(m_editDate, m_plan.value(m_editDate));
    }

    animateEditorClose(false);
    m_editDate = QDate();

    // refresh per-cell preview line
    for (QObject* obj : m_gridHost->children()) {
        auto* w = dynamic_cast<DayCell*>(obj);
        if (!w) continue;

        const QDate cd = w->date();
        const auto it = m_plan.constFind(cd);
        if (it == m_plan.cend() || it->isEmpty()) {
            w->setPreviewText(QString());
        } else {
            QStringList lines;
            for (auto v = it->cbegin(); v != it->cend(); ++v) {
                const QString line = compactPlanLine(v.key(), v.value());
                if (!line.isEmpty()) lines << line;
                if (lines.size() >= 3) break;
            }
            w->setPreviewText(lines.join("\n"));
        }
        w->setCurrentDate(w->date() == QDate::currentDate());
    }
}

void PlanningPage::updateEditorHeader()
{
    if (!m_editDate.isValid()) return;
    m_editorDate->setText(QString("%1.%2.%3")
        .arg(m_editDate.day(),2,10,QChar('0'))
        .arg(m_editDate.month(),2,10,QChar('0'))
        .arg(m_editDate.year()%100,2,10,QChar('0')));

    const auto it = m_plan.constFind(m_editDate);
    bool has=false;
    if (it != m_plan.cend()) {
        for (auto v = it->cbegin(); v != it->cend(); ++v) if (!v.value().trimmed().isEmpty()) { has=true; break; }
    }
    m_editorInfo->setText(has ? QString::fromUtf8("Є заплановані роботи") : QString::fromUtf8("Запланованих робіт нема"));
}
void PlanningPage::checkReminders()
{
    const QDate today = QDate::currentDate();
    if (m_reminderDay != today) {
        m_reminderDay = today;
        m_remindedKeys.clear();
    }

    const QDateTime now = QDateTime::currentDateTime();

    const auto itDay = m_plan.constFind(today);
    if (itDay == m_plan.cend()) return;

    struct Hit {
        int hour;
        QString text;
        qint64 secsTo;
        QString key;
    };
    QVector<Hit> hits;

    for (auto it = itDay->cbegin(); it != itDay->cend(); ++it) {
        const int hour = it.key();
        const QString text = it.value().trimmed();
        if (text.isEmpty()) continue;

        const QDateTime scheduled(today, QTime(hour, 0));
        if (!scheduled.isValid()) continue;

        const qint64 secsTo = now.secsTo(scheduled);
        if (secsTo <= 15 * 60 && secsTo >= 0) {
            const QString key = QString("%1|%2")
                                    .arg(today.toString(Qt::ISODate))
                                    .arg(hour, 2, 10, QChar('0'));
            if (m_remindedKeys.contains(key)) continue;
            m_remindedKeys.insert(key);
            hits.push_back({hour, text, secsTo, key});
        }
    }

    if (hits.isEmpty()) return;

    // Sound once per group
#if CS_HAS_MULTIMEDIA
    if (m_reminderSound && m_reminderSound->status() == QSoundEffect::Ready)
        m_reminderSound->play();
    else
        QApplication::beep();
#else
    QApplication::beep();
#endif

    std::sort(hits.begin(), hits.end(), [](const Hit& a, const Hit& b){ return a.hour < b.hour; });

    QStringList lines;
    for (const auto& h : hits) {
        const qint64 mins = qMax<qint64>(0, (h.secsTo + 59) / 60);
        lines << QString::fromUtf8("• Через %1 хв (о %2:00): %3")
                     .arg(mins)
                     .arg(h.hour, 2, 10, QChar('0'))
                     .arg(h.text);
    }

    const QString title = QString::fromUtf8("Нагадування про запис");
    

    const QString msg = lines.join("\n");

    // Non-modal notification (does not block UI). Auto-closes.
    auto* box = new QMessageBox(QMessageBox::Warning, title, msg, QMessageBox::Ok, this);
    box->setWindowModality(Qt::NonModal);
    box->setAttribute(Qt::WA_DeleteOnClose, true);
    box->show();

    QTimer::singleShot(12000, box, &QMessageBox::close);
}

