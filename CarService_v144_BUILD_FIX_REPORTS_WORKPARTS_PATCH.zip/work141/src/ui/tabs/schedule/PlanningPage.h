#pragma once

#include <QWidget>
#include <QDate>
#include <QMap>
#include <QSet>
#include <QTimer>
#include <QDate>
#include <QTimer>
#include <QVector>
#include <QRect>
class QHideEvent;
class QShowEvent;

class QComboBox;
class QSpinBox;
class QPushButton;
class QScrollArea;
class QGridLayout;
class QLabel;
class QSoundEffect;
class QFrame;
class QLineEdit;
class QGraphicsOpacityEffect;
class QPropertyAnimation;
class QParallelAnimationGroup;
class PlanningRepository;

class PlanningPage : public QWidget
{
    Q_OBJECT
public:
    explicit PlanningPage(QWidget* parent=nullptr);

protected:
    bool eventFilter(QObject* watched, QEvent* event) override;
    bool event(QEvent* event) override;
    void hideEvent(QHideEvent* event) override;
    void showEvent(QShowEvent* event) override;

private:
    struct SlotRow {
        QLabel* timeLabel{};
        QLineEdit* edit{};
    };

    void buildUi();
    void rebuildGrid();
    void setMonth(const QDate& anyDayInMonth);
    void openEditorFor(const QDate& d);
    void closeEditor(bool save);
    void updateEditorHeader();

    // editor animation
    QRect editorTargetRect() const;
    void animateEditorOpen();
    void animateEditorClose(bool hideOnly);

    // hover preview
    void showPreviewFor(const QDate& d);
    void hidePreview();
    void checkReminders();

    PlanningRepository* m_repo{};

    // data (cached from DB)
    QMap<QDate, QMap<int, QString>> m_plan; // date -> (hour -> text)

    // current month
    int m_year = 0;
    int m_month = 0;

    // top controls
    QPushButton* m_btnPrev{};
    QPushButton* m_btnNext{};
    QLabel* m_lblMonthTitle{};
    QComboBox* m_cbMonth{};
    QSpinBox* m_spYear{};
    QPushButton* m_btnToday{};

    // calendar grid
    QScrollArea* m_scroll{};
    QWidget* m_gridHost{};
    QGridLayout* m_grid{};

    // hover preview popup (tool window)
    QFrame* m_preview{};
    QLabel* m_previewTitle{};
    QLabel* m_previewBody{};
    QLabel* m_previewHint{};
    QTimer m_hoverTimer;
    QDate m_hoverDate;

    // reminders
    QTimer m_reminderTimer;
    QSoundEffect* m_reminderSound{};
    QSet<QString> m_remindedKeys;
    QDate m_reminderDay;

    // editor overlay
    QFrame* m_editor{};
    QLabel* m_editorDate{};
    QPushButton* m_btnClear{};
    QPushButton* m_btnClose{};
    QLabel* m_editorInfo{};
    QVector<SlotRow> m_rows;
    QDate m_editDate;

    // animation helpers (owned by m_editor)
    QGraphicsOpacityEffect* m_editorOpacity{};
    QPropertyAnimation* m_editorGeomAnim{};
    QPropertyAnimation* m_editorOpacityAnim{};
    QParallelAnimationGroup* m_editorAnimGroup{};
};
