#include "ui/tabs/schedule/PlanningRepository.h"

#include "infrastructure/db/sqlite/Db.h"

#include <QSqlQuery>
#include <QRegularExpression>

namespace {

static QString toIso(const QDate& d) { return d.toString(Qt::ISODate); }

static QString serializeDay(const QMap<int, QString>& map)
{
    QStringList lines;
    for (auto it = map.cbegin(); it != map.cend(); ++it) {
        const int h = it.key();
        const QString t = it.value().trimmed();
        if (t.isEmpty()) continue;
        lines << QString("%1:00 %2").arg(h, 2, 10, QChar('0')).arg(t);
    }
    return lines.join("\n");
}

static QMap<int, QString> parseDay(const QString& note)
{
    QMap<int, QString> out;
    const QStringList lines = note.split('\n');
    static QRegularExpression re(R"(^\s*(\d{1,2})\s*[:\.]\s*(\d{2})\s*(.*)$)");
    for (const QString& ln : lines) {
        const QString s = ln.trimmed();
        if (s.isEmpty()) continue;
        const auto m = re.match(s);
        if (!m.hasMatch()) continue;
        const int h = m.captured(1).toInt();
        QString txt = m.captured(3).trimmed();
        if (h < 0 || h > 23) continue;
        if (txt.isEmpty()) continue;
        if (!out.contains(h)) out.insert(h, txt);
    }
    return out;
}

} // namespace

QString PlanningRepository::getNote(const QDate& day) const
{
    if (!day.isValid()) return {};
    QSqlQuery q(Database::db());
    q.prepare("SELECT note FROM planning_calendar WHERE day=?");
    q.addBindValue(toIso(day));
    if (!q.exec()) return {};
    if (q.next()) return q.value(0).toString();
    return {};
}

void PlanningRepository::setNote(const QDate& day, const QString& note) const
{
    if (!day.isValid()) return;
    const QString n = note.trimmed();
    QSqlQuery q(Database::db());
    if (n.isEmpty()) {
        q.prepare("DELETE FROM planning_calendar WHERE day=?");
        q.addBindValue(toIso(day));
        q.exec();
        return;
    }
    q.prepare(
        "INSERT INTO planning_calendar(day,note) VALUES(?,?) "
        "ON CONFLICT(day) DO UPDATE SET note=excluded.note"
    );
    q.addBindValue(toIso(day));
    q.addBindValue(n);
    q.exec();
}

QMap<int, QString> PlanningRepository::getDayMap(const QDate& day) const
{
    return parseDay(getNote(day));
}

void PlanningRepository::setDayMap(const QDate& day, const QMap<int, QString>& map) const
{
    setNote(day, serializeDay(map));
}
