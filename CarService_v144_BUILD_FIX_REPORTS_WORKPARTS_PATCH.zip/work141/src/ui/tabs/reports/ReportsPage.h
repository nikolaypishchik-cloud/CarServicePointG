#pragma once

#include <QWidget>

class QDateEdit;
class QLabel;
class QTabWidget;
class QTableWidget;
class QPushButton;

class ReportsPage : public QWidget
{
    Q_OBJECT
public:
    explicit ReportsPage(QWidget* parent=nullptr);

public slots:
    void refresh();

private slots:
    void exportActivePdf();

private:
    enum class ReportTab {
        Period = 0,
        Parts = 1,
        Outsource = 2,
        Expenses = 3,
        Payroll = 4
    };

    void buildUi();
    void refreshActiveTab();
    void refreshPeriod();
    void refreshParts();
    void refreshOutsource();
    void refreshExpenses();
    void refreshPayroll();

    void updateStats(const QStringList& lines);
    void setTableBaseStyle(QTableWidget* table);
    void exportTablePdf(QTableWidget* table, const QString& title, const QString& subtitle, const QString& suggestedName);
    void exportPeriodPdf();
    void exportPartsPdf();
    void exportOutsourcePdf();
    void exportExpensesPdf();
    void exportPayrollPdf();

    ReportTab activeTab() const;

    QDateEdit* m_from = nullptr;
    QDateEdit* m_to = nullptr;
    QLabel* m_statsLabel = nullptr;
    QLabel* m_descLabel = nullptr;
    QTabWidget* m_tabs = nullptr;
    QPushButton* m_pdfButton = nullptr;

    QTableWidget* m_periodTable = nullptr;
    QTableWidget* m_partsTable = nullptr;
    QTableWidget* m_outsourceTable = nullptr;
    QTableWidget* m_expensesTable = nullptr;
    QTableWidget* m_payrollTable = nullptr;
};
