#include "ui/tabs/reports/ReportsPage.h"

#include "infrastructure/db/sqlite/Db.h"
#include "core/util/FormatUtils.h"
#include "ui/common/dialogs/OrderDialog.h"

#include <QAbstractItemView>
#include <algorithm>
#include <QDate>
#include <QDateEdit>
#include <QDesktopServices>
#include <QDateTime>
#include <QDir>
#include <QFont>
#include <QHeaderView>
#include <QJsonDocument>
#include <QJsonObject>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QMap>
#include <QMargins>
#include <QPainter>
#include <QPageSize>
#include <QPdfWriter>
#include <QPushButton>
#include <QRegularExpression>
#include <QSqlError>
#include <QSqlQuery>
#include <QStandardPaths>
#include <QTabWidget>
#include <QTableWidget>
#include <QTextOption>
#include <QUrl>
#include <QVBoxLayout>
#include <QtMath>

namespace {

int partServiceMatchScore(const QString& serviceTitle, const QString& partName);

QString makeAutoPdfPath(const QString& baseName)
{
    const QString docs = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation);
    QString dirPath = docs + QStringLiteral("/CarService_PDF");
    QDir dir;
    dir.mkpath(dirPath);

    QString safeBase = baseName.trimmed();
    if (safeBase.isEmpty()) safeBase = QStringLiteral("report");
    if (safeBase.endsWith(QStringLiteral(".pdf"), Qt::CaseInsensitive)) {
        safeBase.chop(4);
    }
    safeBase.replace(QRegularExpression(QStringLiteral(R"([\/:*?"<>|]+)")), QStringLiteral("_"));
    safeBase.replace(' ', '_');

    const QString stamp = QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd_HHmmss"));
    return dirPath + QStringLiteral("/") + safeBase + QStringLiteral("_") + stamp + QStringLiteral(".pdf");
}

QDate parseFlexibleDate(QString value)
{
    value = value.trimmed();
    if (value.isEmpty()) return {};
    const QString raw10 = value.left(10);
    const QStringList formats = {
        QStringLiteral("yyyy-MM-dd"), QStringLiteral("dd.MM.yy"), QStringLiteral("dd.MM.yyyy"),
        QStringLiteral("yy-MM-dd"), QStringLiteral("yyyy/MM/dd"), QStringLiteral("dd/MM/yyyy")
    };
    for (const auto& f : formats) {
        const QDate d = QDate::fromString(raw10, f);
        if (d.isValid() && d.year() >= 2000 && d.year() <= 2100) return d;
    }
    const auto iso = QDate::fromString(raw10, Qt::ISODate);
    if (iso.isValid() && iso.year() >= 2000 && iso.year() <= 2100) return iso;
    return {};
}

QString displayDate(const QString& raw, const QString& fallback = {})
{
    const QDate d = parseFlexibleDate(raw);
    if (d.isValid()) return d.toString("dd.MM.yy");
    const QDate fb = parseFlexibleDate(fallback);
    if (fb.isValid()) return fb.toString("dd.MM.yy");
    const QString src = raw.trimmed().isEmpty() ? fallback.trimmed() : raw.trimmed();
    return src.left(10);
}

QDate effectiveDate(const QString& raw, const QString& fallback = {})
{
    const QDate d = parseFlexibleDate(raw);
    if (d.isValid()) return d;
    return parseFlexibleDate(fallback);
}

QString dmy(const QString& iso)
{
    return displayDate(iso);
}

QString money0(double value)
{
    return FormatUtils::money(value, 0);
}

int mmToPx(const QPaintDevice* dev, double mm)
{
    return qRound(mm * dev->logicalDpiX() / 25.4);
}

struct PdfTheme {
    int left = 0;
    int right = 0;
    int top = 0;
    int bottom = 0;
    int pageWidth = 0;
    int pageHeight = 0;
    int contentWidth = 0;
};

PdfTheme buildTheme(const QPdfWriter& pdf)
{
    PdfTheme t;
    t.left = mmToPx(&pdf, 20);
    t.right = pdf.width() - mmToPx(&pdf, 10);
    t.top = mmToPx(&pdf, 15);
    t.bottom = pdf.height() - mmToPx(&pdf, 15);
    t.pageWidth = pdf.width();
    t.pageHeight = pdf.height();
    t.contentWidth = t.right - t.left;
    return t;
}

QFont titleFont(int pt, bool bold = true)
{
    QFont f("Times New Roman");
    f.setPointSize(pt);
    f.setBold(bold);
    return f;
}

QFont bodyFont(int pt, bool bold = false)
{
    QFont f("Arial");
    f.setPointSize(pt);
    f.setBold(bold);
    return f;
}

void drawCenteredText(QPainter& p, const QRect& r, const QString& txt, const QFont& f)
{
    p.setFont(f);
    p.drawText(r, Qt::AlignCenter | Qt::TextWordWrap, txt);
}

void drawLeftText(QPainter& p, const QRect& r, const QString& txt, const QFont& f)
{
    p.setFont(f);
    p.drawText(r, Qt::AlignLeft | Qt::AlignVCenter | Qt::TextWordWrap, txt);
}

int wrappedHeight(QPainter& p, const QString& text, const QFont& font, int width, int minHeight = 24)
{
    p.setFont(font);
    QRect br = p.boundingRect(QRect(0, 0, width, 2000), Qt::TextWordWrap | Qt::AlignLeft | Qt::AlignVCenter, text);
    return qMax(minHeight, br.height() + 10);
}

void drawCell(QPainter& p, const QRect& rect, const QString& text, const QFont& font,
              Qt::Alignment align = Qt::AlignLeft | Qt::AlignVCenter,
              const QColor& fill = Qt::white, qreal penWidth = 0.5)
{
    p.save();
    p.setPen(QPen(Qt::black, penWidth));
    p.fillRect(rect, fill);
    p.drawRect(rect);
    p.setFont(font);
    QRect inner = rect.adjusted(6, 4, -6, -4);
    p.drawText(inner, align | Qt::TextWordWrap, text);
    p.restore();
}

struct PeriodPdfRow {
    QString date;
    QString orderNumber;
    QString car;
    QString plate;
    QString workTitle;
    QString partName;
    QString qty;
    double partsPrice = 0.0;
    double added = 0.0;
    double worksPrice = 0.0;
    double total = 0.0;
};

struct PartPdfRow {
    QString store;
    QString date;
    QString orderNumber;
    QString name;
    QString oem;
    double purchase = 0.0;
    double added = 0.0;
    QString qty;
    double clientPrice = 0.0;
};

struct OutsourcePdfRow {
    QString company;
    QString date;
    QString orderNumber;
    QString partName;
    double repairCost = 0.0;
    double clientPrice = 0.0;
};

struct PayrollOrderRow {
    QString dateStart;
    QString dateEnd;
    QString orderNumber;
    QString car;
    QString engine;
    QString works;
    double amount = 0.0;
    double masterAmount = 0.0;
};

struct PayrollMasterPdf {
    QString masterId;
    QString masterName;
    double percent = 0.0;
    QList<PayrollOrderRow> orders;
    int ordersCount = 0;
    double worksTotal = 0.0;
    double accrued = 0.0;
};

struct PayrollRow {
    QString masterId;
    QString masterName;
    int ordersCount = 0;
    double baseSum = 0.0;
    double percent = 0.0;
    double accrued = 0.0;
};


struct AdminSalaryTotals {
    double margin = 0.0;
    double clientTotal = 0.0;
    double purchaseTotal = 0.0;
    double partsQty = 0.0;
    int ordersCount = 0;
};

QString adminSalarySourceLabel(const QString& key)
{
    if (key == QStringLiteral("client_total")) return QString::fromUtf8("Повна ціна для клієнта");
    if (key == QStringLiteral("purchase_total")) return QString::fromUtf8("Ціна закупки");
    return QString::fromUtf8("Доданий % (маржа)");
}

QMap<QString, QString> loadAdminSalarySources()
{
    QMap<QString, QString> out;
    const auto doc = QJsonDocument::fromJson(Database::getSetting(QStringLiteral("settings.staff.admin_salary_sources"), QStringLiteral("{}")).toString().toUtf8());
    if (!doc.isObject()) return out;
    const auto obj = doc.object();
    for (auto it = obj.begin(); it != obj.end(); ++it) out.insert(it.key(), it.value().toString(QStringLiteral("margin")));
    return out;
}

AdminSalaryTotals collectAdminSalaryTotals(const QString& df, const QString& dt)
{
    AdminSalaryTotals t;

    QSqlQuery parts(Database::db());
    parts.prepare(
        "SELECT "
        "COALESCE(SUM(COALESCE(p.purchase_amount, CASE WHEN COALESCE(p.purchase_price,0)>0 THEN COALESCE(p.purchase_price,0)*COALESCE(p.qty,1) ELSE COALESCE(p.amount,0) END)),0), "
        "COALESCE(SUM(COALESCE(p.amount,0)),0), "
        "COALESCE(SUM(COALESCE(p.amount,0) - COALESCE(p.purchase_amount, CASE WHEN COALESCE(p.purchase_price,0)>0 THEN COALESCE(p.purchase_price,0)*COALESCE(p.qty,1) ELSE COALESCE(p.amount,0) END)),0) "
        "FROM work_order_parts p "
        "JOIN work_orders wo ON wo.number = p.order_number "
        "WHERE date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) >= date(?) "
        "AND date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) <= date(?) "
        "AND wo.status='closed'");
    parts.addBindValue(df);
    parts.addBindValue(dt);
    if (parts.exec() && parts.next()) {
        t.purchaseTotal += parts.value(0).toDouble();
        t.clientTotal += parts.value(1).toDouble();
        t.margin += parts.value(2).toDouble();
    }

    QSqlQuery partsQtyQ(Database::db());
    partsQtyQ.prepare(
        "SELECT COALESCE(SUM(COALESCE(p.qty,1)),0) "
        "FROM work_order_parts p "
        "JOIN work_orders wo ON wo.number = p.order_number "
        "WHERE date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) >= date(?) "
        "AND date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) <= date(?) "
        "AND wo.status='closed'");
    partsQtyQ.addBindValue(df);
    partsQtyQ.addBindValue(dt);
    if (partsQtyQ.exec() && partsQtyQ.next()) {
        t.partsQty = partsQtyQ.value(0).toDouble();
    }

    QSqlQuery ordersQ(Database::db());
    ordersQ.prepare(
        "SELECT COUNT(DISTINCT wo.number) "
        "FROM work_orders wo "
        "WHERE date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) >= date(?) "
        "AND date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) <= date(?) "
        "AND wo.status='closed'");
    ordersQ.addBindValue(df);
    ordersQ.addBindValue(dt);
    if (ordersQ.exec() && ordersQ.next()) {
        t.ordersCount = ordersQ.value(0).toInt();
    }

    QSqlQuery outs(Database::db());
    outs.prepare(
        "SELECT COALESCE(SUM(company_price),0), COALESCE(SUM(client_price),0), COALESCE(SUM(client_price - company_price),0) "
        "FROM outsource_jobs "
        "WHERE date(substr(sent_date,1,10)) >= date(?) AND date(substr(sent_date,1,10)) <= date(?)");
    outs.addBindValue(df);
    outs.addBindValue(dt);
    if (outs.exec() && outs.next()) {
        t.purchaseTotal += outs.value(0).toDouble();
        t.clientTotal += outs.value(1).toDouble();
        t.margin += outs.value(2).toDouble();
    }
    return t;
}

double adminSalaryBaseForSource(const AdminSalaryTotals& totals, const QString& source)
{
    if (source == QStringLiteral("client_total")) return totals.clientTotal;
    if (source == QStringLiteral("purchase_total")) return totals.purchaseTotal;
    return totals.margin;
}

QList<PayrollRow> collectPayrollRows(const QString& df, const QString& dt)
{
    QList<PayrollRow> rows;
    const auto masters = Database::masters(true);
    const auto percents = Database::payrollPercents();

    const auto adminSources = loadAdminSalarySources();
    const AdminSalaryTotals adminTotals = collectAdminSalaryTotals(df, dt);

    for (const auto& m : masters) {
        PayrollRow row;
        row.masterId = m.id;
        row.masterName = m.role == QStringLiteral("admin") ? QString::fromUtf8("Адмін: %1").arg(m.name) : m.name;
        row.percent = (m.role == QStringLiteral("admin")) ? m.adminPercent : percents.value(m.id, 0.0);

        if (m.role == QStringLiteral("admin")) {
            const QString source = adminSources.value(m.id, QStringLiteral("margin"));
            row.ordersCount = 1;
            row.baseSum = adminSalaryBaseForSource(adminTotals, source);
            row.accrued = qRound64(row.baseSum * row.percent / 100.0);
            rows.append(row);
            continue;
        }

        QSqlQuery q(Database::db());
        q.prepare(
            "SELECT wo.number, COALESCE(SUM(COALESCE(s.amount,0) * COALESCE(sm.share_percent,0) / 100.0), 0) AS share_raw, "
            "COALESCE(wo.discount,0), COALESCE(wo.works_sum,0) "
            "FROM work_orders wo "
            "JOIN work_order_services s ON s.order_number = wo.number "
            "JOIN service_masters sm ON sm.service_id = s.id "
            "WHERE wo.status='closed' AND sm.master_id=? "
            "AND date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) >= date(?) "
            "AND date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) <= date(?) "
            "GROUP BY wo.number "
            "ORDER BY wo.number ASC");
        q.addBindValue(m.id);
        q.addBindValue(df);
        q.addBindValue(dt);

        if (q.exec()) {
            while (q.next()) {
                row.ordersCount += 1;
                const double shareRaw = q.value(1).toDouble();
                const double discountRaw = q.value(2).toDouble();
                const double worksTotal = q.value(3).toDouble();
                const double discountPct = FormatUtils::inferDiscountPercent(discountRaw, worksTotal);
                row.baseSum += qMax(0.0, shareRaw * (1.0 - discountPct / 100.0));
            }
        }

        row.accrued = qRound64(row.baseSum * row.percent / 100.0);
        rows.append(row);
    }

    return rows;
}

QList<PeriodPdfRow> collectPeriodPdfRows(const QString& df, const QString& dt,
                                         double& partsTotal, double& worksTotal, double& partsMargin,
                                         double& outsourceMargin, double& salaryTotal, double& expensesTotal)
{
    QList<PeriodPdfRow> out;
    partsTotal = worksTotal = partsMargin = outsourceMargin = salaryTotal = expensesTotal = 0.0;

    struct ServiceRow { int id = 0; QString title; double amount = 0.0; };
    struct PartRow { int id = 0; int serviceId = 0; QString name; QString qty; double amount = 0.0; double added = 0.0; bool assigned = false; };

    QSqlQuery ord(Database::db());
    ord.prepare(
        "SELECT number, car, plate, substr(COALESCE(NULLIF(closed_at,''), opened_at),1,10), COALESCE(works_sum,0) "
        "FROM work_orders "
        "WHERE date(COALESCE(NULLIF(closed_at,''), opened_at)) >= date(?) "
        "AND date(COALESCE(NULLIF(closed_at,''), opened_at)) <= date(?) "
        "AND status='closed' "
        "ORDER BY date(COALESCE(NULLIF(closed_at,''), opened_at)) ASC, number ASC");
    ord.addBindValue(df);
    ord.addBindValue(dt);
    if (ord.exec()) {
        while (ord.next()) {
            const QString orderNumber = ord.value(0).toString();
            const QString car = ord.value(1).toString();
            const QString plate = ord.value(2).toString();
            const QString orderDate = ord.value(3).toString();

            QList<ServiceRow> services;
            QSqlQuery qs(Database::db());
            qs.prepare(
                "SELECT id, COALESCE(title,''), COALESCE(amount,0) "
                "FROM work_order_services WHERE order_number=? ORDER BY id ASC");
            qs.addBindValue(orderNumber);
            if (qs.exec()) {
                while (qs.next()) {
                    ServiceRow s;
                    s.id = qs.value(0).toInt();
                    s.title = qs.value(1).toString();
                    s.amount = qs.value(2).toDouble();
                    services.append(s);
                }
            }

            QList<PartRow> parts;
            QSqlQuery qp(Database::db());
            qp.prepare(
                "SELECT id, COALESCE(name,''), COALESCE(qty,0), COALESCE(amount,0), "
                "COALESCE(amount,0) - COALESCE(purchase_amount, CASE WHEN COALESCE(purchase_price,0)>0 THEN COALESCE(purchase_price,0)*COALESCE(qty,1) ELSE COALESCE(amount,0) END), "
                "COALESCE(service_id,0) "
                "FROM work_order_parts WHERE order_number=? ORDER BY id ASC");
            qp.addBindValue(orderNumber);
            if (qp.exec()) {
                while (qp.next()) {
                    const double qty = qp.value(2).toDouble();
                    PartRow pr;
                    pr.id = qp.value(0).toInt();
                    pr.name = qp.value(1).toString();
                    pr.qty = qty > 0.0 ? FormatUtils::smartQty(qty) : QString();
                    pr.amount = qp.value(3).toDouble();
                    pr.added = qp.value(4).toDouble();
                    pr.serviceId = qp.value(5).toInt();
                    parts.append(pr);
                }
            }

            if (services.isEmpty() && parts.isEmpty()) {
                PeriodPdfRow r;
                r.date = displayDate(orderDate);
                r.orderNumber = orderNumber;
                r.car = car;
                r.plate = plate;
                out.append(r);
                continue;
            }

            for (const ServiceRow& service : services) {
                QList<int> matched;

                for (int i = 0; i < parts.size(); ++i) {
                    if (parts[i].assigned) continue;
                    if (parts[i].serviceId > 0 && parts[i].serviceId == service.id) {
                        matched.append(i);
                    }
                }

                if (matched.isEmpty()) {
                    QList<QPair<int,int>> scored;
                    for (int i = 0; i < parts.size(); ++i) {
                        if (parts[i].assigned) continue;
                        const int score = partServiceMatchScore(service.title, parts[i].name);
                        if (score > 0) scored.append({score, i});
                    }
                    std::sort(scored.begin(), scored.end(), [](const auto& a, const auto& b){
                        if (a.first != b.first) return a.first > b.first;
                        return a.second < b.second;
                    });
                    for (const auto& pair : scored) matched.append(pair.second);
                }

                if (matched.isEmpty()) {
                    PeriodPdfRow r;
                    r.date = displayDate(orderDate);
                    r.orderNumber = orderNumber;
                    r.car = car;
                    r.plate = plate;
                    r.workTitle = service.title;
                    r.worksPrice = service.amount;
                    r.total = r.worksPrice;
                    out.append(r);
                    continue;
                }

                for (int k = 0; k < matched.size(); ++k) {
                    PartRow& part = parts[matched[k]];
                    part.assigned = true;

                    PeriodPdfRow r;
                    r.date = displayDate(orderDate);
                    r.orderNumber = orderNumber;
                    r.car = car;
                    r.plate = plate;
                    if (k == 0) {
                        r.workTitle = service.title;
                        r.worksPrice = service.amount;
                    }
                    r.partName = part.name;
                    r.qty = part.qty;
                    r.partsPrice = part.amount;
                    r.added = part.added;
                    r.total = r.partsPrice + r.worksPrice;
                    out.append(r);
                }
            }

            for (const PartRow& part : parts) {
                if (part.assigned) continue;
                PeriodPdfRow r;
                r.date = displayDate(orderDate);
                r.orderNumber = orderNumber;
                r.car = car;
                r.plate = plate;
                r.partName = part.name;
                r.qty = part.qty;
                r.partsPrice = part.amount;
                r.added = part.added;
                r.total = r.partsPrice;
                out.append(r);
            }
        }
    }

    QSqlQuery sums(Database::db());
    sums.prepare(
        "SELECT COALESCE(SUM(p.amount),0), "
        "COALESCE(SUM(COALESCE(p.amount,0) - COALESCE(p.purchase_amount, CASE WHEN COALESCE(p.purchase_price,0)>0 THEN COALESCE(p.purchase_price,0)*COALESCE(p.qty,1) ELSE COALESCE(p.amount,0) END)),0), "
        "COALESCE(SUM(wo.works_sum),0) "
        "FROM work_orders wo "
        "LEFT JOIN work_order_parts p ON p.order_number = wo.number "
        "WHERE date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) >= date(?) "
        "AND date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) <= date(?) "
        "AND wo.status='closed'");
    sums.addBindValue(df);
    sums.addBindValue(dt);
    if (sums.exec() && sums.next()) {
        partsTotal = sums.value(0).toDouble();
        partsMargin = sums.value(1).toDouble();
        worksTotal = sums.value(2).toDouble();
    }

    QSqlQuery outs(Database::db());
    outs.prepare(
        "SELECT COALESCE(SUM(client_price - company_price),0) "
        "FROM outsource_jobs "
        "WHERE date(substr(sent_date,1,10)) >= date(?) AND date(substr(sent_date,1,10)) <= date(?)");
    outs.addBindValue(df);
    outs.addBindValue(dt);
    if (outs.exec() && outs.next()) outsourceMargin = outs.value(0).toDouble();

    for (const auto& row : collectPayrollRows(df, dt)) salaryTotal += row.accrued;

    QSqlQuery ex(Database::db());
    ex.prepare(
        "SELECT COALESCE(SUM((COALESCE(elec_curr,0)-COALESCE(elec_prev,0))*COALESCE(elec_tariff,0) + COALESCE(cleaning,0) + COALESCE(heating,0) + COALESCE(rent,0) + COALESCE(amortization,0)+COALESCE(sw_opendatabot,0)+COALESCE(sw_tecalliance,0)),0) "
        "FROM expenses WHERE date(period_to) >= date(?) AND date(period_from) <= date(?)");
    ex.addBindValue(df);
    ex.addBindValue(dt);
    if (ex.exec() && ex.next()) expensesTotal = ex.value(0).toDouble();

    return out;
}

QString normalizeStoreForPdf(QString store)
{
    store = store.simplified();
    if (store.isEmpty()) return QString::fromUtf8("(без магазину)");

    store.replace(QChar(0x00A0), QLatin1Char(' '));
    store = store.simplified();

    const QString folded = store.toCaseFolded();
    if (folded == QString::fromUtf8("без магазину") || folded == QString::fromUtf8("(без магазину)") ||
        folded == QString::fromUtf8("без магазина") || folded == QString::fromUtf8("(без магазина)")) {
        return QString::fromUtf8("(без магазину)");
    }
    return store;
}

bool isMotorOilName(QString name)
{
    const QString folded = name.toCaseFolded().simplified();
    return folded.contains(QString::fromUtf8("масло"))
        || folded.contains(QString::fromUtf8("мастило"))
        || folded.contains(QStringLiteral("engine oil"))
        || folded.contains(QStringLiteral("motor oil"))
        || folded == QStringLiteral("oil");
}



QString foldForMatch(QString s)
{
    s = s.toCaseFolded();
    s.replace(QChar(0x0456), QChar(0x0438)); // і -> и
    s.replace(QChar(0x0457), QChar(0x0438)); // ї -> и
    s.replace(QChar(0x0454), QChar(0x0435)); // є -> е
    s.replace(QChar(0x0491), QChar(0x0433)); // ґ -> г
    s.replace(QChar(0x044b), QChar(0x0438)); // ы -> и
    s.replace(QChar(0x0451), QChar(0x0435)); // ё -> е
    s.replace(QRegularExpression(QStringLiteral(R"([^\p{L}\p{N}]+)")), QStringLiteral(" "));
    return s.simplified();
}

bool containsAnyRoot(const QString& text, const QStringList& roots)
{
    for (const QString& root : roots) {
        if (text.contains(root)) return true;
    }
    return false;
}

int overlapScore(const QString& a, const QString& b, const QStringList& roots)
{
    int score = 0;
    for (const QString& root : roots) {
        if (a.contains(root) && b.contains(root)) ++score;
    }
    return score;
}

int partServiceMatchScore(const QString& serviceTitle, const QString& partName)
{
    const QString s = foldForMatch(serviceTitle);
    const QString p = foldForMatch(partName);
    if (s.isEmpty() || p.isEmpty()) return 0;

    const bool sOil = containsAnyRoot(s, {QString::fromUtf8("масл"), QString::fromUtf8("мастил"), QStringLiteral("oil")});
    const bool pOil = containsAnyRoot(p, {QString::fromUtf8("масл"), QString::fromUtf8("мастил"), QStringLiteral("oil")});
    const bool sFilter = containsAnyRoot(s, {QString::fromUtf8("фильтр"), QString::fromUtf8("филтр"), QString::fromUtf8("фільтр")});
    const bool pFilter = containsAnyRoot(p, {QString::fromUtf8("фильтр"), QString::fromUtf8("филтр"), QString::fromUtf8("фільтр")});
    const bool sPads = containsAnyRoot(s, {QString::fromUtf8("колод")});
    const bool pPads = containsAnyRoot(p, {QString::fromUtf8("колод")});
    const bool sCaliper = containsAnyRoot(s, {QString::fromUtf8("супорт")});
    const bool pCaliper = containsAnyRoot(p, {QString::fromUtf8("супорт")});
    const bool sGenBelt = containsAnyRoot(s, {QString::fromUtf8("ремен"), QString::fromUtf8("генератор")});
    const bool pGenBelt = containsAnyRoot(p, {QString::fromUtf8("ремен"), QString::fromUtf8("генератор")});
    const bool sChain = containsAnyRoot(s, {QString::fromUtf8("цеп"), QString::fromUtf8("ланцюг"), QString::fromUtf8("грм")});
    const bool pChain = containsAnyRoot(p, {QString::fromUtf8("цеп"), QString::fromUtf8("ланцюг"), QString::fromUtf8("грм")});
    const bool sSilent = containsAnyRoot(s, {QString::fromUtf8("сайлент")});
    const bool pSilent = containsAnyRoot(p, {QString::fromUtf8("сайлент")});
    const bool sTip = containsAnyRoot(s, {QString::fromUtf8("наконеч"), QString::fromUtf8("шаров")});
    const bool pTip = containsAnyRoot(p, {QString::fromUtf8("наконеч"), QString::fromUtf8("шаров")});
    const bool sGasket = containsAnyRoot(s, {QString::fromUtf8("проклад"), QString::fromUtf8("гбц")});
    const bool pGasket = containsAnyRoot(p, {QString::fromUtf8("проклад"), QString::fromUtf8("гбц")});
    const bool sWires = containsAnyRoot(s, {QString::fromUtf8("провод"), QString::fromUtf8("зажиган"), QString::fromUtf8("запал")});
    const bool pWires = containsAnyRoot(p, {QString::fromUtf8("провод"), QString::fromUtf8("зажиган"), QString::fromUtf8("запал")});
    const bool sShock = containsAnyRoot(s, {QString::fromUtf8("амортиз")});
    const bool pShock = containsAnyRoot(p, {QString::fromUtf8("амортиз")});

    if (sOil) {
        if (sFilter) return (pOil && pFilter) ? 100 : 0;
        return (pOil && !pFilter) ? 100 : 0;
    }
    if (sPads) return pPads ? 100 : 0;
    if (sCaliper) return pCaliper ? 100 : 0;
    if (sGenBelt) return pGenBelt ? 100 : 0;
    if (sChain) return pChain ? 100 : 0;
    if (sSilent) return pSilent ? 100 : 0;
    if (sTip) return pTip ? 100 : 0;
    if (sGasket) return pGasket ? 100 : 0;
    if (sWires) return pWires ? 100 : 0;
    if (sShock) return pShock ? 100 : 0;

    const QStringList roots = {
        QString::fromUtf8("масл"), QString::fromUtf8("мастил"), QString::fromUtf8("фильтр"), QString::fromUtf8("фільтр"),
        QString::fromUtf8("колод"), QString::fromUtf8("супорт"), QString::fromUtf8("ремен"), QString::fromUtf8("генератор"),
        QString::fromUtf8("цеп"), QString::fromUtf8("ланцюг"), QString::fromUtf8("грм"), QString::fromUtf8("сайлент"),
        QString::fromUtf8("наконеч"), QString::fromUtf8("шаров"), QString::fromUtf8("проклад"), QString::fromUtf8("гбц"),
        QString::fromUtf8("провод"), QString::fromUtf8("зажиган"), QString::fromUtf8("запал"), QString::fromUtf8("амортиз"),
        QString::fromUtf8("стартер"), QString::fromUtf8("ролик"), QString::fromUtf8("шарнир")
    };
    return overlapScore(s, p, roots);
}


static QString canonStoreKey(const QString& s)
{
    QString t = s.trimmed().toLower();
    t.replace(QChar(0x0456), QChar(0x0438));
    t.replace(QChar(0x0457), QChar(0x0438));
    t.replace(QChar(0x0454), QChar(0x0435));
    t.replace(QChar(0x0491), QChar(0x0433));
    QString out;
    out.reserve(t.size());
    for (const QChar& ch : t) {
        if (ch.isLetterOrNumber()) out.append(ch);
    }
    return out;
}

QString motorOilStoreName()
{
    const QString raw = Database::getSetting("settings.fin.oil_store_markups", "{}").toString();
    const auto doc = QJsonDocument::fromJson(raw.toUtf8());
    if (doc.isObject()) {
        const auto obj = doc.object();
        for (auto it = obj.begin(); it != obj.end(); ++it) {
            const QString key = it.key().trimmed();
            if (!key.isEmpty()) return key;
        }
    }
    return QString::fromUtf8("Моторне мастило");
}

QMap<QString,double> loadMarkupMapForReports(const QString& key)
{
    QMap<QString,double> out;
    const QString raw = Database::getSetting(key, "{}").toString();
    const auto doc = QJsonDocument::fromJson(raw.toUtf8());
    if (!doc.isObject()) return out;
    const auto obj = doc.object();
    for (auto it = obj.begin(); it != obj.end(); ++it) {
        const QString k = it.key().trimmed();
        bool ok = false;
        const double v = it.value().toVariant().toDouble(&ok);
        if (!k.isEmpty() && ok) out.insert(k, v);
    }
    return out;
}

double lookupStoreMarkupPercentForReports(const QMap<QString,double>& mp, const QString& store)
{
    const QString s = store.trimmed();
    if (s.isEmpty()) return 0.0;
    if (mp.contains(s)) return mp.value(s);
    const QString key = canonStoreKey(s);
    for (auto it = mp.begin(); it != mp.end(); ++it) {
        if (canonStoreKey(it.key()) == key) return it.value();
    }
    return 0.0;
}

double effectiveMarkupPercentForReports(const QString& partName, const QString& store, double storedPct)
{
    if (storedPct > 0.0) return storedPct;
    const double defaultParts = Database::getSetting("settings.fin.parts_markup", "0").toDouble();
    const double defaultOil = Database::getSetting("settings.fin.oil_markup", "0").toDouble();
    if (isMotorOilName(partName)) {
        const double pct = lookupStoreMarkupPercentForReports(loadMarkupMapForReports("settings.fin.oil_store_markups"), store);
        return pct > 0.0 ? pct : defaultOil;
    }
    const double pct = lookupStoreMarkupPercentForReports(loadMarkupMapForReports("settings.fin.store_markups"), store);
    return pct > 0.0 ? pct : defaultParts;
}

QMap<QString, QList<PartPdfRow>> collectPartsPdfGroups(const QString& df, const QString& dt)
{
    QMap<QString, QList<PartPdfRow>> groups;
    const QDate from = QDate::fromString(df, Qt::ISODate);
    const QDate to = QDate::fromString(dt, Qt::ISODate);

    QSqlQuery q(Database::db());
    q.prepare(
        "SELECT COALESCE(NULLIF(TRIM(p.store),''), '(без магазину)'), p.ordered_at, substr(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at),1,10), p.order_number, "
        "COALESCE(p.name,''), COALESCE(p.part_number,''), "
        "COALESCE(p.purchase_amount, CASE WHEN COALESCE(p.purchase_price,0)>0 THEN COALESCE(p.purchase_price,0)*COALESCE(p.qty,1) ELSE COALESCE(p.amount,0) END), "
        "COALESCE(p.amount,0) - COALESCE(p.purchase_amount, CASE WHEN COALESCE(p.purchase_price,0)>0 THEN COALESCE(p.purchase_price,0)*COALESCE(p.qty,1) ELSE COALESCE(p.amount,0) END), "
        "COALESCE(p.qty,1), COALESCE(p.amount,0), COALESCE(p.purchase_price,0), COALESCE(p.markup_percent,0) "
        "FROM work_order_parts p "
        "JOIN work_orders wo ON wo.number = p.order_number "
        "ORDER BY COALESCE(NULLIF(TRIM(p.store),''), '(без магазину)') ASC, p.order_number ASC, p.id ASC");
    if (q.exec()) {
        while (q.next()) {
            const QDate eff = effectiveDate(q.value(1).toString(), q.value(2).toString());
            if (!eff.isValid() || eff < from || eff > to) continue;
            PartPdfRow r;
            r.store = normalizeStoreForPdf(q.value(0).toString());
            r.date = eff.toString("dd.MM.yy");
            r.orderNumber = q.value(3).toString();
            r.name = q.value(4).toString();
            if (isMotorOilName(r.name)) {
                r.store = motorOilStoreName();
            }
            r.oem = q.value(5).toString();
            r.purchase = q.value(6).toDouble();
            const double qty = q.value(8).toDouble();
            const double purchasePrice = q.value(10).toDouble() > 0.0 ? q.value(10).toDouble() : (qty > 0.0 ? r.purchase / qty : 0.0);
            const double pct = effectiveMarkupPercentForReports(r.name, r.store, q.value(11).toDouble());
            const double clientPrice = purchasePrice * (1.0 + qMax(0.0, pct) / 100.0);
            r.added = (clientPrice - purchasePrice) * qty;
            r.qty = FormatUtils::smartQty(qty);
            r.clientPrice = clientPrice * qty;
            groups[r.store].append(r);
        }
    }
    return groups;
}

QMap<QString, QList<OutsourcePdfRow>> collectOutsourceGroups(const QString& df, const QString& dt,
                                                             int& count, double& repairTotal, double& clientTotal)
{
    QMap<QString, QList<OutsourcePdfRow>> groups;
    count = 0; repairTotal = 0.0; clientTotal = 0.0;
    const QDate from = QDate::fromString(df, Qt::ISODate);
    const QDate to = QDate::fromString(dt, Qt::ISODate);
    QSqlQuery q(Database::db());
    q.prepare(
        "SELECT COALESCE(NULLIF(company_name,''), '(без компанії)'), sent_date, order_number, part_name, company_price, client_price "
        "FROM outsource_jobs "
        "ORDER BY company_name ASC, sent_date ASC, id ASC");
    if (q.exec()) {
        while (q.next()) {
            const QDate eff = effectiveDate(q.value(1).toString());
            if (!eff.isValid() || eff < from || eff > to) continue;
            OutsourcePdfRow r;
            r.company = q.value(0).toString();
            r.date = eff.toString("dd.MM.yy");
            r.orderNumber = q.value(2).toString();
            r.partName = q.value(3).toString();
            r.repairCost = q.value(4).toDouble();
            r.clientPrice = q.value(5).toDouble();
            groups[r.company].append(r);
            ++count;
            repairTotal += r.repairCost;
            clientTotal += r.clientPrice;
        }
    }
    return groups;
}

QList<PayrollMasterPdf> collectPayrollDetails(const QString& df, const QString& dt)
{
    QList<PayrollMasterPdf> mastersOut;
    const auto masters = Database::masters(true);
    const auto percents = Database::payrollPercents();
    const auto adminSources = loadAdminSalarySources();
    const AdminSalaryTotals adminTotals = collectAdminSalaryTotals(df, dt);

    for (const auto& m : masters) {
        PayrollMasterPdf pm;
        pm.masterId = m.id;
        pm.masterName = m.role == QStringLiteral("admin") ? QString::fromUtf8("Адмін: %1").arg(m.name) : m.name;
        pm.percent = (m.role == QStringLiteral("admin")) ? m.adminPercent : percents.value(m.id, 0.0);

        if (m.role == QStringLiteral("admin")) {
            const QString source = adminSources.value(m.id, QStringLiteral("margin"));
            PayrollOrderRow row;
            row.dateStart = dmy(df);
            row.dateEnd = dmy(dt);
            row.orderNumber = QStringLiteral("-");
            row.car = adminSalarySourceLabel(source);
            row.engine = QString();
            row.works = QString::fromUtf8("Зарплата адміна за вибраним джерелом");
            row.amount = adminSalaryBaseForSource(adminTotals, source);
            row.masterAmount = qRound64(row.amount * pm.percent / 100.0);
            pm.orders.append(row);
            pm.ordersCount = 1;
            pm.worksTotal = row.amount;
            pm.accrued = row.masterAmount;
            mastersOut.append(pm);
            continue;
        }

        QSqlQuery ordersQ(Database::db());
        ordersQ.prepare(
            "SELECT wo.number, substr(wo.opened_at,1,10), substr(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at),1,10), "
            "wo.plate, wo.car, wo.engine_type, wo.engine_volume, "
            "COALESCE(SUM(COALESCE(s.amount,0) * COALESCE(sm.share_percent,0) / 100.0), 0) "
            "FROM work_orders wo "
            "JOIN work_order_services s ON s.order_number = wo.number "
            "JOIN service_masters sm ON sm.service_id = s.id "
            "WHERE wo.status='closed' AND sm.master_id=? "
            "AND date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) >= date(?) "
            "AND date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) <= date(?) "
            "GROUP BY wo.number, wo.opened_at, wo.closed_at, wo.plate, wo.car, wo.engine_type, wo.engine_volume "
            "ORDER BY wo.number ASC");
        ordersQ.addBindValue(m.id);
        ordersQ.addBindValue(df);
        ordersQ.addBindValue(dt);
        if (ordersQ.exec()) {
            while (ordersQ.next()) {
                PayrollOrderRow row;
                const QString orderNumber = ordersQ.value(0).toString();
                row.dateStart = dmy(ordersQ.value(1).toString());
                row.dateEnd = dmy(ordersQ.value(2).toString());
                row.orderNumber = orderNumber;
                row.car = QString("%1 / %2").arg(ordersQ.value(3).toString(), ordersQ.value(4).toString());
                row.engine = QString("%1\n%2").arg(ordersQ.value(5).toString(), ordersQ.value(6).toString());
                row.amount = ordersQ.value(7).toDouble();
                row.masterAmount = qRound64(row.amount * pm.percent / 100.0);

                QStringList works;
                QSqlQuery svcQ(Database::db());
                svcQ.prepare(
                    "SELECT COALESCE(s.title,''), COALESCE(s.amount,0), COALESCE(sm.share_percent,0) "
                    "FROM work_order_services s "
                    "JOIN service_masters sm ON sm.service_id = s.id "
                    "WHERE s.order_number=? AND sm.master_id=? "
                    "ORDER BY s.id ASC");
                svcQ.addBindValue(orderNumber);
                svcQ.addBindValue(m.id);
                if (svcQ.exec()) {
                    while (svcQ.next()) {
                        const QString t = svcQ.value(0).toString();
                        const double am = svcQ.value(1).toDouble() * svcQ.value(2).toDouble() / 100.0;
                        works << QString("%1 — %2 грн").arg(t, money0(am));
                    }
                }
                row.works = works.join("\n");
                pm.orders.append(row);
                pm.ordersCount += 1;
                pm.worksTotal += row.amount;
            }
        }
        pm.accrued = qRound64(pm.worksTotal * pm.percent / 100.0);
        mastersOut.append(pm);
    }

    return mastersOut;
}

void newPdfPage(QPdfWriter& pdf, QPainter& p, int& y, const PdfTheme& theme)
{
    pdf.newPage();
    p.resetTransform();
    y = theme.top;
}

bool finalizeAndOpenPdf(QWidget* parent, QPainter& p, const QString& path)
{
    p.end();
    const bool opened = QDesktopServices::openUrl(QUrl::fromLocalFile(path));
    if (!opened) {
        QMessageBox::warning(parent, QString::fromUtf8("PDF збережено"),
                             QString::fromUtf8("PDF збережено, але не вдалося відкрити автоматично:\n%1").arg(path));
    }
    return opened;
}

} // namespace

ReportsPage::ReportsPage(QWidget* parent)
    : QWidget(parent)
{
    buildUi();
    refresh();
}

void ReportsPage::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(0, 0, 0, 0);
    root->setSpacing(10);

    auto* top = new QHBoxLayout();
    top->setContentsMargins(0, 0, 0, 0);
    top->setSpacing(12);

    auto* lblFrom = new QLabel(QString::fromUtf8("З:"), this);
    auto* lblTo = new QLabel(QString::fromUtf8("По:"), this);

    m_from = new QDateEdit(QDate::currentDate().addDays(-9), this);
    m_from->setDisplayFormat("dd.MM.yy");
    m_from->setCalendarPopup(true);
    m_to = new QDateEdit(QDate::currentDate(), this);
    m_to->setDisplayFormat("dd.MM.yy");
    m_to->setCalendarPopup(true);

    top->addWidget(lblFrom);
    top->addWidget(m_from);
    top->addWidget(lblTo);
    top->addWidget(m_to);
    top->addStretch(1);

    m_statsLabel = new QLabel(this);
    m_statsLabel->setAlignment(Qt::AlignRight | Qt::AlignTop);
    m_statsLabel->setMinimumWidth(340);
    top->addWidget(m_statsLabel);

    root->addLayout(top);

    m_tabs = new QTabWidget(this);
    m_tabs->setDocumentMode(false);

    auto makeTab = [this](QTableWidget*& table) {
        auto* page = new QWidget(this);
        auto* l = new QVBoxLayout(page);
        l->setContentsMargins(8, 8, 8, 8);
        l->setSpacing(8);
        table = new QTableWidget(page);
        setTableBaseStyle(table);
        l->addWidget(table, 1);
        return page;
    };

    m_tabs->addTab(makeTab(m_periodTable), QString::fromUtf8("Звіт за період"));
    m_tabs->addTab(makeTab(m_partsTable), QString::fromUtf8("Придбання запчастин"));
    m_tabs->addTab(makeTab(m_outsourceTable), QString::fromUtf8("Аутсорс"));
    m_tabs->addTab(makeTab(m_expensesTable), QString::fromUtf8("Витрати"));
    m_tabs->addTab(makeTab(m_payrollTable), QString::fromUtf8("Зарплата"));

    m_descLabel = new QLabel(this);
    m_descLabel->setWordWrap(true);
    root->addWidget(m_tabs, 1);
    root->addWidget(m_descLabel);

    auto* bottom = new QHBoxLayout();
    bottom->setContentsMargins(0, 0, 0, 0);
    bottom->addStretch(1);
    m_pdfButton = new QPushButton(QString::fromUtf8("PDF"), this);
    m_pdfButton->setMinimumWidth(90);
    bottom->addWidget(m_pdfButton);
    root->addLayout(bottom);

    m_periodTable->setColumnCount(7);
    m_periodTable->setHorizontalHeaderLabels({
        QString::fromUtf8("Дата"), QString::fromUtf8("Наряд"), QString::fromUtf8("Авто"),
        QString::fromUtf8("Майстер"), QString::fromUtf8("Роботи (грн)"),
        QString::fromUtf8("Запчастини (грн)"), QString::fromUtf8("Разом (грн)")
    });
    m_periodTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    m_periodTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    m_periodTable->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch);
    m_periodTable->horizontalHeader()->setSectionResizeMode(3, QHeaderView::ResizeToContents);
    m_periodTable->horizontalHeader()->setSectionResizeMode(4, QHeaderView::ResizeToContents);
    m_periodTable->horizontalHeader()->setSectionResizeMode(5, QHeaderView::ResizeToContents);
    m_periodTable->horizontalHeader()->setSectionResizeMode(6, QHeaderView::ResizeToContents);

    m_partsTable->setColumnCount(7);
    m_partsTable->setHorizontalHeaderLabels({
        QString::fromUtf8("Дата"), QString::fromUtf8("Наряд"), QString::fromUtf8("Запчастина"),
        QString::fromUtf8("Сума закупки"), QString::fromUtf8("Доданий %\n(чистий)"),
        QString::fromUtf8("Кіл-ть"), QString::fromUtf8("Ціна")
    });
    m_partsTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    m_partsTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    m_partsTable->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch);
    m_partsTable->horizontalHeader()->setSectionResizeMode(3, QHeaderView::ResizeToContents);
    m_partsTable->horizontalHeader()->setSectionResizeMode(4, QHeaderView::ResizeToContents);
    m_partsTable->horizontalHeader()->setSectionResizeMode(5, QHeaderView::ResizeToContents);
    m_partsTable->horizontalHeader()->setSectionResizeMode(6, QHeaderView::ResizeToContents);

    m_outsourceTable->setColumnCount(6);
    m_outsourceTable->setHorizontalHeaderLabels({
        QString::fromUtf8("Дата"), QString::fromUtf8("Компанія"), QString::fromUtf8("Наряд"),
        QString::fromUtf8("Запчастина"), QString::fromUtf8("Ціна ремонту"), QString::fromUtf8("Ціна клієнту")
    });
    m_outsourceTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    m_outsourceTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    m_outsourceTable->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    m_outsourceTable->horizontalHeader()->setSectionResizeMode(3, QHeaderView::Stretch);
    m_outsourceTable->horizontalHeader()->setSectionResizeMode(4, QHeaderView::ResizeToContents);
    m_outsourceTable->horizontalHeader()->setSectionResizeMode(5, QHeaderView::ResizeToContents);

    m_expensesTable->setColumnCount(8);
    m_expensesTable->setHorizontalHeaderLabels({
        QString::fromUtf8("З"), QString::fromUtf8("По"), QString::fromUtf8("Електро"),
        QString::fromUtf8("Прибирання"), QString::fromUtf8("Опалення"), QString::fromUtf8("Оренда"),
        QString::fromUtf8("Аморт./ПЗ"), QString::fromUtf8("Разом")
    });
    for (int i = 0; i < 8; ++i) {
        m_expensesTable->horizontalHeader()->setSectionResizeMode(i, i < 2 ? QHeaderView::ResizeToContents : QHeaderView::Stretch);
    }

    m_payrollTable->setColumnCount(5);
    m_payrollTable->setHorizontalHeaderLabels({
        QString::fromUtf8("Співробітник"), QString::fromUtf8("Нарядів"), QString::fromUtf8("База"),
        QString::fromUtf8("%"), QString::fromUtf8("Зарплата")
    });
    m_payrollTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    m_payrollTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    m_payrollTable->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    m_payrollTable->horizontalHeader()->setSectionResizeMode(3, QHeaderView::ResizeToContents);
    m_payrollTable->horizontalHeader()->setSectionResizeMode(4, QHeaderView::ResizeToContents);

    connect(m_from, &QDateEdit::dateChanged, this, &ReportsPage::refresh);
    connect(m_to, &QDateEdit::dateChanged, this, &ReportsPage::refresh);
    connect(m_tabs, &QTabWidget::currentChanged, this, [this](int){ refreshActiveTab(); });
    connect(m_pdfButton, &QPushButton::clicked, this, &ReportsPage::exportActivePdf);

    auto openOrderFromTable = [this](QTableWidget* table, int orderColumn, int row) {
        if (!table || row < 0 || row >= table->rowCount()) return;
        auto* item = table->item(row, orderColumn);
        if (!item) return;
        bool ok = false;
        const int orderNumber = item->text().trimmed().toInt(&ok);
        if (!ok || orderNumber <= 0) return;
        table->selectRow(row);
        OrderDialog dlg(this, orderNumber);
        dlg.setWindowTitle(QString::fromUtf8("Редагування наряду"));
        dlg.openWorkPartsTab();
        const int rc = dlg.exec();
        Q_UNUSED(rc);
        refreshActiveTab();
    };

    connect(m_periodTable, &QTableWidget::cellDoubleClicked, this, [openOrderFromTable, this](int row, int) {
        openOrderFromTable(m_periodTable, 1, row);
    });
    connect(m_partsTable, &QTableWidget::cellDoubleClicked, this, [openOrderFromTable, this](int row, int) {
        openOrderFromTable(m_partsTable, 1, row);
    });
    connect(m_outsourceTable, &QTableWidget::cellDoubleClicked, this, [openOrderFromTable, this](int row, int) {
        openOrderFromTable(m_outsourceTable, 2, row);
    });
}

void ReportsPage::setTableBaseStyle(QTableWidget* table)
{
    table->setAlternatingRowColors(false);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setSelectionMode(QAbstractItemView::SingleSelection);
    table->setWordWrap(true);
    table->setSortingEnabled(false);
    table->verticalHeader()->setVisible(false);
    table->horizontalHeader()->setStretchLastSection(false);
}

ReportsPage::ReportTab ReportsPage::activeTab() const
{
    return static_cast<ReportTab>(m_tabs ? m_tabs->currentIndex() : 0);
}

void ReportsPage::refresh()
{
    refreshActiveTab();
}

void ReportsPage::refreshActiveTab()
{
    switch (activeTab()) {
    case ReportTab::Period:    refreshPeriod(); break;
    case ReportTab::Parts:     refreshParts(); break;
    case ReportTab::Outsource: refreshOutsource(); break;
    case ReportTab::Expenses:  refreshExpenses(); break;
    case ReportTab::Payroll:   refreshPayroll(); break;
    }
}

void ReportsPage::updateStats(const QStringList& lines)
{
    m_statsLabel->setText(lines.join("\n"));
}

void ReportsPage::refreshPeriod()
{
    const QString df = m_from->date().toString("yyyy-MM-dd");
    const QString dt = m_to->date().toString("yyyy-MM-dd");
    m_descLabel->setText(QString::fromUtf8("Звіт за період — табличний перегляд по поточному діапазону дат."));
    m_periodTable->setRowCount(0);

    QSqlQuery q(Database::db());
    q.prepare(
        "SELECT substr(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at),1,10), wo.number, wo.car, "
        "COALESCE(NULLIF(wo.master_name_closed,''), NULLIF(m.name,''), ''), "
        "COALESCE(wo.works_sum,0), COALESCE(wo.parts_sum,0) "
        "FROM work_orders wo "
        "LEFT JOIN masters m ON m.id = wo.master_id "
        "WHERE date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) >= date(?) "
        "AND date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) <= date(?) "
        "ORDER BY date(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at)) ASC, wo.number ASC");
    q.addBindValue(df);
    q.addBindValue(dt);

    int count = 0;
    double works = 0.0;
    double parts = 0.0;

    if (q.exec()) {
        while (q.next()) {
            const int r = m_periodTable->rowCount();
            m_periodTable->insertRow(r);
            const double ws = q.value(4).toDouble();
            const double ps = q.value(5).toDouble();
            m_periodTable->setItem(r, 0, new QTableWidgetItem(dmy(q.value(0).toString())));
            m_periodTable->setItem(r, 1, new QTableWidgetItem(q.value(1).toString()));
            m_periodTable->setItem(r, 2, new QTableWidgetItem(q.value(2).toString()));
            const QString masterName = q.value(3).toString().trimmed();
            m_periodTable->setItem(r, 3, new QTableWidgetItem(masterName.isEmpty() ? QString::fromUtf8("—") : masterName));
            m_periodTable->setItem(r, 4, new QTableWidgetItem(money0(ws)));
            m_periodTable->setItem(r, 5, new QTableWidgetItem(money0(ps)));
            m_periodTable->setItem(r, 6, new QTableWidgetItem(money0(ws + ps)));
            for (int c = 4; c <= 6; ++c) m_periodTable->item(r, c)->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            ++count;
            works += ws;
            parts += ps;
        }
    }

    updateStats({
        QString::fromUtf8("Нарядів:  %1").arg(count),
        QString::fromUtf8("Роботи:  %1  грн.").arg(money0(works)),
        QString::fromUtf8("Запчастини:  %1  грн.").arg(money0(parts)),
        QString::fromUtf8("Разом:  %1  грн.").arg(money0(works + parts))
    });
}

void ReportsPage::refreshParts()
{
    const QString df = m_from->date().toString("yyyy-MM-dd");
    const QString dt = m_to->date().toString("yyyy-MM-dd");
    const QDate from = QDate::fromString(df, Qt::ISODate);
    const QDate to = QDate::fromString(dt, Qt::ISODate);
    m_descLabel->setText(QString::fromUtf8("Придбання запчастин — перегляд по поточному діапазону дат."));
    m_partsTable->setRowCount(0);

    QSqlQuery q(Database::db());
    q.prepare(
        "SELECT p.ordered_at, substr(COALESCE(NULLIF(wo.closed_at,''), wo.opened_at),1,10), p.order_number, "
        "COALESCE(NULLIF(TRIM(p.store),''), '(без магазину)'), COALESCE(p.name,''), "
        "COALESCE(p.purchase_amount, CASE WHEN COALESCE(p.purchase_price,0)>0 THEN COALESCE(p.purchase_price,0)*COALESCE(p.qty,1) ELSE COALESCE(p.amount,0) END), "
        "COALESCE(p.amount,0) - COALESCE(p.purchase_amount, CASE WHEN COALESCE(p.purchase_price,0)>0 THEN COALESCE(p.purchase_price,0)*COALESCE(p.qty,1) ELSE COALESCE(p.amount,0) END), "
        "COALESCE(p.qty,1), COALESCE(p.amount,0), COALESCE(p.purchase_price,0), COALESCE(p.markup_percent,0) "
        "FROM work_order_parts p "
        "JOIN work_orders wo ON wo.number = p.order_number "
        "ORDER BY COALESCE(NULLIF(TRIM(p.store),''), '(без магазину)') ASC, p.order_number ASC, p.id ASC");

    QString lastStore;
    int count = 0;
    double totalPurchase = 0.0;
    double totalNet = 0.0;
    double totalQty = 0.0;

    if (q.exec()) {
        while (q.next()) {
            const QDate eff = effectiveDate(q.value(0).toString(), q.value(1).toString());
            if (!eff.isValid() || eff < from || eff > to) continue;
            const QString store = normalizeStoreForPdf(q.value(3).toString());
            if (store != lastStore) {
                lastStore = store;
                const int hr = m_partsTable->rowCount();
                m_partsTable->insertRow(hr);
                auto* item = new QTableWidgetItem(QString::fromUtf8("Магазин: %1").arg(store));
                QFont f = item->font();
                f.setBold(true);
                item->setFont(f);
                m_partsTable->setItem(hr, 0, item);
                m_partsTable->setSpan(hr, 0, 1, m_partsTable->columnCount());
            }
            const int r = m_partsTable->rowCount();
            m_partsTable->insertRow(r);
            const double purchase = q.value(5).toDouble();
            const double qty = q.value(7).toDouble();
            const double purchasePrice = q.value(9).toDouble() > 0.0 ? q.value(9).toDouble() : (qty > 0.0 ? purchase / qty : 0.0);
            const double pct = effectiveMarkupPercentForReports(q.value(4).toString(), store, q.value(10).toDouble());
            const double client = purchasePrice * (1.0 + qMax(0.0, pct) / 100.0) * qty;
            const double net = client - purchase;
            m_partsTable->setItem(r, 0, new QTableWidgetItem(eff.toString("dd.MM.yy")));
            m_partsTable->setItem(r, 1, new QTableWidgetItem(q.value(2).toString()));
            m_partsTable->setItem(r, 2, new QTableWidgetItem(q.value(4).toString()));
            m_partsTable->setItem(r, 3, new QTableWidgetItem(money0(purchase)));
            m_partsTable->setItem(r, 4, new QTableWidgetItem(money0(net)));
            m_partsTable->setItem(r, 5, new QTableWidgetItem(FormatUtils::smartQty(qty)));
            m_partsTable->setItem(r, 6, new QTableWidgetItem(money0(client)));
            for (int c = 3; c <= 6; ++c) m_partsTable->item(r, c)->setTextAlignment((c == 5 ? Qt::AlignCenter : Qt::AlignRight) | Qt::AlignVCenter);
            ++count;
            totalPurchase += purchase;
            totalNet += net;
            totalQty += qty;
        }
    }

    updateStats({
        QString::fromUtf8("Придбано запчастин:  %1  од.").arg(FormatUtils::smartQty(totalQty)),
        QString::fromUtf8("На суму:  %1  грн.").arg(money0(totalPurchase)),
        QString::fromUtf8("Маржа:  %1  грн.").arg(money0(totalNet)),
        QString::fromUtf8("Позицій:  %1").arg(count)
    });
}

void ReportsPage::refreshOutsource()
{
    const QString df = m_from->date().toString("yyyy-MM-dd");
    const QString dt = m_to->date().toString("yyyy-MM-dd");
    const QDate from = QDate::fromString(df, Qt::ISODate);
    const QDate to = QDate::fromString(dt, Qt::ISODate);
    m_descLabel->setText(QString::fromUtf8("Аутсорс — перегляд відправлених на ремонт запчастин по поточному діапазону дат."));
    m_outsourceTable->setRowCount(0);

    QSqlQuery q(Database::db());
    q.prepare(
        "SELECT sent_date, COALESCE(NULLIF(company_name,''), '(без компанії)'), order_number, part_name, company_price, client_price "
        "FROM outsource_jobs ORDER BY sent_date ASC, id ASC");

    int count = 0;
    double repair = 0.0;
    double client = 0.0;

    if (q.exec()) {
        while (q.next()) {
            const QDate eff = effectiveDate(q.value(0).toString());
            if (!eff.isValid() || eff < from || eff > to) continue;
            const int r = m_outsourceTable->rowCount();
            m_outsourceTable->insertRow(r);
            const double repairCost = q.value(4).toDouble();
            const double clientPrice = q.value(5).toDouble();
            m_outsourceTable->setItem(r, 0, new QTableWidgetItem(eff.toString("dd.MM.yy")));
            m_outsourceTable->setItem(r, 1, new QTableWidgetItem(q.value(1).toString()));
            m_outsourceTable->setItem(r, 2, new QTableWidgetItem(q.value(2).toString()));
            m_outsourceTable->setItem(r, 3, new QTableWidgetItem(q.value(3).toString()));
            m_outsourceTable->setItem(r, 4, new QTableWidgetItem(money0(repairCost)));
            m_outsourceTable->setItem(r, 5, new QTableWidgetItem(money0(clientPrice)));
            m_outsourceTable->item(r, 4)->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            m_outsourceTable->item(r, 5)->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            ++count;
            repair += repairCost;
            client += clientPrice;
        }
    }

    if (count == 0) {
        m_outsourceTable->setRowCount(1);
        m_outsourceTable->setItem(0, 0, new QTableWidgetItem(QString::fromUtf8("За вибраний період немає записів аутсорсу")));
        m_outsourceTable->setSpan(0, 0, 1, m_outsourceTable->columnCount());
    }

    updateStats({
        QString::fromUtf8("Відправлено на ремонт:  %1  од.").arg(count),
        QString::fromUtf8("На суму:  %1  грн.").arg(money0(repair)),
        QString::fromUtf8("Маржа:  %1  грн.").arg(money0(client - repair))
    });
}

void ReportsPage::refreshExpenses()
{
    const QString df = m_from->date().toString("yyyy-MM-dd");
    const QString dt = m_to->date().toString("yyyy-MM-dd");
    m_descLabel->setText(QString::fromUtf8("Витрати — зведення по збережених періодах витрат."));
    m_expensesTable->setRowCount(0);

    QSqlQuery q(Database::db());
    q.prepare(
        "SELECT period_from, period_to, "
        "((COALESCE(elec_curr,0)-COALESCE(elec_prev,0))*COALESCE(elec_tariff,0)), "
        "COALESCE(cleaning,0), COALESCE(heating,0), COALESCE(rent,0), "
        "(COALESCE(amortization,0)+COALESCE(sw_opendatabot,0)+COALESCE(sw_tecalliance,0)) "
        "FROM expenses "
        "WHERE date(period_to) >= date(?) AND date(period_from) <= date(?) "
        "ORDER BY date(period_from) ASC");
    q.addBindValue(df);
    q.addBindValue(dt);

    double grandTotal = 0.0;
    int count = 0;
    if (q.exec()) {
        while (q.next()) {
            const double elec = q.value(2).toDouble();
            const double cleaning = q.value(3).toDouble();
            const double heating = q.value(4).toDouble();
            const double rent = q.value(5).toDouble();
            const double software = q.value(6).toDouble();
            const double total = elec + cleaning + heating + rent + software;
            const int r = m_expensesTable->rowCount();
            m_expensesTable->insertRow(r);
            m_expensesTable->setItem(r, 0, new QTableWidgetItem(dmy(q.value(0).toString())));
            m_expensesTable->setItem(r, 1, new QTableWidgetItem(dmy(q.value(1).toString())));
            m_expensesTable->setItem(r, 2, new QTableWidgetItem(money0(elec)));
            m_expensesTable->setItem(r, 3, new QTableWidgetItem(money0(cleaning)));
            m_expensesTable->setItem(r, 4, new QTableWidgetItem(money0(heating)));
            m_expensesTable->setItem(r, 5, new QTableWidgetItem(money0(rent)));
            m_expensesTable->setItem(r, 6, new QTableWidgetItem(money0(software)));
            m_expensesTable->setItem(r, 7, new QTableWidgetItem(money0(total)));
            for (int c = 2; c < 8; ++c) m_expensesTable->item(r, c)->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            grandTotal += total;
            ++count;
        }
    }

    updateStats({
        QString::fromUtf8("Періодів:  %1").arg(count),
        QString::fromUtf8("Всього витрат:  %1  грн.").arg(money0(grandTotal))
    });
}

void ReportsPage::refreshPayroll()
{
    const QString df = m_from->date().toString("yyyy-MM-dd");
    const QString dt = m_to->date().toString("yyyy-MM-dd");
    m_descLabel->setText(QString::fromUtf8("Зарплата — нарахування майстрів та адміна у межах вибраного періоду."));
    m_payrollTable->setRowCount(0);

    const auto rows = collectPayrollRows(df, dt);
    double total = 0.0;
    for (const auto& row : rows) {
        const int r = m_payrollTable->rowCount();
        m_payrollTable->insertRow(r);
        m_payrollTable->setItem(r, 0, new QTableWidgetItem(row.masterName));
        m_payrollTable->setItem(r, 1, new QTableWidgetItem(QString::number(row.ordersCount)));
        m_payrollTable->setItem(r, 2, new QTableWidgetItem(money0(row.baseSum)));
        m_payrollTable->setItem(r, 3, new QTableWidgetItem(QString::number(row.percent, 'f', 2)));
        m_payrollTable->setItem(r, 4, new QTableWidgetItem(money0(row.accrued)));
        m_payrollTable->item(r, 1)->setTextAlignment(Qt::AlignCenter);
        for (int c = 2; c <= 4; ++c) m_payrollTable->item(r, c)->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        total += row.accrued;
    }

    updateStats({
        QString::fromUtf8("Співробітників:  %1").arg(rows.size()),
        QString::fromUtf8("Нараховано:  %1  грн.").arg(money0(total))
    });
}

void ReportsPage::exportActivePdf()
{
    switch (activeTab()) {
    case ReportTab::Period:    exportPeriodPdf(); break;
    case ReportTab::Parts:     exportPartsPdf(); break;
    case ReportTab::Outsource: exportOutsourcePdf(); break;
    case ReportTab::Expenses:  exportExpensesPdf(); break;
    case ReportTab::Payroll:   exportPayrollPdf(); break;
    }
}

void ReportsPage::exportPeriodPdf()
{
    const QString df = m_from->date().toString("yyyy-MM-dd");
    const QString dt = m_to->date().toString("yyyy-MM-dd");
    const QString path = makeAutoPdfPath(QStringLiteral("report_period"));

    double partsTotal=0, worksTotal=0, partsMargin=0, outsourceMargin=0, salaryTotal=0, expensesTotal=0;
    const auto rows = collectPeriodPdfRows(df, dt, partsTotal, worksTotal, partsMargin, outsourceMargin, salaryTotal, expensesTotal);
    const double totalMargin = partsMargin + outsourceMargin + worksTotal - salaryTotal - expensesTotal;

    QPdfWriter pdf(path);
    pdf.setPageSize(QPageSize(QPageSize::A4));
    pdf.setResolution(144);
    QPainter p(&pdf);
    p.setRenderHint(QPainter::Antialiasing, false);
    const PdfTheme th = buildTheme(pdf);
    const int extraSide = mmToPx(&pdf, 10);
    const int tableLeft = th.left - extraSide;
    const int tableWidth = th.contentWidth + extraSide * 2;
    int y = th.top;

    drawCenteredText(p, QRect(th.left, y, th.contentWidth, 34), QStringLiteral("CarServicePointG"), titleFont(24));
    y += 42;
    drawCenteredText(p, QRect(th.left, y, th.contentWidth, 30),
                     QString::fromUtf8("ЗВІТ ЗА ПЕРІОД: %1 — %2").arg(m_from->date().toString("dd.MM.yy"), m_to->date().toString("dd.MM.yy")),
                     titleFont(20));
    y += 46;

    QStringList headers = {
        QString::fromUtf8("Дата"),
        QString::fromUtf8("Наряд"),
        QString::fromUtf8("Авто"),
        QString::fromUtf8("Держ. номер"),
        QString::fromUtf8("Робота"),
        QString::fromUtf8("Запчастина"),
        QString::fromUtf8("Кіл-ть"),
        QString::fromUtf8("Ціна\nзапчастин"),
        QString::fromUtf8("Доданий\n%"),
        QString::fromUtf8("Ціна\nробіт"),
        QString::fromUtf8("Підсумок")
    };

    const QFont tableFont = bodyFont(7);
    auto headerFontForColumn = [&](int i) {
        const bool compactHeader = (i == 0 || i == 1 || i >= 7);
        return bodyFont(compactHeader ? 5 : 7, true);
    };

    auto cellTextWidth = [&](const QString& text, const QFont& font) {
        QFontMetrics fm(font);
        const QStringList lines = text.split('\n');
        int maxWidth = 0;
        for (const QString& line : lines) {
            maxWidth = qMax(maxWidth, fm.horizontalAdvance(line));
        }
        return maxWidth;
    };

    QVector<int> minW = {
        mmToPx(&pdf, 14), // Дата
        mmToPx(&pdf, 10), // Наряд
        mmToPx(&pdf, 20), // Авто
        mmToPx(&pdf, 14), // Держ. номер
        mmToPx(&pdf, 26), // Робота
        mmToPx(&pdf, 18), // Запчастина
        mmToPx(&pdf, 8),  // Кіл-ть
        mmToPx(&pdf, 14), // Ціна запчастин
        mmToPx(&pdf, 12), // Доданий %
        mmToPx(&pdf, 12), // Ціна робіт
        mmToPx(&pdf, 16)  // Підсумок
    };
    QVector<int> maxW = {
        mmToPx(&pdf, 18), // Дата
        mmToPx(&pdf, 12), // Наряд
        mmToPx(&pdf, 34), // Авто
        mmToPx(&pdf, 19), // Держ. номер
        mmToPx(&pdf, 62), // Робота
        mmToPx(&pdf, 42), // Запчастина
        mmToPx(&pdf, 10), // Кіл-ть
        mmToPx(&pdf, 18), // Ціна запчастин
        mmToPx(&pdf, 13), // Доданий %
        mmToPx(&pdf, 15), // Ціна робіт
        mmToPx(&pdf, 19)  // Підсумок
    };

    QVector<int> w(headers.size(), 0);
    for (int i = 0; i < headers.size(); ++i) {
        w[i] = qMax(minW[i], cellTextWidth(headers[i], headerFontForColumn(i)) + 12);
    }

    for (const auto& row : rows) {
        const QStringList cells = {
            row.date, row.orderNumber, row.car, row.plate, row.workTitle, row.partName, row.qty,
            money0(row.partsPrice), money0(row.added), money0(row.worksPrice), money0(row.total)
        };
        for (int i = 0; i < cells.size(); ++i) {
            const int padding = (i >= 7) ? 14 : 12;
            w[i] = qMax(w[i], qMin(maxW[i], cellTextWidth(cells[i], tableFont) + padding));
        }
    }

    w[5] = qMax(w[5], qMin(maxW[5], w[5] + mmToPx(&pdf, 6)));

    int currentWidth = 0;
    for (int width : w) currentWidth += width;

    if (currentWidth > tableWidth) {
        QVector<int> shrinkPriority = {4, 2, 3, 7, 9, 8, 10, 0, 1, 6, 5};
        int need = currentWidth - tableWidth;
        for (int idx : shrinkPriority) {
            if (need <= 0) break;
            const int room = w[idx] - minW[idx];
            if (room <= 0) continue;
            const int take = qMin(room, need);
            w[idx] -= take;
            need -= take;
        }
    } else if (currentWidth < tableWidth) {
        int free = tableWidth - currentWidth;
        const int addToPart = qMin(free, qMax(0, maxW[5] - w[5]));
        w[5] += addToPart;
        free -= addToPart;
        const int addToWork = qMin(free, qMax(0, maxW[4] - w[4]));
        w[4] += addToWork;
        free -= addToWork;
        const int addToCar = qMin(free, qMax(0, maxW[2] - w[2]));
        w[2] += addToCar;
        free -= addToCar;
        if (free > 0) w[5] += free;
    }

    auto drawHeader = [&]() {
        int x = tableLeft;
        for (int i=0;i<headers.size();++i) {
            drawCell(p, QRect(x, y, w[i], 46), headers[i], headerFontForColumn(i), Qt::AlignLeft | Qt::AlignTop, QColor(220,220,220), 1);
            x += w[i];
        }
        y += 46;
    };
    drawHeader();

    for (int rowIndex = 0; rowIndex < rows.size(); ++rowIndex) {
        const auto& row = rows[rowIndex];
        QStringList cells = { row.date, row.orderNumber, row.car, row.plate, row.workTitle, row.partName, row.qty,
                              money0(row.partsPrice), money0(row.added), money0(row.worksPrice), money0(row.total) };
        int rowH = 28;
        for (int i=0;i<cells.size();++i) rowH = qMax(rowH, wrappedHeight(p, cells[i], tableFont, w[i], 26));
        if (y + rowH > th.bottom - 180) {
            newPdfPage(pdf, p, y, th);
            drawHeader();
        }
        const QColor rowFill = (rowIndex % 2 == 0) ? Qt::white : QColor(248, 248, 248);
        int x = tableLeft;
        for (int i=0;i<cells.size();++i) {
            Qt::Alignment a = (i >= 7) ? (Qt::AlignRight | Qt::AlignTop) : ((i == 6) ? (Qt::AlignCenter | Qt::AlignTop) : (Qt::AlignLeft | Qt::AlignTop));
            drawCell(p, QRect(x, y, w[i], rowH), cells[i], tableFont, a, rowFill, 1);
            x += w[i];
        }
        y += rowH;
    }

    y += 18;
    p.setFont(bodyFont(10));
    int labelW = mmToPx(&pdf, 48);
    int valueW = mmToPx(&pdf, 36);
    auto drawPair = [&](const QString& l, const QString& v) {
        p.drawText(QRect(th.left, y, labelW, 20), Qt::AlignLeft | Qt::AlignVCenter, l);
        p.drawText(QRect(th.left + labelW, y, valueW, 20), Qt::AlignLeft | Qt::AlignVCenter, v);
        y += 22;
    };
    drawPair(QString::fromUtf8("Разом запчастини:"), money0(partsTotal) + QString::fromUtf8(" грн"));
    drawPair(QString::fromUtf8("Разом роботи:"), money0(worksTotal) + QString::fromUtf8(" грн"));
    y += 18;
    drawPair(QString::fromUtf8("Маржа Аутсорс:"), money0(outsourceMargin) + QString::fromUtf8(" грн"));
    drawPair(QString::fromUtf8("Маржа запчастин:"), money0(partsMargin) + QString::fromUtf8(" грн"));
    y += 18;
    drawPair(QString::fromUtf8("Видано зарплати:"), money0(salaryTotal) + QString::fromUtf8(" грн"));
    drawPair(QString::fromUtf8("Всього витрати на СТО:"), money0(expensesTotal) + QString::fromUtf8(" грн"));
    y += 18;
    drawPair(QString::fromUtf8("Всього маржа:"), money0(totalMargin) + QString::fromUtf8(" грн"));
    finalizeAndOpenPdf(this, p, path);
}

void ReportsPage::exportPartsPdf()
{
    const QString df = m_from->date().toString("yyyy-MM-dd");
    const QString dt = m_to->date().toString("yyyy-MM-dd");
    const QString path = makeAutoPdfPath(QStringLiteral("parts_report"));

    const auto groups = collectPartsPdfGroups(df, dt);
    QPdfWriter pdf(path);
    pdf.setPageSize(QPageSize(QPageSize::A4));
    pdf.setResolution(144);
    QPainter p(&pdf);
    p.setRenderHint(QPainter::Antialiasing, false);
    const PdfTheme th = buildTheme(pdf);
    bool firstPage = true;

    QFontMetrics fmHead(bodyFont(8, true));
    QFontMetrics fmBody(bodyFont(9));
    QVector<int> w = {
        qMax(mmToPx(&pdf, 12), fmHead.horizontalAdvance(QString::fromUtf8("№ з/с")) + 14),
        qMax(mmToPx(&pdf, 15), fmHead.horizontalAdvance(QString::fromUtf8("Дата")) + 14),
        qMax(mmToPx(&pdf, 14), fmHead.horizontalAdvance(QString::fromUtf8("Наряд")) + 14),
        mmToPx(&pdf, 52),
        qMax(mmToPx(&pdf, 19), fmHead.horizontalAdvance(QString::fromUtf8("OEM номер")) + 12),
        qMax(mmToPx(&pdf, 19), fmHead.horizontalAdvance(QString::fromUtf8("Ціна придбання")) + 14),
        qMax(mmToPx(&pdf, 16), fmHead.horizontalAdvance(QString::fromUtf8("Доданий %")) + 12),
        qMax(mmToPx(&pdf, 12), fmHead.horizontalAdvance(QString::fromUtf8("Кіл-ть")) + 12),
        qMax(mmToPx(&pdf, 17), fmHead.horizontalAdvance(QString::fromUtf8("Ціна запчастини")) + 14)
    };
    for (auto it = groups.cbegin(); it != groups.cend(); ++it) {
        for (const auto& r : it.value()) {
            w[0] = qMax(w[0], fmBody.horizontalAdvance(QString::number(it.value().size())) + 16);
            w[1] = qMax(w[1], fmBody.horizontalAdvance(r.date) + 18);
            w[2] = qMax(w[2], fmBody.horizontalAdvance(r.orderNumber) + 18);
            w[4] = qMax(w[4], fmBody.horizontalAdvance(r.oem) + 16);
            w[5] = qMax(w[5], fmBody.horizontalAdvance(money0(r.purchase)) + 20);
            w[6] = qMax(w[6], fmBody.horizontalAdvance(money0(r.added)) + 18);
            w[7] = qMax(w[7], fmBody.horizontalAdvance(r.qty) + 16);
            w[8] = qMax(w[8], fmBody.horizontalAdvance(money0(r.clientPrice)) + 20);
        }
    }
    int fixed = 0; for (int i = 0; i < w.size(); ++i) if (i != 3) fixed += w[i];
    w[3] = qMax(mmToPx(&pdf, 46), th.contentWidth - fixed);
    QStringList headers = {
        QString::fromUtf8("№ з/с"), QString::fromUtf8("Дата"), QString::fromUtf8("Наряд"), QString::fromUtf8("Поз."),
        QString::fromUtf8("OEM\nномер"), QString::fromUtf8("Ціна придбання"), QString::fromUtf8("Доданий %"), QString::fromUtf8("Кіл-ть"), QString::fromUtf8("Ціна запчастини")
    };

    auto drawStorePage = [&](const QString& store, const QList<PartPdfRow>& rows) {
        if (!firstPage) pdf.newPage();
        firstPage = false;
        int y = th.top + mmToPx(&pdf, 20);
        drawCenteredText(p, QRect(th.left, y, th.contentWidth, 30), store, titleFont(22));
        y += 40;
        p.setPen(QPen(Qt::black, 2));
        p.drawLine(th.left, y, th.right, y);
        y += 16;
        drawCenteredText(p, QRect(th.left, y, th.contentWidth, 26), QString::fromUtf8("Звіт придбання запчастин"), titleFont(17, false));
        y += 40;
        drawCenteredText(p, QRect(th.left, y, th.contentWidth, 20), QString::fromUtf8("За період (дата з %1 по %2)").arg(m_from->date().toString("dd.MM.yy"), m_to->date().toString("dd.MM.yy")), bodyFont(11));
        y += 34;
        int x = th.left;
        for (int i=0;i<headers.size();++i) {
            drawCell(p, QRect(x, y, w[i], 46), headers[i], bodyFont(i == 4 ? 7 : 8, true), Qt::AlignCenter, QColor(220,220,220), 2);
            x += w[i];
        }
        y += 46;

        auto drawHeaderRow = [&]() {
            int hx = th.left;
            for (int i=0;i<headers.size();++i) {
                drawCell(p, QRect(hx, y, w[i], 46), headers[i], bodyFont(i == 4 ? 7 : 8, true), Qt::AlignCenter, QColor(220,220,220), 2);
                hx += w[i];
            }
            y += 46;
        };

        int idx = 1; double purchaseTotal=0, addedTotal=0, clientTotal=0; double qtySum = 0;
        const bool oilStore = std::all_of(rows.cbegin(), rows.cend(), [](const PartPdfRow& r){ return isMotorOilName(r.name); })
            || isMotorOilName(store) || store.toCaseFolded().contains(QString::fromUtf8("мастил"));
        for (const auto& r : rows) {
            QStringList cells = { QString::number(idx++), r.date, r.orderNumber, r.name, r.oem, money0(r.purchase), money0(r.added), r.qty, money0(r.clientPrice) };
            int rowH = 28;
            for (int i=0;i<cells.size();++i) rowH = qMax(rowH, wrappedHeight(p, cells[i], bodyFont(9), w[i], 26));
            if (y + rowH > th.bottom - 120) {
                pdf.newPage();
                y = th.top + mmToPx(&pdf, 20);
                drawCenteredText(p, QRect(th.left, y, th.contentWidth, 30), store, titleFont(22));
                y += 40;
                p.setPen(QPen(Qt::black, 2));
                p.drawLine(th.left, y, th.right, y);
                y += 16;
                drawCenteredText(p, QRect(th.left, y, th.contentWidth, 26), QString::fromUtf8("Звіт придбання запчастин"), titleFont(17, false));
                y += 40;
                drawCenteredText(p, QRect(th.left, y, th.contentWidth, 20), QString::fromUtf8("За період (дата з %1 по %2)").arg(m_from->date().toString("dd.MM.yy"), m_to->date().toString("dd.MM.yy")), bodyFont(11));
                y += 34;
                drawHeaderRow();
            }
            x = th.left;
            for (int i=0;i<cells.size();++i) {
                Qt::Alignment a = (i >= 5) ? ((i == 7) ? Qt::Alignment(Qt::AlignCenter | Qt::AlignVCenter) : Qt::Alignment(Qt::AlignRight | Qt::AlignVCenter)) : Qt::Alignment(Qt::AlignLeft | Qt::AlignVCenter);
                drawCell(p, QRect(x, y, w[i], rowH), cells[i], bodyFont(9), a, Qt::white, 2);
                x += w[i];
            }
            y += rowH;
            purchaseTotal += r.purchase;
            addedTotal += r.added;
            clientTotal += r.clientPrice;
            { QString qtyNorm = r.qty; qtyNorm.replace(',', '.'); qtySum += qtyNorm.toDouble(); }
        }

        y += 24;
        p.setFont(bodyFont(11));
        auto pair = [&](const QString& l, const QString& v) {
            p.drawText(QRect(th.left+10, y, 250, 22), Qt::AlignLeft|Qt::AlignVCenter, l);
            p.drawText(QRect(th.left+300, y, 320, 22), Qt::AlignLeft|Qt::AlignVCenter, v);
            y += 24;
        };
        auto separator = [&]() {
            y += 6;
            p.setPen(QPen(Qt::black, 1));
            p.drawLine(th.left + 10, y, th.left + 620, y);
            y += 12;
        };
        pair(QString::fromUtf8("Придбано"), QString::fromUtf8("%1 поз.").arg(rows.size()));
        pair(QString::fromUtf8("Кількість"), QString::fromUtf8("%1 %2").arg(FormatUtils::smartQty(qtySum), oilStore ? QString::fromUtf8("л") : QString::fromUtf8("од.")));
        separator();
        pair(QString::fromUtf8("Вартість"), money0(purchaseTotal) + QString::fromUtf8(" грн"));
        pair(QString::fromUtf8("Доданий %"), money0(addedTotal) + QString::fromUtf8(" грн"));
        pair(QString::fromUtf8("Разом"), money0(clientTotal) + QString::fromUtf8(" грн"));
    };

    for (auto it = groups.cbegin(); it != groups.cend(); ++it) {
        drawStorePage(it.key(), it.value());
    }
    finalizeAndOpenPdf(this, p, path);
}

void ReportsPage::exportOutsourcePdf()
{
    const QString df = m_from->date().toString("yyyy-MM-dd");
    const QString dt = m_to->date().toString("yyyy-MM-dd");
    const QString path = makeAutoPdfPath(QStringLiteral("outsource_report"));

    int count = 0; double repairTotal = 0.0; double clientTotal = 0.0;
    const auto groups = collectOutsourceGroups(df, dt, count, repairTotal, clientTotal);

    QPdfWriter pdf(path);
    pdf.setPageSize(QPageSize(QPageSize::A4));
    pdf.setResolution(144);
    QPainter p(&pdf);
    p.setRenderHint(QPainter::Antialiasing, false);
    const PdfTheme th = buildTheme(pdf);
    int y = th.top;

    drawCenteredText(p, QRect(th.left, y, th.contentWidth, 34), QStringLiteral("CarServicePointG"), titleFont(24));
    y += 42;
    drawCenteredText(p, QRect(th.left, y, th.contentWidth, 24),
                     QString::fromUtf8("АУТСОРС: %1 — %2").arg(m_from->date().toString("dd.MM.yy"), m_to->date().toString("dd.MM.yy")),
                     titleFont(10));
    y += 40;

    const QStringList headers = {
        QString::fromUtf8("Дата\nвідправки"),
        QString::fromUtf8("Компанія"),
        QString::fromUtf8("Наряд"),
        QString::fromUtf8("Запчастина на ремонт"),
        QString::fromUtf8("Вартість\nремонту"),
        QString::fromUtf8("Ціна")
    };

    const QFont headerFont = bodyFont(8, false);
    const QFont cellFont = bodyFont(10, false);
    const int minDateW = mmToPx(&pdf, 22);
    const int minCompanyW = mmToPx(&pdf, 30);
    const int minOrderW = mmToPx(&pdf, 12);
    const int minPartW = mmToPx(&pdf, 42);
    const int minRepairW = mmToPx(&pdf, 20);
    const int minPriceW = mmToPx(&pdf, 18);
    const int cellPad = 18;

    QFontMetrics hfm(headerFont);
    QFontMetrics cfm(cellFont);
    auto maxLineWidth = [](const QString& s, const QFontMetrics& fm) {
        int best = 0;
        for (const QString& line : s.split('\n')) best = qMax(best, fm.horizontalAdvance(line));
        return best;
    };

    int dateW = qMax(minDateW, maxLineWidth(headers[0], hfm) + cellPad);
    int companyW = qMax(minCompanyW, maxLineWidth(headers[1], hfm) + cellPad);
    int orderW = qMax(minOrderW, maxLineWidth(headers[2], hfm) + cellPad);
    int repairW = qMax(minRepairW, maxLineWidth(headers[4], hfm) + cellPad);
    int priceW = qMax(minPriceW, maxLineWidth(headers[5], hfm) + cellPad);

    for (auto it = groups.cbegin(); it != groups.cend(); ++it) {
        companyW = qMax(companyW, cfm.horizontalAdvance(it.key()) + cellPad);
        for (const auto& r : it.value()) {
            dateW = qMax(dateW, cfm.horizontalAdvance(r.date) + cellPad);
            orderW = qMax(orderW, cfm.horizontalAdvance(r.orderNumber) + cellPad);
            repairW = qMax(repairW, cfm.horizontalAdvance(money0(r.repairCost)) + cellPad);
            priceW = qMax(priceW, cfm.horizontalAdvance(money0(r.clientPrice)) + cellPad);
        }
    }

    repairW = qMax(repairW, cfm.horizontalAdvance(QStringLiteral("99 999")) + cellPad);
    priceW = qMax(priceW, cfm.horizontalAdvance(QStringLiteral("99 999")) + cellPad);

    QVector<int> w = { dateW, companyW, orderW, 0, repairW, priceW };
    int fixedSum = dateW + companyW + orderW + repairW + priceW;
    w[3] = qMax(minPartW, th.contentWidth - fixedSum);
    int total = fixedSum + w[3];
    if (total > th.contentWidth) {
        int overflow = total - th.contentWidth;
        int reducibleCompany = qMax(0, companyW - minCompanyW);
        int takeCompany = qMin(overflow, reducibleCompany);
        companyW -= takeCompany;
        overflow -= takeCompany;

        int reducibleDate = qMax(0, dateW - minDateW);
        int takeDate = qMin(overflow, reducibleDate);
        dateW -= takeDate;
        overflow -= takeDate;

        int reducibleRepair = qMax(0, repairW - minRepairW);
        int takeRepair = qMin(overflow, reducibleRepair);
        repairW -= takeRepair;
        overflow -= takeRepair;

        int reduciblePrice = qMax(0, priceW - minPriceW);
        int takePrice = qMin(overflow, reduciblePrice);
        priceW -= takePrice;
        overflow -= takePrice;

        int reducibleOrder = qMax(0, orderW - minOrderW);
        int takeOrder = qMin(overflow, reducibleOrder);
        orderW -= takeOrder;
        overflow -= takeOrder;

        Q_UNUSED(overflow);
        w = { dateW, companyW, orderW, qMax(minPartW, th.contentWidth - (dateW + companyW + orderW + repairW + priceW)), repairW, priceW };
    }
    int sum = 0; for (int v : w) sum += v;
    if (sum != th.contentWidth) w[3] += th.contentWidth - sum;

    const int companyHeaderH = 24;
    const int tableHeaderH = 40;
    const int minRowH = 24;

    for (auto it = groups.cbegin(); it != groups.cend(); ++it) {
        drawCell(p, QRect(th.left, y, th.contentWidth, companyHeaderH), it.key(), bodyFont(9, false), Qt::AlignLeft|Qt::AlignVCenter, Qt::white, 0.5);
        y += companyHeaderH;

        int x = th.left;
        for (int i = 0; i < headers.size(); ++i) {
            drawCell(p, QRect(x, y, w[i], tableHeaderH), headers[i], headerFont, Qt::AlignCenter, Qt::white, 0.5);
            x += w[i];
        }
        y += tableHeaderH;

        for (const auto& r : it.value()) {
            QStringList cells = { r.date, r.company, r.orderNumber, r.partName, money0(r.repairCost), money0(r.clientPrice) };
            int rowH = minRowH;
            for (int i = 0; i < cells.size(); ++i) rowH = qMax(rowH, wrappedHeight(p, cells[i], cellFont, w[i], 20));
            x = th.left;
            for (int i = 0; i < cells.size(); ++i) {
                Qt::Alignment a = (i >= 4) ? (Qt::AlignRight|Qt::AlignVCenter)
                                           : ((i == 2) ? (Qt::AlignCenter|Qt::AlignVCenter)
                                                       : (Qt::AlignLeft|Qt::AlignVCenter));
                drawCell(p, QRect(x, y, w[i], rowH), cells[i], cellFont, a, Qt::white, 0.5);
                x += w[i];
            }
            y += rowH;
        }

        y += 10;
    }

    y += 10;
    p.setFont(bodyFont(12));
    auto pair = [&](const QString& l, const QString& v) {
        p.drawText(QRect(th.left, y, 260, 24), Qt::AlignLeft|Qt::AlignVCenter, l);
        p.drawText(QRect(th.left+340, y, 200, 24), Qt::AlignLeft|Qt::AlignVCenter, v);
        y += 26;
    };
    pair(QString::fromUtf8("Відправлено на ремонт:"), QString::number(count));
    pair(QString::fromUtf8("Вартість ремонту:"), money0(repairTotal) + QString::fromUtf8(" грн"));
    pair(QString::fromUtf8("Маржа:"), money0(clientTotal - repairTotal) + QString::fromUtf8(" грн"));
    finalizeAndOpenPdf(this, p, path);
}

void ReportsPage::exportExpensesPdf()
{
    const QString fromText = m_from->date().toString("dd.MM.yy");
    const QString toText = m_to->date().toString("dd.MM.yy");
    const QString subtitle = QString::fromUtf8("Період: %1 — %2").arg(fromText, toText);
    exportTablePdf(m_expensesTable, QString::fromUtf8("Витрати"), subtitle, "expenses_report.pdf");
}

void ReportsPage::exportPayrollPdf()
{
    const QString df = m_from->date().toString("yyyy-MM-dd");
    const QString dt = m_to->date().toString("yyyy-MM-dd");
    const QString path = makeAutoPdfPath(QStringLiteral("payroll_report"));

    const auto masters = collectPayrollDetails(df, dt);
    QPdfWriter pdf(path);
    pdf.setPageSize(QPageSize(QPageSize::A4));
    pdf.setResolution(144);
    QPainter p(&pdf);
    p.setRenderHint(QPainter::Antialiasing, false);
    const PdfTheme th = buildTheme(pdf);
    bool firstPage = true;

    QVector<int> w = {
        mmToPx(&pdf,18), // Дата
        mmToPx(&pdf,12), // № наряду
        mmToPx(&pdf,52), // Держ.номер / марка авто
        0,               // Виконані роботи
        mmToPx(&pdf,24)  // Вартість робіт
    };
    const int fixed = w[0] + w[1] + w[2] + w[4];
    w[3] = qMax(mmToPx(&pdf,78), th.contentWidth - fixed);
    QStringList headers = { QString::fromUtf8("Дата"), QString::fromUtf8("№ наряду"), QString::fromUtf8("Держ.номер / марка авто"), QString::fromUtf8("Виконані роботи"), QString::fromUtf8("Вартість\nробіт") };

    const auto adminSources = loadAdminSalarySources();
    const AdminSalaryTotals adminTotals = collectAdminSalaryTotals(df, dt);

    for (const auto& m : masters) {
        if (!firstPage) pdf.newPage();
        firstPage = false;
        int y = th.top;
        drawCenteredText(p, QRect(th.left, y, th.contentWidth, 34), QStringLiteral("CarServicePointG"), titleFont(24));
        y += 36;
        p.setPen(QPen(Qt::black, 2));
        p.drawLine(th.left + mmToPx(&pdf, 42), y, th.right - mmToPx(&pdf, 42), y);
        y += 18;
        drawCenteredText(p, QRect(th.left, y, th.contentWidth, 28),
                         QString::fromUtf8("ЗАРПЛАТА ЗА ПЕРІОД: %1 — %2").arg(m_from->date().toString("dd.MM.yy"), m_to->date().toString("dd.MM.yy")),
                         titleFont(11));
        y += 52;
        const bool isAdmin = m.masterName.startsWith(QString::fromUtf8("Адмін:"));
        const QString displayName = isAdmin ? m.masterName.mid(QString::fromUtf8("Адмін:").size()).trimmed() : m.masterName;
        const QString roleTitle = isAdmin ? QString::fromUtf8("Адмін") : QString::fromUtf8("Майстер");
        p.setFont(bodyFont(16, true));
        p.drawText(QRect(th.left, y, th.contentWidth, 28), Qt::AlignLeft|Qt::AlignVCenter,
                   QString::fromUtf8("%1: %2").arg(roleTitle, displayName));
        y += 42;
        p.setFont(bodyFont(11));
        p.drawText(QRect(th.left, y, th.contentWidth, 22), Qt::AlignLeft|Qt::AlignVCenter,
                   QString::fromUtf8("Період: %1 — %2").arg(m_from->date().toString("dd.MM.yy"), m_to->date().toString("dd.MM.yy")));
        y += 26;

        int x = th.left;
        if (isAdmin) {
            const QString source = adminSources.value(m.masterId, QStringLiteral("margin"));
            const double purchase = adminTotals.purchaseTotal;
            const double margin = adminTotals.margin;
            const double fullSum = purchase + margin;
            const double accrued = qRound64(adminSalaryBaseForSource(adminTotals, source) * m.percent / 100.0);
            QVector<int> aw = {
                mmToPx(&pdf, 28),
                mmToPx(&pdf, 38),
                mmToPx(&pdf, 34),
                mmToPx(&pdf, 30),
                0
            };
            const int afixed = aw[0] + aw[1] + aw[2] + aw[3];
            aw[4] = qMax(mmToPx(&pdf, 34), th.contentWidth - afixed);
            QStringList aheaders = {
                QString::fromUtf8("Кіл-ть\nнарядів"),
                QString::fromUtf8("Замовлено\nзапчастин (од)"),
                QString::fromUtf8("Ціна\nзакупки"),
                QString::fromUtf8("Доданий\n%"),
                QString::fromUtf8("Повна\nсума")
            };
            for (int i=0;i<aheaders.size();++i) {
                drawCell(p, QRect(x, y, aw[i], 38), aheaders[i], bodyFont(7, false), Qt::AlignCenter, QColor(220,220,220), 2);
                x += aw[i];
            }
            y += 38;

            QStringList acells = {
                QString::number(adminTotals.ordersCount),
                QString::number(qRound64(adminTotals.partsQty)),
                money0(purchase) + QString::fromUtf8(" грн"),
                money0(margin) + QString::fromUtf8(" грн"),
                money0(fullSum) + QString::fromUtf8(" грн")
            };
            int rowH = 42;
            x = th.left;
            for (int i=0;i<acells.size();++i) {
                const Qt::Alignment a = (i >= 2) ? (Qt::AlignRight|Qt::AlignVCenter) : (Qt::AlignCenter|Qt::AlignVCenter);
                drawCell(p, QRect(x, y, aw[i], rowH), acells[i], bodyFont(10), a, Qt::white, 2);
                x += aw[i];
            }
            y += rowH;

            y += 24;

            auto pair = [&](const QString& l, const QString& v, bool emph = false) {
                QFont lf = bodyFont(14, emph);
                lf.setUnderline(emph);
                p.setFont(lf);
                p.drawText(QRect(th.left, y, 260, 28), Qt::AlignLeft|Qt::AlignVCenter, l);
                p.drawText(QRect(th.left + 300, y, 240, 28), Qt::AlignLeft|Qt::AlignVCenter, v);
                y += 30;
            };
            pair(QString::fromUtf8("Нараховано:"), money0(accrued) + QString::fromUtf8(" грн"), true);
            continue;
        }

        for (int i=0;i<headers.size();++i) { drawCell(p, QRect(x, y, w[i], 38), headers[i], bodyFont(7, false), Qt::AlignCenter, QColor(220,220,220), 2); x += w[i]; }
        y += 38;

        for (const auto& row : m.orders) {
            QStringList cells = { row.dateStart, row.orderNumber, row.car, row.works, money0(row.masterAmount) + QString::fromUtf8(" грн") };
            int rowH = 38;
            for (int i=0;i<cells.size();++i) rowH = qMax(rowH, wrappedHeight(p, cells[i], bodyFont(10), w[i], 34));
            x = th.left;
            for (int i=0;i<cells.size();++i) {
                Qt::Alignment a = (i == 4) ? (Qt::AlignRight|Qt::AlignTop) : (Qt::AlignLeft|Qt::AlignTop);
                drawCell(p, QRect(x, y, w[i], rowH), cells[i], bodyFont(10), a, Qt::white, 2);
                x += w[i];
            }
            y += rowH;
        }

        x = th.left;
        drawCell(p, QRect(x, y, w[0]+w[1]+w[2]+w[3], 28), QString::fromUtf8("ПІДСУМОК"), bodyFont(10, true), Qt::AlignCenter, Qt::white, 2);
        drawCell(p, QRect(x + w[0]+w[1]+w[2]+w[3], y, w[4], 28), money0(m.accrued) + QString::fromUtf8(" грн"), bodyFont(10, true), Qt::AlignRight|Qt::AlignVCenter, Qt::white, 2);
        y += 44;

        auto pair = [&](const QString& l, const QString& v, bool emph = false) {
            QFont lf = bodyFont(14, emph);
            lf.setUnderline(emph);
            p.setFont(lf);
            p.drawText(QRect(th.left, y, 260, 28), Qt::AlignLeft|Qt::AlignVCenter, l);
            p.drawText(QRect(th.left + 300, y, 240, 28), Qt::AlignLeft|Qt::AlignVCenter, v);
            y += 30;
        };
        pair(QString::fromUtf8("Виконано нарядів:"), QString::number(m.ordersCount));
        pair(QString::fromUtf8("Нараховано:"), money0(m.accrued) + QString::fromUtf8(" грн"), true);
    }
    finalizeAndOpenPdf(this, p, path);
}

void ReportsPage::exportTablePdf(QTableWidget* table, const QString& title, const QString& subtitle, const QString& suggestedName)
{
    if (!table) return;
    const QString path = makeAutoPdfPath(suggestedName);

    QPdfWriter pdf(path);
    pdf.setPageSize(QPageSize(QPageSize::A4));
    pdf.setResolution(144);

    QPainter p(&pdf);
    p.setRenderHint(QPainter::Antialiasing, true);

    const int left = mmToPx(&pdf, 20);
    const int right = pdf.width() - mmToPx(&pdf, 10);
    int y = mmToPx(&pdf, 15);

    p.setFont(titleFont(18));
    p.drawText(QRect(left, y, right - left, 28), Qt::AlignLeft | Qt::AlignVCenter, title);
    y += 34;

    p.setFont(bodyFont(10));
    p.drawText(QRect(left, y, right - left, 20), Qt::AlignLeft | Qt::AlignVCenter, subtitle);
    y += 26;

    const int cols = table->columnCount();
    if (cols <= 0) return;
    const int totalWidth = right - left;
    QVector<int> widths(cols, totalWidth / cols);
    int stretchCol = 0;
    int fixedSum = 0;
    for (int c = 0; c < cols; ++c) {
        int w = qMax(80, table->columnWidth(c));
        widths[c] = w;
        fixedSum += w;
        if (table->horizontalHeader()->sectionResizeMode(c) == QHeaderView::Stretch) stretchCol = c;
    }
    if (fixedSum != totalWidth && cols > 0) {
        widths[stretchCol] += (totalWidth - fixedSum);
        if (widths[stretchCol] < 100) widths[stretchCol] = 100;
    }

    int x = left;
    for (int c = 0; c < cols; ++c) {
        drawCell(p, QRect(x, y, widths[c], 34), table->horizontalHeaderItem(c)->text(), bodyFont(8, true), Qt::AlignCenter, QColor(220,220,220), 1);
        x += widths[c];
    }
    y += 34;

    for (int r = 0; r < table->rowCount(); ++r) {
        if (y > pdf.height() - 100) {
            pdf.newPage();
            y = mmToPx(&pdf, 15);
        }
        x = left;
        const bool spanned = table->columnSpan(r, 0) > 1;
        if (spanned) {
            QRect rect(left, y, totalWidth, 24);
            drawCell(p, rect, table->item(r, 0) ? table->item(r, 0)->text() : QString(), bodyFont(8, true), Qt::AlignLeft | Qt::AlignVCenter, QColor(240,240,240), 1);
            y += 24;
            continue;
        }
        int rowH = 28;
        for (int c = 0; c < cols; ++c) {
            const auto* item = table->item(r, c);
            rowH = qMax(rowH, wrappedHeight(p, item ? item->text() : QString(), bodyFont(8), widths[c], 22));
        }
        for (int c = 0; c < cols; ++c) {
            const auto* item = table->item(r, c);
            drawCell(p, QRect(x, y, widths[c], rowH), item ? item->text() : QString(), bodyFont(8), Qt::AlignLeft | Qt::AlignVCenter, Qt::white, 1);
            x += widths[c];
        }
        y += rowH;
    }

    finalizeAndOpenPdf(this, p, path);
}
