#pragma once

#include <QWidget>

class StatsPage : public QWidget
{
    Q_OBJECT
public:
    explicit StatsPage(QWidget* parent=nullptr);
};
