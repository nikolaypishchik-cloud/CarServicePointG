#include "ui/tabs/statistics/StatsPage.h"

#include <QVBoxLayout>
#include <QLabel>

StatsPage::StatsPage(QWidget* parent)
    : QWidget(parent)
{
    auto* l = new QVBoxLayout(this);
    l->setContentsMargins(0,0,0,0);

    auto* t = new QLabel(QString::fromUtf8("Статистика (етап 1): базові графіки/агрегації буде перенесено наступним кроком."), this);
    t->setWordWrap(true);
    l->addWidget(t);
    l->addStretch(1);
}
