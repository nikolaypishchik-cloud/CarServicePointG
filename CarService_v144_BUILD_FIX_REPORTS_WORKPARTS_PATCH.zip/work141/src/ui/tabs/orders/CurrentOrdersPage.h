#pragma once

#include <QWidget>
#include <QSqlQueryModel>
#include <QList>

class QSortFilterProxyModel;

class QTableView;
class QLineEdit;

class CurrentOrdersPage : public QWidget
{
    Q_OBJECT
public:
    explicit CurrentOrdersPage(QWidget* parent=nullptr);

    void refresh();

signals:
    void requestRefreshAll();

private:
    int selectedOrderNumber() const;
    QList<int> selectedOrderNumbers() const;

    QSqlQueryModel* m_model = nullptr;
    QSortFilterProxyModel* m_proxy = nullptr;
    QTableView* m_table = nullptr;
    QLineEdit* m_search = nullptr;
};
