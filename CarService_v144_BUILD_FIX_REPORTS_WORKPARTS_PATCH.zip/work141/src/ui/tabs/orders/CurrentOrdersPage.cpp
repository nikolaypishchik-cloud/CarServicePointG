#include "ui/tabs/orders/CurrentOrdersPage.h"

#include "infrastructure/db/sqlite/Db.h"
#include "ui/common/dialogs/OrderDialog.h"
#include "core/util/FormatUtils.h"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QToolButton>
#include <QTableView>
#include <QHeaderView>
#include <QLineEdit>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDateTime>
#include <QSortFilterProxyModel>
#include <algorithm>


namespace {
static QString displayDateShort(const QVariant& v)
{
    const QString raw = v.toString().trimmed();
    if (raw.isEmpty()) return QString();
    QString t = raw;
    const int tpos = t.indexOf('T');
    if (tpos > 0) t = t.left(tpos);
    for (const QString& fmt : {QStringLiteral("yyyy-MM-dd"), QStringLiteral("dd.MM.yy"), QStringLiteral("dd.MM.yyyy")}) {
        const QDate d = QDate::fromString(t, fmt);
        if (d.isValid()) return d.toString(QStringLiteral("dd.MM.yy"));
    }
    return raw;
}

class CurrentOrdersDisplayProxy final : public QSortFilterProxyModel {
public:
    using QSortFilterProxyModel::QSortFilterProxyModel;
    QVariant data(const QModelIndex& index, int role) const override
    {
        if (!index.isValid()) return QSortFilterProxyModel::data(index, role);
        if (role == Qt::DisplayRole) {
            const QVariant src = QSortFilterProxyModel::data(index, role);
            switch (index.column()) {
            case 1: return displayDateShort(src);
            case 7:
            case 8: return FormatUtils::money(src.toDouble(), 0);
            default: break;
            }
        }
        return QSortFilterProxyModel::data(index, role);
    }
};
}

CurrentOrdersPage::CurrentOrdersPage(QWidget* parent)
    : QWidget(parent)
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(0,0,0,0);
    root->setSpacing(10);

    // Toolbar
    auto* bar = new QHBoxLayout();
    bar->setContentsMargins(0,0,0,0);

    auto* btnNew = new QToolButton(this);
    btnNew->setText(QString::fromUtf8("➕ Новий"));
    auto* btnEdit = new QToolButton(this);
    btnEdit->setText(QString::fromUtf8("✏️ Редагувати"));
    auto* btnDelete = new QToolButton(this);
    btnDelete->setText(QString::fromUtf8("🗑️ Видалити"));
    auto* btnClose = new QToolButton(this);
    btnClose->setText(QString::fromUtf8("✅ Закрити"));

    m_search = new QLineEdit(this);
    m_search->setPlaceholderText(QString::fromUtf8("Пошук: марка, номер, VIN, клієнт…"));

    m_search->setMinimumWidth(360);
    m_search->setMaximumWidth(460);

    bar->addWidget(m_search, 0, Qt::AlignLeft);
    bar->addSpacing(12);
    bar->addWidget(btnNew);
    bar->addWidget(btnEdit);
    bar->addWidget(btnDelete);
    bar->addWidget(btnClose);
    bar->addStretch(1);

    root->addLayout(bar);

    // Table
    m_table = new QTableView(this);
    m_table->setObjectName("premiumCurrentOrdersTable");
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::ExtendedSelection);
    m_table->setAlternatingRowColors(false);
    m_table->setSortingEnabled(true);
    m_table->setMouseTracking(true);
    m_table->setShowGrid(true);
    m_table->setWordWrap(false);
    m_table->setCornerButtonEnabled(false);
    m_table->verticalHeader()->setVisible(false);
    m_table->verticalHeader()->setDefaultSectionSize(34);
    m_table->horizontalHeader()->setHighlightSections(false);
    m_table->horizontalHeader()->setSortIndicatorShown(true);

    m_model = new QSqlQueryModel(this);
    m_proxy = new CurrentOrdersDisplayProxy(this);
    m_proxy->setSourceModel(m_model);
    m_proxy->setSortCaseSensitivity(Qt::CaseInsensitive);
    m_proxy->setDynamicSortFilter(true);
    m_table->setModel(m_proxy);

    auto* hh = m_table->horizontalHeader();
    hh->setStretchLastSection(true);
    hh->setDefaultAlignment(Qt::AlignCenter);
    hh->setMinimumSectionSize(54);
    hh->setSectionResizeMode(QHeaderView::Interactive);

    m_table->setColumnWidth(0, 66);   // №
    m_table->setColumnWidth(1, 178);  // Відкрито
    m_table->setColumnWidth(2, 108);  // Статус
    m_table->setColumnWidth(3, 130);  // Номер
    m_table->setColumnWidth(4, 210);  // Авто
    m_table->setColumnWidth(5, 170);  // Клієнт
    m_table->setColumnWidth(6, 130);  // Майстер
    m_table->setColumnWidth(7, 110);  // Роботи
    m_table->setColumnWidth(8, 130);  // Запчастини

    m_table->sortByColumn(1, Qt::DescendingOrder);

    root->addWidget(m_table, 1);

    connect(btnNew, &QToolButton::clicked, this, [this]() {
        OrderDialog dlg(this);
        dlg.setWindowTitle(QString::fromUtf8("Новий наряд"));
        if (dlg.exec() == QDialog::Accepted) {
            emit requestRefreshAll();
        }
    });

    connect(btnEdit, &QToolButton::clicked, this, [this]() {
        int num = selectedOrderNumber();
        if (num <= 0) return;
        OrderDialog dlg(this, num);
        dlg.setWindowTitle(QString::fromUtf8("Редагування наряду"));
        dlg.openWorkPartsTab();
        if (dlg.exec() == QDialog::Accepted) {
            emit requestRefreshAll();
        }
    });

    connect(m_table, &QTableView::doubleClicked, this, [this](const QModelIndex&) {
        int num = selectedOrderNumber();
        if (num <= 0) return;
        OrderDialog dlg(this, num);
        dlg.setWindowTitle(QString::fromUtf8("Редагування наряду"));
        dlg.openWorkPartsTab();
        if (dlg.exec() == QDialog::Accepted) {
            emit requestRefreshAll();
        }
    });

    connect(btnDelete, &QToolButton::clicked, this, [this]() {
    const QList<int> nums = selectedOrderNumbers();
    if (nums.isEmpty()) return;

    QString list;
    for (int n : nums) list += QString::number(n) + ", ";
    if (list.endsWith(", ")) list.chop(2);

    if (QMessageBox::question(this, QString::fromUtf8("Підтвердження"),
                              QString::fromUtf8("Видалити %1 нарядів?\n№: %2\n\nДія незворотна.")
                                  .arg(nums.size()).arg(list))
        != QMessageBox::Yes) {
        return;
    }

    QSqlDatabase d = Database::db();
    if (!d.transaction()) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не можу відкрити транзакцію"));
        return;
    }

    QSqlQuery q(d);
    q.prepare("DELETE FROM work_orders WHERE number=?");
    for (int n : nums) {
        q.addBindValue(n);
        if (!q.exec()) {
            d.rollback();
            QMessageBox::critical(this, QString::fromUtf8("Помилка"), q.lastError().text());
            return;
        }
        q.finish();
    }

    d.commit();
    emit requestRefreshAll();
});

    connect(btnClose, &QToolButton::clicked, this, [this]() {
    const QList<int> nums = selectedOrderNumbers();
    if (nums.isEmpty()) return;

    QString list;
    for (int n : nums) list += QString::number(n) + ", ";
    if (list.endsWith(", ")) list.chop(2);

    if (QMessageBox::question(this, QString::fromUtf8("Підтвердження"),
                              QString::fromUtf8("Закрити %1 нарядів?\n№: %2").arg(nums.size()).arg(list))
        != QMessageBox::Yes) {
        return;
    }

    QSqlDatabase d = Database::db();
    if (!d.transaction()) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не можу відкрити транзакцію"));
        return;
    }

    for (int num : nums) {
        // snapshot master name at close time
        QSqlQuery m(d);
        m.prepare("SELECT master_id FROM work_orders WHERE number=?");
        m.addBindValue(num);
        QString mid;
        if (m.exec() && m.next()) mid = m.value(0).toString();
        QString mname;
        if (!mid.isEmpty()) {
            QSqlQuery mn(d);
            mn.prepare("SELECT name FROM masters WHERE id=?");
            mn.addBindValue(mid);
            if (mn.exec() && mn.next()) mname = mn.value(0).toString();
        }

        QSqlQuery q(d);
        q.prepare("UPDATE work_orders SET status='closed', closed_at=?, master_name_closed=? WHERE number=?");
        q.addBindValue(QDateTime::currentDateTime().toString(Qt::ISODate));
        q.addBindValue(mname);
        q.addBindValue(num);
        if (!q.exec()) {
            d.rollback();
            QMessageBox::critical(this, QString::fromUtf8("Помилка"), q.lastError().text());
            return;
        }

        // Freeze master names for service_masters as well
        QSqlQuery sm(d);
        sm.prepare("UPDATE service_masters SET master_name_closed=(SELECT name FROM masters WHERE id=service_masters.master_id) "
                   "WHERE service_id IN (SELECT id FROM work_order_services WHERE order_number=?)");
        sm.addBindValue(num);
        sm.exec();
    }

    d.commit();
    emit requestRefreshAll();
});

    connect(m_search, &QLineEdit::textChanged, this, [this]() { refresh(); });

    refresh();
}

int CurrentOrdersPage::selectedOrderNumber() const
{
    if (!m_table || !m_model) return -1;
    QModelIndex idx = m_table->currentIndex();
    if (!idx.isValid() || !m_proxy) return -1;
    QModelIndex srcIdx = m_proxy->mapToSource(idx.sibling(idx.row(), 0));
    if (!srcIdx.isValid()) return -1;
    bool ok = false;
    int num = m_model->data(srcIdx).toInt(&ok);
    return ok ? num : -1;

}

QList<int> CurrentOrdersPage::selectedOrderNumbers() const
{
    QList<int> out;
    if (!m_table || !m_model || !m_proxy) return out;
    auto* sel = m_table->selectionModel();
    if (!sel) return out;

    const QModelIndexList rows = sel->selectedRows(0);
    for (const QModelIndex& idx : rows) {
        QModelIndex srcIdx = m_proxy->mapToSource(idx);
        bool ok = false;
        int num = m_model->data(srcIdx).toInt(&ok);
        if (ok) out.append(num);
    }
    std::sort(out.begin(), out.end());
    out.erase(std::unique(out.begin(), out.end()), out.end());
    return out;
}

void CurrentOrdersPage::refresh()
{
    const QString filter = m_search ? m_search->text().trimmed() : QString();

    auto escapeLike = [](const QString& s) {
        QString out = s;
        out.replace(QStringLiteral("\\"), QStringLiteral("\\\\"));
        out.replace(QStringLiteral("%"),  QStringLiteral("\\%"));
        out.replace(QStringLiteral("_"),  QStringLiteral("\\_"));
        return out;
    };
    auto makeFtsQuery = [](const QString& s) {
        // Turn user input into: token1* AND token2* ...
        QStringList toks = s.simplified().split(' ', Qt::SkipEmptyParts);
        for (QString& tok : toks) {
            tok.replace('"', ' ');
            tok = tok.trimmed();
            if (tok.isEmpty()) continue;
            // Prefix match
            if (!tok.endsWith('*')) tok += '*';
        }
        toks.removeAll(QString());
        return toks.isEmpty() ? QString() : toks.join(QStringLiteral(" AND "));
    };

    QSqlQuery q(Database::db());

QString sql =
    "SELECT o.number AS '№', "
    "       o.opened_at AS 'Відкрито', "
        "       o.status AS 'Статус', "
        "       o.plate AS 'Номер', "
        "       o.car AS 'Авто', "
        "       o.client AS 'Клієнт', "
        "       COALESCE(NULLIF(o.master_name_closed,''), (SELECT name FROM masters m WHERE m.id=o.master_id), '') AS 'Майстер', "
        "       o.works_sum AS 'Роботи', "
        "       o.parts_sum AS 'Запчастини' "
        "FROM work_orders o "
        "WHERE o.status != 'closed'";

    QString whereExtra;
    QString fts = makeFtsQuery(filter);
    if (!fts.isEmpty()) {
        whereExtra += " AND o.number IN (SELECT rowid FROM work_orders_fts WHERE work_orders_fts MATCH :m)";
    } else if (!filter.isEmpty()) {
        whereExtra += " AND (o.car LIKE :p ESCAPE '\\' "
                      " OR o.plate LIKE :p ESCAPE '\\' "
                      " OR o.vin LIKE :p ESCAPE '\\' "
                      " OR o.client LIKE :p ESCAPE '\\' "
                      " OR CAST(o.number AS TEXT) LIKE :p ESCAPE '\\')";
    }

    sql += whereExtra;
    sql += " ORDER BY o.opened_at DESC";

    q.prepare(sql);
    if (!fts.isEmpty()) {
        q.bindValue(":m", fts);
    } else if (!filter.isEmpty()) {
        q.bindValue(":p", "%" + escapeLike(filter) + "%");
    }

    if (!q.exec()) {
        qWarning() << "CurrentOrdersPage query error" << q.lastError().text();
    }
    m_model->setQuery(q);

    if (m_model->lastError().isValid()) {
        qWarning() << "CurrentOrdersPage model error" << m_model->lastError().text();
    }

    if (m_proxy) {
        m_proxy->sort(m_table->horizontalHeader()->sortIndicatorSection(),
                      m_table->horizontalHeader()->sortIndicatorOrder());
    }
}

