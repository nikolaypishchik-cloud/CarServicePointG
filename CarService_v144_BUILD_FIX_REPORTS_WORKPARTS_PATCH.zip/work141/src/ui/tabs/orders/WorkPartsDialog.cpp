#include "ui/tabs/orders/WorkPartsDialog.h"

#include "infrastructure/db/sqlite/Db.h"
#include "core/util/FormatUtils.h"

#include <QByteArray>
#include <QComboBox>
#include <QCoreApplication>
#include <QDate>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFrame>
#include <QHeaderView>
#include <QHBoxLayout>
#include <QInputDialog>
#include <QKeyEvent>
#include <QLabel>
#include <QLineEdit>
#include <QMenu>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QDateEdit>
#include <QDoubleSpinBox>
#include <QFormLayout>
#include <QPlainTextEdit>
#include <QUuid>
#include <QMessageBox>
#include <QPushButton>
#include <QSignalBlocker>
#include <QStyledItemDelegate>
#include <QAbstractButton>
#include <QSplitter>
#include <QSqlError>
#include <QSqlQuery>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QTimer>
#include <QVBoxLayout>

namespace {
constexpr int RoleId = Qt::UserRole + 1;
constexpr int RoleIsHint = Qt::UserRole + 2;
constexpr int RolePurchasePrice = Qt::UserRole + 3;
constexpr int RoleDisplayPrice = Qt::UserRole + 4;
constexpr int RoleMarkupPercent = Qt::UserRole + 5;

static QString serviceHintText()
{
    return QString::fromUtf8("+ Додати роботу… (Enter = наступна, Tab = вправо)");
}

static QString partHintText()
{
    return QString::fromUtf8("+ Додати запчастину… (Tab = кількість → ціна → магазин)");
}

static bool isServiceHintValue(const QString& text)
{
    const QString t = text.simplified().trimmed();
    return t.isEmpty() || t.startsWith(QString::fromUtf8("+ Додати роботу"));
}

static bool isPartHintValue(const QString& text)
{
    const QString t = text.simplified().trimmed();
    return t.isEmpty() || t.startsWith(QString::fromUtf8("+ Додати запчастину"));
}

static QString normalizeSentence(const QString& s)
{
    QString t = s.simplified().trimmed();
    if (t.isEmpty()) return t;
    for (int i = 0; i < t.size(); ++i) {
        if (t[i].isLetter()) {
            t[i] = t[i].toUpper();
            break;
        }
    }
    return t;
}

static QString currentOrderDateDisplay()
{
    return QDate::currentDate().toString(QStringLiteral("dd.MM.yy"));
}

static QString displayDateFromStored(const QString& raw)
{
    const QString t = raw.trimmed();
    if (t.isEmpty()) return currentOrderDateDisplay();
    QDate d = QDate::fromString(t, Qt::ISODate);
    if (!d.isValid()) d = QDate::fromString(t, QStringLiteral("dd.MM.yy"));
    if (!d.isValid()) d = QDate::fromString(t, QStringLiteral("dd.MM.yyyy"));
    return d.isValid() ? d.toString(QStringLiteral("dd.MM.yy")) : t;
}

static QString storedDateFromDisplay(const QString& raw)
{
    const QString t = raw.trimmed();
    if (t.isEmpty()) return QDate::currentDate().toString(Qt::ISODate);
    QDate d = QDate::fromString(t, QStringLiteral("dd.MM.yy"));
    if (!d.isValid()) d = QDate::fromString(t, QStringLiteral("dd.MM.yyyy"));
    if (!d.isValid()) d = QDate::fromString(t, Qt::ISODate);
    return d.isValid() ? d.toString(Qt::ISODate) : QDate::currentDate().toString(Qt::ISODate);
}


static double parseLooseNumber(QString text, bool* ok = nullptr)
{
    text = text.trimmed();
    text.remove(' ');
    text.replace(',', '.');
    const double v = text.toDouble(ok);
    return v;
}

static void restoreHeaderState(QHeaderView* header, const QString& key)
{
    if (!header || key.trimmed().isEmpty()) return;
    const QString raw = Database::getSetting(key, QString()).toString();
    if (raw.trimmed().isEmpty()) return;
    header->restoreState(QByteArray::fromBase64(raw.toUtf8()));
}

static void bindHeaderStatePersistence(QHeaderView* header, const QString& key)
{
    if (!header || key.trimmed().isEmpty()) return;
    QObject::connect(header, &QHeaderView::sectionResized, header, [header, key](int, int, int) {
        Database::setSetting(key, QString::fromLatin1(header->saveState().toBase64()));
    });
    QObject::connect(header, &QHeaderView::sectionMoved, header, [header, key](int, int, int) {
        Database::setSetting(key, QString::fromLatin1(header->saveState().toBase64()));
    });
    QObject::connect(header, &QHeaderView::sortIndicatorChanged, header, [header, key](int, Qt::SortOrder) {
        Database::setSetting(key, QString::fromLatin1(header->saveState().toBase64()));
    });
}

static QString canonStoreKey(const QString& s)
{
    QString t = s.trimmed().toLower();
    t.replace(QChar(0x0456), QChar(0x0438));
    t.replace(QChar(0x0457), QChar(0x0438));
    t.replace(QChar(0x0454), QChar(0x0435));
    t.replace(QChar(0x0491), QChar(0x0433));
    QString out;
    out.reserve(t.size());
    for (const QChar& ch : t) {
        if (ch.isLetterOrNumber()) out.append(ch);
    }
    return out;
}

static bool isMotorOilPartName(const QString& name)
{
    const QString s = name.toLower();
    if (s.trimmed().isEmpty()) return false;
    if (s.contains(QString::fromUtf8("фільтр")) || s.contains("filter")) return false;
    const QStringList keys = {
        QString::fromUtf8("масло"), QString::fromUtf8("моторн"), QString::fromUtf8("двигун"),
        "motor oil", "engine oil", "oil",
        "5w", "0w", "10w", "15w", "20w", "sae", "acea", "api "
    };
    for (const auto& k : keys) {
        if (s.contains(k)) return true;
    }
    if (s.contains("oil") && (s.contains("seal") || s.contains(QString::fromUtf8("сальник")))) return false;
    return false;
}

static QMap<QString,double> loadMarkupMapFromSetting(const QString& settingKey)
{
    QMap<QString,double> out;
    const QString raw = Database::getSetting(settingKey, "{}").toString();
    const auto doc = QJsonDocument::fromJson(raw.toUtf8());
    if (!doc.isObject()) return out;
    const auto obj = doc.object();
    for (auto it = obj.begin(); it != obj.end(); ++it) {
        bool ok = false;
        const double v = it.value().toVariant().toDouble(&ok);
        const QString k = it.key().trimmed();
        if (!k.isEmpty() && ok) out.insert(k, v);
    }
    return out;
}

static QMap<QString,double> loadStoreMarkupMap()
{
    return loadMarkupMapFromSetting("settings.fin.store_markups");
}

static QMap<QString,double> loadOilStoreMarkupMap()
{
    return loadMarkupMapFromSetting("settings.fin.oil_store_markups");
}

static double lookupStoreMarkupPercent(const QMap<QString,double>& mp, const QString& store)
{
    const QString s = store.trimmed();
    if (s.isEmpty()) return 0.0;
    if (mp.contains(s)) return mp.value(s);
    const QString key = canonStoreKey(s);
    for (auto it = mp.begin(); it != mp.end(); ++it) {
        if (canonStoreKey(it.key()) == key) return it.value();
    }
    return 0.0;
}

static double effectivePartMarkupPercent(const QString& partName, const QString& store)
{
    const double defaultParts = Database::getSetting("settings.fin.parts_markup", "0").toDouble();
    const double oilMarkup = Database::getSetting("settings.fin.oil_markup", "0").toDouble();
    if (isMotorOilPartName(partName)) {
        const double oilStorePct = lookupStoreMarkupPercent(loadOilStoreMarkupMap(), store);
        return oilStorePct > 0.0 ? oilStorePct : oilMarkup;
    }
    const double storePct = lookupStoreMarkupPercent(loadStoreMarkupMap(), store);
    return storePct > 0.0 ? storePct : defaultParts;
}

static double applyMarkup(double purchasePrice, double pct)
{
    return purchasePrice * (1.0 + qMax(0.0, pct) / 100.0);
}

struct OutsourceCompanyEntry {
    QString id;
    QString company;
    QString address;
    QString contact;
    QString branch;
    QString note;
    double markup = 20.0;
};

struct OutsourceJobDraft {
    QDate sentDate = QDate::currentDate();
    QString partName;
    double companyPrice = 0.0;
    double markup = 20.0;
    double clientPrice = 0.0;
    QString note;
};

static QJsonObject outsourceCompanyToJson(const OutsourceCompanyEntry& e)
{
    QJsonObject o;
    o["id"] = e.id;
    o["company"] = e.company;
    o["address"] = e.address;
    o["contact"] = e.contact;
    o["branch"] = e.branch;
    o["note"] = e.note;
    o["markup"] = e.markup;
    return o;
}

static OutsourceCompanyEntry outsourceCompanyFromJson(const QJsonObject& o)
{
    OutsourceCompanyEntry e;
    e.id = o.value("id").toString();
    if (e.id.isEmpty()) e.id = QUuid::createUuid().toString(QUuid::WithoutBraces);
    e.company = o.value("company").toString();
    e.address = o.value("address").toString();
    e.contact = o.value("contact").toString();
    e.branch = o.value("branch").toString();
    e.note = o.value("note").toString();
    e.markup = o.value("markup").toDouble(20.0);
    return e;
}

static QList<OutsourceCompanyEntry> loadOutsourceCompanies()
{
    QList<OutsourceCompanyEntry> out;
    const auto raw = Database::getSetting("settings.out.items", QString()).toString();
    if (!raw.trimmed().isEmpty()) {
        const auto doc = QJsonDocument::fromJson(raw.toUtf8());
        if (doc.isArray()) {
            for (const auto& v : doc.array()) {
                if (v.isObject()) out.push_back(outsourceCompanyFromJson(v.toObject()));
            }
        }
    }
    if (out.isEmpty()) {
        out.push_back({QUuid::createUuid().toString(QUuid::WithoutBraces), QString::fromUtf8("Ремонт генераторів"), QString(), QString(), QString(), QString(), 20.0});
        out.push_back({QUuid::createUuid().toString(QUuid::WithoutBraces), QString::fromUtf8("Ремонт стартерів"), QString(), QString(), QString(), QString(), 20.0});
        out.push_back({QUuid::createUuid().toString(QUuid::WithoutBraces), QString::fromUtf8("Ремонт форсунок"), QString(), QString(), QString(), QString(), 20.0});
    }
    return out;
}

static void ensureOutsourceJobsTable()
{
    QSqlQuery q(Database::db());
    q.exec(QString::fromUtf8(
        "CREATE TABLE IF NOT EXISTS outsource_jobs ("
        " id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " order_number INTEGER NOT NULL,"
        " service_id INTEGER NOT NULL,"
        " company_id TEXT NOT NULL DEFAULT '',"
        " company_name TEXT NOT NULL DEFAULT '',"
        " sent_date TEXT NOT NULL DEFAULT '',"
        " part_name TEXT NOT NULL DEFAULT '',"
        " company_price REAL NOT NULL DEFAULT 0,"
        " markup_percent REAL NOT NULL DEFAULT 0,"
        " client_price REAL NOT NULL DEFAULT 0,"
        " note TEXT NOT NULL DEFAULT '',"
        " FOREIGN KEY(service_id) REFERENCES work_order_services(id) ON DELETE CASCADE"
        ");"));
}

static bool saveOutsourceJob(int orderNumber, int serviceId, const OutsourceCompanyEntry& company, const OutsourceJobDraft& draft, QWidget* parent)
{
    ensureOutsourceJobsTable();
    QSqlQuery del(Database::db());
    del.prepare("DELETE FROM outsource_jobs WHERE service_id=?");
    del.addBindValue(serviceId);
    if (!del.exec()) {
        QMessageBox::critical(parent, QString::fromUtf8("Помилка"), del.lastError().text());
        return false;
    }
    QSqlQuery ins(Database::db());
    ins.prepare("INSERT INTO outsource_jobs(order_number, service_id, company_id, company_name, sent_date, part_name, company_price, markup_percent, client_price, note) VALUES(?,?,?,?,?,?,?,?,?,?)");
    ins.addBindValue(orderNumber);
    ins.addBindValue(serviceId);
    ins.addBindValue(company.id);
    ins.addBindValue(company.company);
    ins.addBindValue(draft.sentDate.toString(Qt::ISODate));
    ins.addBindValue(draft.partName);
    ins.addBindValue(draft.companyPrice);
    ins.addBindValue(draft.markup);
    ins.addBindValue(draft.clientPrice);
    ins.addBindValue(draft.note);
    if (!ins.exec()) {
        QMessageBox::critical(parent, QString::fromUtf8("Помилка"), ins.lastError().text());
        return false;
    }
    return true;
}

static bool runOutsourceDetailDialog(QWidget* parent, int orderNumber, const OutsourceCompanyEntry& company, OutsourceJobDraft& draft)
{
    QDialog dlg(parent);
    dlg.setWindowTitle(QString::fromUtf8("Аутсорс — відправити запчастину на ремонт"));
    dlg.resize(980, 520);

    auto* root = new QVBoxLayout(&dlg);
    root->setContentsMargins(22, 22, 22, 22);
    root->setSpacing(18);

    auto* summary = new QLabel(QString::fromUtf8("Наряд: %1 | Компанія: <b>%2</b>").arg(orderNumber).arg(company.company), &dlg);
    summary->setTextFormat(Qt::RichText);
    summary->setStyleSheet(QString::fromUtf8("font-size:16pt;font-weight:700;"));
    root->addWidget(summary);

    auto* form = new QFormLayout();
    form->setLabelAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    form->setFormAlignment(Qt::AlignTop);
    form->setHorizontalSpacing(18);
    form->setVerticalSpacing(14);

    auto* sentDate = new QDateEdit(draft.sentDate.isValid() ? draft.sentDate : QDate::currentDate(), &dlg);
    sentDate->setCalendarPopup(true);
    sentDate->setDisplayFormat("dd.MM.yy");
    sentDate->setMinimumHeight(42);

    auto* partName = new QLineEdit(draft.partName, &dlg);
    partName->setPlaceholderText(QString::fromUtf8("Напр.: Ремінь генератора / Турбіна / Форсунка ..."));
    partName->setMinimumHeight(42);

    auto* companyPrice = new QDoubleSpinBox(&dlg);
    companyPrice->setRange(0.0, 10000000.0);
    companyPrice->setDecimals(2);
    companyPrice->setSuffix(QString::fromUtf8(" грн"));
    companyPrice->setValue(draft.companyPrice);
    companyPrice->setMinimumHeight(42);

    auto* markup = new QDoubleSpinBox(&dlg);
    markup->setRange(0.0, 1000.0);
    markup->setDecimals(1);
    markup->setSuffix(QString::fromUtf8(" %"));
    markup->setValue(draft.markup > 0.0 ? draft.markup : company.markup);
    markup->setMinimumHeight(42);

    auto* clientPrice = new QLabel(QString::fromUtf8("0 грн"), &dlg);
    clientPrice->setStyleSheet(QString::fromUtf8("font-size:15pt;font-weight:700;"));

    auto recalc = [companyPrice, markup, clientPrice, &draft]() {
        const double price = companyPrice->value() * (1.0 + markup->value() / 100.0);
        draft.clientPrice = price;
        clientPrice->setText(QString::fromUtf8("%1 грн").arg(QString::number(price, 'f', 2)));
    };

    auto* note = new QPlainTextEdit(draft.note, &dlg);
    note->setPlaceholderText(QString::fromUtf8("Примітка (необов’язково)"));
    note->setFixedHeight(92);

    form->addRow(QString::fromUtf8("Дата відправки:"), sentDate);
    form->addRow(QString::fromUtf8("Запчастина:"), partName);
    form->addRow(QString::fromUtf8("Ціна ремонту (компанія):"), companyPrice);
    form->addRow(QString::fromUtf8("Націнка до ремонту:"), markup);
    form->addRow(QString::fromUtf8("Ціна клієнту:"), clientPrice);
    form->addRow(QString::fromUtf8("Примітка:"), note);
    root->addLayout(form);

    QObject::connect(companyPrice, qOverload<double>(&QDoubleSpinBox::valueChanged), &dlg, [recalc](double){ recalc(); });
    QObject::connect(markup, qOverload<double>(&QDoubleSpinBox::valueChanged), &dlg, [recalc](double){ recalc(); });
    recalc();

    auto* buttons = new QDialogButtonBox(QDialogButtonBox::Save | QDialogButtonBox::Cancel, &dlg);
    QObject::connect(buttons, &QDialogButtonBox::accepted, &dlg, [&]() {
        const QString part = normalizeSentence(partName->text());
        if (part.isEmpty()) {
            QMessageBox::warning(&dlg, QString::fromUtf8("Аутсорс"), QString::fromUtf8("Вкажіть запчастину."));
            return;
        }
        draft.sentDate = sentDate->date();
        draft.partName = part;
        draft.companyPrice = companyPrice->value();
        draft.markup = markup->value();
        draft.note = note->toPlainText().trimmed();
        draft.clientPrice = draft.companyPrice * (1.0 + draft.markup / 100.0);
        dlg.accept();
    });
    QObject::connect(buttons, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
    root->addWidget(buttons, 0, Qt::AlignRight);

    return dlg.exec() == QDialog::Accepted;
}

static bool chooseOutsourceCompanyAndFill(QWidget* parent, int orderNumber, OutsourceCompanyEntry& selectedCompany, OutsourceJobDraft& draft)
{
    const auto companies = loadOutsourceCompanies();
    if (companies.isEmpty()) {
        QMessageBox::warning(parent, QString::fromUtf8("Аутсорс"), QString::fromUtf8("Немає компаній аутсорсу в налаштуваннях."));
        return false;
    }

    QDialog dlg(parent);
    dlg.setWindowTitle(QString::fromUtf8("Аутсорс — вибір компанії"));
    dlg.resize(920, 520);

    auto* root = new QVBoxLayout(&dlg);
    root->setContentsMargins(22, 18, 22, 18);
    root->setSpacing(14);

    auto* title = new QLabel(QString::fromUtf8("Оберіть компанію для ремонту запчастини:"), &dlg);
    title->setStyleSheet(QString::fromUtf8("font-size:15pt;font-weight:700;"));
    root->addWidget(title);

    auto* table = new QTableWidget(companies.size(), 2, &dlg);
    table->setHorizontalHeaderLabels({QString::fromUtf8("Компанія"), QString::fromUtf8("Націнка (%)")});
    table->verticalHeader()->setVisible(false);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setSelectionMode(QAbstractItemView::SingleSelection);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    table->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    for (int i = 0; i < companies.size(); ++i) {
        auto* c0 = new QTableWidgetItem(companies[i].company);
        c0->setData(Qt::UserRole, i);
        auto* c1 = new QTableWidgetItem(QString::number(companies[i].markup, 'f', 0));
        table->setItem(i, 0, c0);
        table->setItem(i, 1, c1);
    }
    root->addWidget(table, 1);

    auto finishForRow = [&](int row) {
        if (row < 0 || row >= companies.size()) return;
        OutsourceCompanyEntry company = companies[row];
        OutsourceJobDraft localDraft;
        localDraft.markup = company.markup;
        if (runOutsourceDetailDialog(&dlg, orderNumber, company, localDraft)) {
            selectedCompany = company;
            draft = localDraft;
            dlg.accept();
        }
    };

    QObject::connect(table, &QTableWidget::cellDoubleClicked, &dlg, [&](int row, int){ finishForRow(row); });

    auto* buttons = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
    QObject::connect(buttons, &QDialogButtonBox::accepted, &dlg, [&]() { finishForRow(table->currentRow()); });
    QObject::connect(buttons, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
    root->addWidget(buttons, 0, Qt::AlignRight);

    return dlg.exec() == QDialog::Accepted;
}

static QTableWidgetItem* makeTextItem(const QString& text, bool hint = false)
{
    auto* item = new QTableWidgetItem(text);
    if (hint) {
        QColor c("#dfe6f3");
        c.setAlpha(105);
        item->setForeground(c);
    }
    return item;
}

static void styleDarkFlatTable(QTableWidget* table)
{
    table->setShowGrid(false);
    table->setCornerButtonEnabled(false);
    table->setFrameShape(QFrame::StyledPanel);
    table->setAlternatingRowColors(false);
    table->setSelectionBehavior(QAbstractItemView::SelectItems);
    table->setWordWrap(true);
    table->setTextElideMode(Qt::ElideNone);
    table->setStyleSheet(QString::fromUtf8(
        "QTableWidget {"
        "  border: 1px solid rgba(235,239,244,0.92);"
        "  border-radius: 14px;"
        "  background: #ffffff;"
        "  color: #111111;"
        "  outline: none;"
        "  gridline-color: rgba(115,126,140,0.16);"
        "}" 
        "QTableWidget::item {"
        "  background: #ffffff;"
        "  color: #111111;"
        "  padding: 6px 10px;"
        "  border-right: 1px solid rgba(115,126,140,0.42);"
        "  border-bottom: 1px solid rgba(115,126,140,0.10);"
        "}" 
        "QTableWidget::item:selected {"
        "  background: #eef4ff;"
        "  color: #111111;"
        "}" 
        "QTableWidget QLineEdit, QTableWidget QAbstractSpinBox, QTableWidget QComboBox {"
        "  background: transparent;"
        "  color: #111111;"
        "  border: 0px;"
        "  outline: none;"
        "  padding: 0px;"
        "  margin: 0px;"
        "  selection-background-color: #dce9ff;"
        "  min-height: 30px;"
        "}" 
        "QTableWidget QLineEdit:focus, QTableWidget QAbstractSpinBox:focus, QTableWidget QComboBox:focus {"
        "  border: 0px;"
        "  outline: none;"
        "  background: transparent;"
        "}" 
        "QHeaderView::section {"
        "  border: none;"
        "  border-right: 1px solid rgba(255,255,255,0.10);"
        "  border-bottom: 1px solid rgba(255,255,255,0.08);"
        "  background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #515862, stop:1 #3d434b);"
        "  color: #ffffff;"
        "  padding: 5px 8px;"
        "  font-size: 10pt;"
        "  font-weight: 600;"
        "}" 
        "QTableCornerButton::section {"
        "  background: #49505a;"
        "  border: none;"
        "}" 
        "QHeaderView::section:vertical {"
        "  background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #49505a, stop:1 #383e46);"
        "  color: #ffffff;"
        "  border: none;"
        "  border-right: 1px solid rgba(255,255,255,0.08);"
        "  font-size: 10pt;"
        "  font-weight: 600;"
        "}" 
    ));

    if (auto* corner = table->findChild<QAbstractButton*>()) {
        corner->setStyleSheet(QString::fromUtf8("background: #49505a; border: none;"));
        corner->setEnabled(false);
        corner->update();
    }
}


static QString currentPrimaryMasterName(QComboBox* combo)
{
    return combo ? combo->currentText().trimmed() : QString();
}


static QString moneyText(double v)
{
    return FormatUtils::money(v, 0);
}

class FlatTableItemDelegate final : public QStyledItemDelegate {
public:
    using QStyledItemDelegate::QStyledItemDelegate;

    QWidget* createEditor(QWidget* parent, const QStyleOptionViewItem&, const QModelIndex&) const override
    {
        auto* edit = new QLineEdit(parent);
        edit->setFrame(false);
        edit->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        edit->setAttribute(Qt::WA_MacShowFocusRect, false);
        edit->setTextMargins(0, 0, 0, 0);
        edit->setContentsMargins(0, 0, 0, 0);
        edit->setStyleSheet(QString::fromUtf8(
            "QLineEdit { background: #f3f5f8; border: 0px; outline: none; padding: 0px; margin: 0px; color: #111111; selection-background-color: #d6e4ff; }"
            "QLineEdit:focus { background: #f3f5f8; border: 0px; outline: none; }"
        ));
        return edit;
    }

    void updateEditorGeometry(QWidget* editor, const QStyleOptionViewItem& option, const QModelIndex&) const override
    {
        QRect r = option.rect.adjusted(8, 4, -8, -4);
        editor->setGeometry(r);
    }
};

static int calcBatchRowHeight(QTableWidget* table, int row)
{
    if (!table) return 40;
    const int baseHeight = 40;
    const int minEditHeight = 30;
    int maxLines = 1;
    const QFontMetrics fm(table->font());
    for (int c = 0; c < table->columnCount(); ++c) {
        const auto* item = table->item(row, c);
        const QString txt = item ? item->text().trimmed() : QString();
        if (txt.isEmpty()) continue;
        const int colWidth = qMax(40, table->columnWidth(c) - 20);
        QRect br = fm.boundingRect(QRect(0, 0, colWidth, 2000), Qt::TextWordWrap | Qt::AlignLeft | Qt::AlignVCenter, txt);
        const int lines = qMax(1, (br.height() + fm.lineSpacing() - 1) / fm.lineSpacing());
        maxLines = qMax(maxLines, lines);
    }
    return qMax(baseHeight, qMax(minEditHeight + 10, maxLines * fm.lineSpacing() + 14));
}

static void updateBatchRowHeights(QTableWidget* table)
{
    if (!table) return;
    for (int r = 0; r < table->rowCount(); ++r) {
        table->setRowHeight(r, calcBatchRowHeight(table, r));
    }
}

static void updateSingleBatchRowHeight(QTableWidget* table, int row)
{
    if (!table || row < 0 || row >= table->rowCount()) return;
    table->setRowHeight(row, calcBatchRowHeight(table, row));
}

static QList<QStringList> runBatchEditor(QWidget* parent, const QString& title, const QStringList& headers, const QList<QStringList>& existing, const QString& stateKey = QString())
{
    QDialog dlg(parent);
    dlg.setWindowTitle(title);
    const bool isPartsEditor = (headers.size() == 8);
    const bool isServicesEditor = (headers.size() == 3);
    if (isPartsEditor) dlg.resize(1320, 740);
    else if (isServicesEditor) dlg.resize(1240, 760);
    else dlg.resize(1520, 860);
    auto* root = new QVBoxLayout(&dlg);
    root->setContentsMargins(12,12,12,12);
    root->setSpacing(10);

    auto* table = new QTableWidget(&dlg);
    table->setColumnCount(headers.size());
    table->setHorizontalHeaderLabels(headers);
    table->verticalHeader()->setVisible(true);
    table->verticalHeader()->setDefaultAlignment(Qt::AlignCenter);
    table->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    table->verticalHeader()->setDefaultSectionSize(42);
    table->verticalHeader()->setMinimumSectionSize(42);
    table->horizontalHeader()->setStretchLastSection(false);
    table->horizontalHeader()->setSectionsMovable(true);
    table->setEditTriggers(QAbstractItemView::CurrentChanged | QAbstractItemView::SelectedClicked | QAbstractItemView::EditKeyPressed | QAbstractItemView::AnyKeyPressed);
    table->setSelectionBehavior(QAbstractItemView::SelectItems);
    table->setSelectionMode(QAbstractItemView::SingleSelection);
    table->setAlternatingRowColors(false);
    table->setWordWrap(true);
    table->setCornerButtonEnabled(false);
    styleDarkFlatTable(table);
    table->setItemDelegate(new FlatTableItemDelegate(table));
    QFont tableFont = table->font();
    tableFont.setPointSize(12);
    table->setFont(tableFont);
    QFont headerFont = table->horizontalHeader()->font();
    headerFont.setPointSize(10);
    headerFont.setBold(true);
    table->horizontalHeader()->setFont(headerFont);
    table->verticalHeader()->setFont(headerFont);
    table->horizontalHeader()->setDefaultAlignment(Qt::AlignCenter);

    auto updateNumbers = [table]() {
        for (int r = 0; r < table->rowCount(); ++r) table->setVerticalHeaderItem(r, new QTableWidgetItem(QString::number(r + 1)));
    };

    const int baseRows = qMax(8, existing.size() + 2);
    table->setRowCount(baseRows);
    for (int r = 0; r < baseRows; ++r) {
        for (int c = 0; c < headers.size(); ++c) {
            if (!table->item(r, c)) table->setItem(r, c, new QTableWidgetItem());
        }
    }
    updateNumbers();
    updateBatchRowHeights(table);

    for (int r = 0; r < existing.size(); ++r) {
        const auto row = existing[r];
        for (int c = 0; c < headers.size() && c < row.size(); ++c) {
            table->item(r, c)->setText(row[c]);
        }
    }
    if (headers.size() == 8) {
        for (int r = 0; r < table->rowCount(); ++r) {
            if (auto* dateItem = table->item(r, 0); dateItem && dateItem->text().trimmed().isEmpty()) dateItem->setText(currentOrderDateDisplay());
            if (auto* amountItem = table->item(r, 5)) amountItem->setFlags(amountItem->flags() & ~Qt::ItemIsEditable);
        }
    }

    for (int i = 0; i < headers.size(); ++i) {
        table->horizontalHeader()->setSectionResizeMode(i, QHeaderView::Interactive);
    }
    if (headers.size() == 3) {
        table->setColumnWidth(0, 760);
        table->setColumnWidth(1, 260);
        table->setColumnWidth(2, 260);
    } else if (headers.size() == 8) {
        table->setColumnWidth(0, 140);
        table->setColumnWidth(1, 180);
        table->setColumnWidth(2, 480);
        table->setColumnWidth(3, 140);
        table->setColumnWidth(4, 170);
        table->setColumnWidth(5, 170);
        table->setColumnWidth(6, 220);
        table->setColumnWidth(7, 180);
    }
    restoreHeaderState(table->horizontalHeader(), stateKey);

    if (isPartsEditor) {
        if (QWidget* pw = parent ? parent->window() : nullptr) {
            const QRect pg = pw->frameGeometry();
            const int dlgW = qMin(1260, qMax(980, pg.width() - 520));
            const int dlgH = qMin(700, qMax(560, pg.height() - 140));
            dlg.setFixedSize(dlgW, dlgH);
            const int x = pg.x() + qMin(320, qMax(180, pg.width() / 6));
            const int y = pg.y() + 26;
            dlg.move(x, y);
        } else {
            dlg.setFixedSize(1180, 660);
        }
    }
    bindHeaderStatePersistence(table->horizontalHeader(), stateKey);
    updateBatchRowHeights(table);
    QObject::connect(table->horizontalHeader(), &QHeaderView::sectionResized, &dlg, [table](int, int, int) {
        QTimer::singleShot(0, table, [table]() { updateBatchRowHeights(table); });
    });

    QObject::connect(table, &QTableWidget::itemChanged, &dlg, [table, updateNumbers](QTableWidgetItem* changed) {
        if (!changed) return;
        const int row = changed->row();
        const int col = changed->column();
        const bool isServices = table->columnCount() == 3;
        const bool isParts = table->columnCount() == 8;
        const bool normalizeCol = (isServices && (col == 0 || col == 2)) || (isParts && (col == 2 || col == 6 || col == 7));
        if (normalizeCol) {
            const QString norm = normalizeSentence(changed->text());
            if (norm != changed->text()) {
                QSignalBlocker blocker(table);
                changed->setText(norm);
            }
        }
        if (isParts) {
            if (col == 0 && changed->text().trimmed().isEmpty()) {
                QSignalBlocker blocker(table);
                changed->setText(currentOrderDateDisplay());
            }
            if (col == 3 || col == 4) {
                bool okQty = false, okPrice = false;
                const double qty = table->item(row, 3) ? parseLooseNumber(table->item(row, 3)->text().trimmed(), &okQty) : 1.0;
                const double price = table->item(row, 4) ? parseLooseNumber(table->item(row, 4)->text().trimmed(), &okPrice) : 0.0;
                const double amount = (okQty && qty > 0.0 ? qty : 1.0) * (okPrice && price >= 0.0 ? price : 0.0);
                if (auto* amountItem = table->item(row, 5)) {
                    QSignalBlocker blocker(table);
                    amountItem->setText(moneyText(amount));
                }
            }
        }

        bool hasAny = false;
        for (int c = 0; c < table->columnCount(); ++c) {
            auto* it = table->item(row, c);
            if (it && !it->text().trimmed().isEmpty()) { hasAny = true; break; }
        }
        updateSingleBatchRowHeight(table, row);
        if (hasAny && row == table->rowCount() - 1) {
            const int newRow = table->rowCount();
            {
                QSignalBlocker blocker(table);
                table->insertRow(newRow);
                for (int c = 0; c < table->columnCount(); ++c) {
                    table->setItem(newRow, c, new QTableWidgetItem());
                }
                if (isParts) {
                    if (auto* dateItem = table->item(newRow, 0)) dateItem->setText(currentOrderDateDisplay());
                    if (auto* amountItem = table->item(newRow, 5)) amountItem->setFlags(amountItem->flags() & ~Qt::ItemIsEditable);
                }
            }
            updateNumbers();
            updateSingleBatchRowHeight(table, newRow);
        }
    });

    class EnterFilter final : public QObject {
    public:
        explicit EnterFilter(QTableWidget* t) : QObject(t), table(t) {}
    protected:
        bool eventFilter(QObject* obj, QEvent* ev) override {
            if ((ev->type() == QEvent::KeyPress) && table) {
                auto* ke = static_cast<QKeyEvent*>(ev);
                if (ke->key() == Qt::Key_Return || ke->key() == Qt::Key_Enter) {
                    table->clearSelection();
                    int row = table->currentRow();
                    int col = table->currentColumn();
                    if (col < table->columnCount() - 1) table->setCurrentCell(row, col + 1);
                    else table->setCurrentCell(row + 1 < table->rowCount() ? row + 1 : row, 0);
                    table->editItem(table->currentItem());
                    return true;
                }
            }
            return QObject::eventFilter(obj, ev);
        }
        QTableWidget* table;
    };
    table->installEventFilter(new EnterFilter(table));
    QObject::connect(table, &QTableWidget::cellClicked, &dlg, [table](int row, int col) {
        if (auto* item = table->item(row, col)) {
            QTimer::singleShot(0, table, [table, item]() {
                table->closePersistentEditor(item);
                table->setCurrentItem(item);
                table->editItem(item);
            });
        }
    });

    root->addWidget(table, 1);
    auto* buttons = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
    QObject::connect(buttons, &QDialogButtonBox::accepted, &dlg, [&dlg, table]() {
        if (QWidget* fw = dlg.focusWidget()) fw->clearFocus();
        table->setFocus();
        QCoreApplication::processEvents();
        dlg.accept();
    });
    QObject::connect(buttons, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
    root->addWidget(buttons);
    if (dlg.exec() != QDialog::Accepted) return {};

    QList<QStringList> out;
    for (int r = 0; r < table->rowCount(); ++r) {
        QStringList row; row.reserve(headers.size());
        bool any = false;
        for (int c = 0; c < table->columnCount(); ++c) {
            QString txt = table->item(r, c) ? table->item(r, c)->text().trimmed() : QString();
            if (!txt.isEmpty()) any = true;
            row << txt;
        }
        if (!any) continue;
        if (row.size() == 3) {
            row[0] = normalizeSentence(row[0]);
            row[2] = normalizeSentence(row[2]);
        } else if (row.size() == 8) {
            row[0] = row[0].trimmed().isEmpty() ? currentOrderDateDisplay() : row[0].trimmed();
            row[2] = normalizeSentence(row[2]);
            row[6] = normalizeSentence(row[6]);
            row[7] = normalizeSentence(row[7]);
            bool okQty = false, okPrice = false;
            const double qty = parseLooseNumber(row[3].trimmed(), &okQty);
            const double price = parseLooseNumber(row[4].trimmed(), &okPrice);
            row[5] = moneyText((okQty && qty > 0.0 ? qty : 1.0) * (okPrice && price >= 0.0 ? price : 0.0));
        }
        out << row;
    }
    return out;
}

} // namespace

WorkPartsDialog::WorkPartsDialog(QWidget* parent, int orderNumber)
    : QDialog(parent), m_orderNumber(orderNumber)
{
    setWindowTitle(QString::fromUtf8("Роботи та запчастини"));
    setModal(false);
    setWindowModality(Qt::NonModal);

    buildUi();
    loadHeader();
    loadMasterChoice();
    loadServices();
    ensureServiceSelected();
    loadPartsForActiveService();
    focusSection(0);

    if (parent) {
        const QRect pg = parent->geometry();
        resize(pg.size());
        move(pg.topLeft());
    } else {
        showMaximized();
    }
}

void WorkPartsDialog::setEmbedded(bool on)
{
    m_embedded = on;
    setWindowFlags(on ? Qt::Widget : Qt::Dialog);
    setModal(!on);
    setWindowModality(on ? Qt::NonModal : Qt::ApplicationModal);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    if (on) {
        setMinimumSize(0, 0);
        setMaximumSize(QWIDGETSIZE_MAX, QWIDGETSIZE_MAX);
        updateGeometry();
    }
}

void WorkPartsDialog::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(16, 16, 16, 16);
    root->setSpacing(10);

    m_lblTitle = new QLabel(this);
    QFont tf = m_lblTitle->font();
    tf.setPointSize(tf.pointSize() + 4);
    tf.setBold(true);
    m_lblTitle->setFont(tf);
    root->addWidget(m_lblTitle);

    m_lblSub = new QLabel(this);
    m_lblSub->setWordWrap(true);
    root->addWidget(m_lblSub);

    auto* controlsRow = new QHBoxLayout();
    controlsRow->setSpacing(10);
    auto* masterLbl = new QLabel(QString::fromUtf8("Майстер:"), this);
    QFont lf = masterLbl->font();
    lf.setBold(true);
    masterLbl->setFont(lf);
    m_masterCombo = new QComboBox(this);
    m_masterCombo->setMinimumWidth(300);
    m_btnSaveMaster = new QPushButton(QString::fromUtf8("Зберегти майстра"), this);
    m_btnOutsource = new QPushButton(QString::fromUtf8("Аутсорс"), this);
    m_btnPdf = new QPushButton(QString::fromUtf8("PDF"), this);
    m_btnCloseOrder = new QPushButton(QString::fromUtf8("Закрити наряд"), this);
    controlsRow->addWidget(masterLbl);
    controlsRow->addWidget(m_masterCombo, 1);
    controlsRow->addWidget(m_btnSaveMaster);
    controlsRow->addSpacing(18);
    controlsRow->addWidget(m_btnOutsource);
    controlsRow->addWidget(m_btnPdf);
    controlsRow->addWidget(m_btnCloseOrder);
    root->addLayout(controlsRow);

    m_split = new QSplitter(Qt::Horizontal, this);
    m_split->setChildrenCollapsible(false);
    root->addWidget(m_split, 1);

    auto makePaneTitle = [](const QString& text, QWidget* parent) {
        auto* lbl = new QLabel(text, parent);
        QFont f = lbl->font();
        f.setBold(true);
        lbl->setFont(f);
        return lbl;
    };

    auto* left = new QFrame(this);
    left->setObjectName("workPane");
    auto* leftLay = new QVBoxLayout(left);
    leftLay->setContentsMargins(0,0,0,0);
    leftLay->setSpacing(8);
    auto* serviceHeader = new QHBoxLayout();
    serviceHeader->setContentsMargins(0,0,0,0);
    serviceHeader->setSpacing(10);
    serviceHeader->addWidget(makePaneTitle(QString::fromUtf8("Виконання робіт"), left));
    serviceHeader->addStretch(1);
    m_btnAddService = new QPushButton(QString::fromUtf8("Додати роботу"), left);
    m_btnEditService = new QPushButton(QString::fromUtf8("Редагувати"), left);
    serviceHeader->addWidget(m_btnAddService);
    serviceHeader->addWidget(m_btnEditService);
    leftLay->addLayout(serviceHeader);

    m_servicesTable = new QTableWidget(0, 3, left);
    m_servicesTable->setHorizontalHeaderLabels({QString::fromUtf8("Робота"), QString::fromUtf8("Ціна"), QString::fromUtf8("Майстер")});
    m_servicesTable->verticalHeader()->setVisible(true);
    m_servicesTable->verticalHeader()->setDefaultAlignment(Qt::AlignCenter);
    m_servicesTable->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    m_servicesTable->verticalHeader()->setDefaultSectionSize(40);
    m_servicesTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_servicesTable->setSelectionMode(QAbstractItemView::SingleSelection);
    m_servicesTable->setContextMenuPolicy(Qt::CustomContextMenu);
    m_servicesTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_servicesTable->horizontalHeader()->setSectionsMovable(false);
    m_servicesTable->horizontalHeader()->setStretchLastSection(false);
    m_servicesTable->horizontalHeader()->setDefaultAlignment(Qt::AlignCenter);
    m_servicesTable->horizontalHeader()->setMinimumHeight(42);
    m_servicesTable->horizontalHeader()->setFixedHeight(42);
    m_servicesTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Fixed);
    m_servicesTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Fixed);
    m_servicesTable->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Fixed);
    m_servicesTable->setColumnWidth(0, 430);
    m_servicesTable->setColumnWidth(1, 110);
    m_servicesTable->setColumnWidth(2, 150);
    {
        QFont hf = m_servicesTable->horizontalHeader()->font();
        hf.setPointSize(qMax(8, hf.pointSize() - 1));
        hf.setBold(true);
        m_servicesTable->horizontalHeader()->setFont(hf);
    }
    styleDarkFlatTable(m_servicesTable);
    leftLay->addWidget(m_servicesTable, 1);

    auto* right = new QFrame(this);
    right->setObjectName("partsPane");
    auto* rightLay = new QVBoxLayout(right);
    rightLay->setContentsMargins(0,0,0,0);
    rightLay->setSpacing(8);
    auto* partHeader = new QHBoxLayout();
    partHeader->setContentsMargins(0,0,0,0);
    partHeader->setSpacing(10);
    partHeader->addWidget(makePaneTitle(QString::fromUtf8("Запчастини"), right));
    partHeader->addStretch(1);
    m_btnAddPart = new QPushButton(QString::fromUtf8("Додати запчастину"), right);
    m_btnEditPart = new QPushButton(QString::fromUtf8("Редагувати"), right);
    partHeader->addWidget(m_btnAddPart);
    partHeader->addWidget(m_btnEditPart);
    rightLay->addLayout(partHeader);

    m_partsTable = new QTableWidget(0, 8, right);
    m_partsTable->setHorizontalHeaderLabels({
        QString::fromUtf8("Дата\nзамовл."),
        QString::fromUtf8("OEM\nномер"),
        QString::fromUtf8("Запчастина"),
        QString::fromUtf8("Кіл-\nть"),
        QString::fromUtf8("Ціна"),
        QString::fromUtf8("Вартість"),
        QString::fromUtf8("Магазин"),
        QString::fromUtf8("Замовник")});
    m_partsTable->verticalHeader()->setVisible(true);
    m_partsTable->verticalHeader()->setDefaultAlignment(Qt::AlignCenter);
    m_partsTable->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    m_partsTable->verticalHeader()->setDefaultSectionSize(40);
    m_partsTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_partsTable->setSelectionMode(QAbstractItemView::SingleSelection);
    m_partsTable->setContextMenuPolicy(Qt::CustomContextMenu);
    m_partsTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_partsTable->horizontalHeader()->setSectionsMovable(false);
    m_partsTable->horizontalHeader()->setStretchLastSection(false);
    m_partsTable->horizontalHeader()->setDefaultAlignment(Qt::AlignCenter);
    m_partsTable->horizontalHeader()->setMinimumHeight(52);
    m_partsTable->horizontalHeader()->setFixedHeight(52);
    for (int i = 0; i < 8; ++i) m_partsTable->horizontalHeader()->setSectionResizeMode(i, QHeaderView::Fixed);
    m_partsTable->setColumnWidth(0, 90);
    m_partsTable->setColumnWidth(1, 110);
    m_partsTable->setColumnWidth(2, 260);
    m_partsTable->setColumnWidth(3, 70);
    m_partsTable->setColumnWidth(4, 90);
    m_partsTable->setColumnWidth(5, 110);
    m_partsTable->setColumnWidth(6, 90);
    m_partsTable->setColumnWidth(7, 90);
    {
        QFont hf = m_partsTable->horizontalHeader()->font();
        hf.setPointSize(qMax(8, hf.pointSize() - 1));
        hf.setBold(true);
        m_partsTable->horizontalHeader()->setFont(hf);
    }
    styleDarkFlatTable(m_partsTable);
    rightLay->addWidget(m_partsTable, 1);

    m_split->addWidget(left);
    m_split->addWidget(right);
    m_split->setStretchFactor(0, 1);
    m_split->setStretchFactor(1, 1);
    m_split->setHandleWidth(1);
    m_split->setStyleSheet(QString::fromUtf8(
        "QSplitter::handle { background: rgba(255,255,255,0.18); }"
        "QFrame#workPane, QFrame#partsPane {"
        "  background: transparent;"
        "  border: none;"
        "}"
        "QFrame#workPane QLabel, QFrame#partsPane QLabel { color: #ffffff; }"
    ));
    m_split->setSizes({width() / 2, width() / 2});

    connect(m_btnSaveMaster, &QPushButton::clicked, this, [this] { savePrimaryMaster(); });
    connect(m_btnOutsource, &QPushButton::clicked, this, [this] {
        OutsourceCompanyEntry company;
        OutsourceJobDraft draft;
        if (!chooseOutsourceCompanyAndFill(this, m_orderNumber, company, draft)) return;

        const QString title = QString::fromUtf8("%1 • %2").arg(draft.partName, company.company);
        if (!insertService(title, QString::fromUtf8("[Аутсорс] "))) return;
        setServicePrice(draft.clientPrice);
        saveOutsourceJob(m_orderNumber, m_activeServiceId, company, draft, this);
        loadServices();
        ensureServiceSelected();
        loadHeader();
    });
    connect(m_btnPdf, &QPushButton::clicked, this, &WorkPartsDialog::requestPdf);
    connect(m_btnAddService, &QPushButton::clicked, this, &WorkPartsDialog::openAddServicesDialog);
    connect(m_btnEditService, &QPushButton::clicked, this, &WorkPartsDialog::openEditServicesDialog);
    connect(m_btnAddPart, &QPushButton::clicked, this, &WorkPartsDialog::openAddPartsDialog);
    connect(m_btnEditPart, &QPushButton::clicked, this, &WorkPartsDialog::openEditPartsDialog);
    connect(m_btnCloseOrder, &QPushButton::clicked, this, [this] {
        const auto r = QMessageBox::question(this, QString::fromUtf8("Підтвердження"),
                                             QString::fromUtf8("Закрити наряд?"),
                                             QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
        if (r == QMessageBox::Yes) emit requestCloseOrder();
    });

    connect(m_servicesTable, &QTableWidget::customContextMenuRequested, this, &WorkPartsDialog::showServicesMenu);
    connect(m_partsTable, &QTableWidget::customContextMenuRequested, this, &WorkPartsDialog::showPartsMenu);

    connect(m_servicesTable, &QTableWidget::currentCellChanged, this, [this](int row, int, int, int) {
        if (m_syncingServices || row < 0) return;
        auto* item = m_servicesTable->item(row, 0);
        if (!item || item->data(RoleIsHint).toBool()) return;
        setActiveServiceId(item->data(RoleId).toInt());
    });

    connect(m_servicesTable, &QTableWidget::itemChanged, this, [this](QTableWidgetItem* item) {
        if (!item || m_syncingServices) return;
        if (m_servicesTable->editTriggers() == QAbstractItemView::NoEditTriggers) return;
        const int row = item->row();
        auto* titleItem = m_servicesTable->item(row, 0);
        if (!titleItem) return;

        const bool isHint = titleItem->data(RoleIsHint).toBool();
        if (isHint) {
            const QString entered = normalizeSentence(titleItem->text());
            if (isServiceHintValue(entered)) return;
            if (insertService(entered)) {
                loadServices();
                ensureServiceSelected();
                loadHeader();
            }
            return;
        }

        const int serviceId = titleItem->data(RoleId).toInt();
        if (serviceId <= 0) return;
        const QString title = normalizeSentence(titleItem->text());
        bool okPrice = false;
        const double price = m_servicesTable->item(row, 1)
                                 ? parseLooseNumber(m_servicesTable->item(row, 1)->text(), &okPrice)
                                 : 0.0;
        QSqlQuery q(Database::db());
        q.prepare("UPDATE work_order_services SET title=?, price=?, amount=qty*? WHERE id=? AND order_number=?");
        q.addBindValue(title);
        q.addBindValue(okPrice ? qMax(0.0, price) : 0.0);
        q.addBindValue(okPrice ? qMax(0.0, price) : 0.0);
        q.addBindValue(serviceId);
        q.addBindValue(m_orderNumber);
        if (!q.exec()) {
            QMessageBox::critical(this, QString::fromUtf8("Помилка"), q.lastError().text());
        }
        loadServices();
        loadHeader();
    });

    connect(m_partsTable, &QTableWidget::itemChanged, this, [this](QTableWidgetItem* item) {
        if (!item || m_loadingParts) return;
        if (m_partsTable->editTriggers() == QAbstractItemView::NoEditTriggers) return;
        savePartRow(item->row());
    });
}

void WorkPartsDialog::loadHeader()
{
    QSqlQuery q(Database::db());
    q.prepare(
        "SELECT w.number, COALESCE(w.plate,''), COALESCE(w.vin,''), COALESCE(w.car,''), COALESCE(w.client,''), COALESCE(w.client_phone,''), "
        "COALESCE(m.name, w.master_name_closed, ''), COALESCE(w.status,''), COALESCE(w.opened_at,''), "
        "(SELECT COALESCE(SUM(qty*price),0) FROM work_order_services s WHERE s.order_number=w.number), "
        "(SELECT COALESCE(SUM(qty*price),0) FROM work_order_parts p WHERE p.order_number=w.number) "
        "FROM work_orders w LEFT JOIN masters m ON m.id=w.master_id WHERE w.number=?");
    q.addBindValue(m_orderNumber);
    if (!q.exec() || !q.next()) {
        m_lblTitle->setText(QString::fromUtf8("Наряд №%1").arg(m_orderNumber));
        m_lblSub->clear();
        return;
    }

    const QString plate = q.value(1).toString();
    const QString vin = q.value(2).toString();
    const QString car = q.value(3).toString();
    const QString client = q.value(4).toString();
    const QString phone = q.value(5).toString();
    const QString master = q.value(6).toString();
    const QString status = q.value(7).toString();
    const QString opened = displayDateFromStored(q.value(8).toString());
    const double worksSum = q.value(9).toDouble();
    const double partsSum = q.value(10).toDouble();

    m_lblTitle->setText(QString::fromUtf8("Наряд №%1").arg(m_orderNumber));
    m_lblSub->setText(QString::fromUtf8("%1 • VIN: %2 • %3 • Клієнт: %4 • Тел: %5 • Майстер: %6 • Статус: %7 • Відкрито: %8 • Роботи: %9 грн • Запчастини: %10 грн")
                      .arg(plate, vin, car, client, phone, master, status, opened,
                           moneyText(worksSum), moneyText(partsSum)));
}

void WorkPartsDialog::loadMasterChoice()
{
    if (!m_masterCombo) return;
    const QSignalBlocker blocker(m_masterCombo);
    m_masterCombo->clear();
    const auto list = Database::masters(true);
    for (const auto& m : list) m_masterCombo->addItem(m.name, m.id);

    QSqlQuery q(Database::db());
    q.prepare("SELECT master_id FROM work_orders WHERE number=?");
    q.addBindValue(m_orderNumber);
    if (q.exec() && q.next()) {
        const QString masterId = q.value(0).toString();
        const int idx = m_masterCombo->findData(masterId);
        if (idx >= 0) m_masterCombo->setCurrentIndex(idx);
    }
}

void WorkPartsDialog::loadServices()
{
    m_syncingServices = true;
    m_servicesTable->setRowCount(0);

    const QString primaryMaster = currentPrimaryMasterName(m_masterCombo);

    QSqlQuery q(Database::db());
    q.prepare(
        "SELECT s.id, COALESCE(s.title,''), COALESCE(s.price,0), "
        "COALESCE(MAX(NULLIF(m.name,'')), MAX(NULLIF(sm.master_name_closed,'')), '') "
        "FROM work_order_services s "
        "LEFT JOIN service_masters sm ON sm.service_id=s.id "
        "LEFT JOIN masters m ON m.id=sm.master_id "
        "WHERE s.order_number=? "
        "GROUP BY s.id, s.title, s.price "
        "ORDER BY s.id");
    q.addBindValue(m_orderNumber);
    if (q.exec()) {
        while (q.next()) {
            const int row = m_servicesTable->rowCount();
            m_servicesTable->insertRow(row);
            const int serviceId = q.value(0).toInt();
            const QString title = q.value(1).toString();
            const double price = q.value(2).toDouble();
            QString master = q.value(3).toString().trimmed();
            if (master.isEmpty()) master = primaryMaster;
            auto* titleItem = makeTextItem(title);
            titleItem->setData(RoleId, serviceId);
            titleItem->setData(RoleIsHint, false);
            auto* priceItem = makeTextItem(moneyText(price));
            auto* masterItem = makeTextItem(master);
            m_servicesTable->setItem(row, 0, titleItem);
            m_servicesTable->setItem(row, 1, priceItem);
            m_servicesTable->setItem(row, 2, masterItem);
        }
    }
    m_syncingServices = false;
    syncServiceVisualSelection();
}

void WorkPartsDialog::loadPartsForActiveService()
{
    m_loadingParts = true;
    m_partsTable->setRowCount(0);

    QSqlQuery q(Database::db());
    q.prepare("SELECT id, COALESCE(name,''), COALESCE(qty,1), COALESCE(price,0), COALESCE(amount,0), COALESCE(store,''), COALESCE(part_number,''), COALESCE(purchase_price,0), COALESCE(markup_percent,0), COALESCE(ordered_at,'') FROM work_order_parts WHERE order_number=? ORDER BY id");
    q.addBindValue(m_orderNumber);
    if (q.exec()) {
        while (q.next()) {
            const int row = m_partsTable->rowCount();
            m_partsTable->insertRow(row);
            auto* dateItem = makeTextItem(displayDateFromStored(q.value(9).toString()));
            dateItem->setData(RoleId, q.value(0).toInt());
            m_partsTable->setItem(row, 0, dateItem);
            auto* oemItem = makeTextItem(q.value(6).toString());
            oemItem->setData(RoleId, q.value(0).toInt());
            m_partsTable->setItem(row, 1, oemItem);
            auto* nameItem = makeTextItem(q.value(1).toString());
            nameItem->setData(RoleId, q.value(0).toInt());
            m_partsTable->setItem(row, 2, nameItem);
            m_partsTable->setItem(row, 3, makeTextItem(FormatUtils::smartQty(q.value(2).toDouble(), 2)));
            auto* priceItem = makeTextItem(moneyText(q.value(3).toDouble()));
            const double displayPrice = q.value(3).toDouble();
            const double purchasePrice = q.value(7).toDouble() > 0.0 ? q.value(7).toDouble() : displayPrice;
            priceItem->setData(RolePurchasePrice, purchasePrice);
            priceItem->setData(RoleDisplayPrice, displayPrice);
            priceItem->setData(RoleMarkupPercent, q.value(8).toDouble());
            m_partsTable->setItem(row, 4, priceItem);
            m_partsTable->setItem(row, 5, makeTextItem(moneyText(q.value(4).toDouble())));
            m_partsTable->setItem(row, 6, makeTextItem(q.value(5).toString()));
            m_partsTable->setItem(row, 7, makeTextItem(QString()));
        }
    }
    m_loadingParts = false;
}

void WorkPartsDialog::ensureServiceSelected()
{
    if (m_activeServiceId > 0) {
        syncServiceVisualSelection();
        return;
    }
    for (int row = 0; row < m_servicesTable->rowCount(); ++row) {
        auto* item = m_servicesTable->item(row, 0);
        if (!item || item->data(RoleIsHint).toBool()) continue;
        m_activeServiceId = item->data(RoleId).toInt();
        break;
    }
    syncServiceVisualSelection();
}

int WorkPartsDialog::activeServiceId() const
{
    return m_activeServiceId;
}

void WorkPartsDialog::setActiveServiceId(int serviceId)
{
    m_activeServiceId = serviceId;
    syncServiceVisualSelection();
}

void WorkPartsDialog::syncServiceVisualSelection()
{
    if (!m_servicesTable) return;
    for (int row = 0; row < m_servicesTable->rowCount(); ++row) {
        auto* item = m_servicesTable->item(row, 0);
        if (!item || item->data(RoleIsHint).toBool()) continue;
        if (item->data(RoleId).toInt() == m_activeServiceId) {
            const QSignalBlocker blocker(m_servicesTable);
            m_servicesTable->setCurrentCell(row, 0);
            m_servicesTable->scrollToItem(item);
            break;
        }
    }
}

void WorkPartsDialog::focusSection(int section)
{
    if (!m_split) return;
    Q_UNUSED(section);
    const int total = qMax(900, m_split->width() > 0 ? m_split->width() : 1400);
    m_split->setSizes({int(total * 0.50), int(total * 0.50)});
}

bool WorkPartsDialog::insertService(const QString& title, const QString& prefix)
{
    const QString finalTitle = normalizeSentence(prefix + title);
    if (finalTitle.isEmpty()) return false;

    QSqlQuery q(Database::db());
    q.prepare("INSERT INTO work_order_services(order_number, title, qty, price, amount) VALUES(?,?,?,?,?)");
    q.addBindValue(m_orderNumber);
    q.addBindValue(finalTitle);
    q.addBindValue(1.0);
    q.addBindValue(0.0);
    q.addBindValue(0.0);
    if (!q.exec()) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), q.lastError().text());
        return false;
    }
    m_activeServiceId = q.lastInsertId().toInt();

    QSqlQuery orderQ(Database::db());
    orderQ.prepare("SELECT master_id, COALESCE(master_name_closed,''), COALESCE((SELECT name FROM masters WHERE id=work_orders.master_id), '') FROM work_orders WHERE number=?");
    orderQ.addBindValue(m_orderNumber);
    if (orderQ.exec() && orderQ.next()) {
        const QString masterId = orderQ.value(0).toString();
        QString masterName = orderQ.value(2).toString();
        if (masterName.isEmpty()) masterName = orderQ.value(1).toString();
        if (!masterId.isEmpty()) setServiceMaster(masterId, masterName);
    }
    return true;
}

bool WorkPartsDialog::savePrimaryMaster()
{
    if (!m_masterCombo || m_masterCombo->currentIndex() < 0) return false;
    const QString masterId = m_masterCombo->currentData().toString();
    const QString masterName = m_masterCombo->currentText().trimmed();
    if (masterId.isEmpty()) return false;

    QSqlQuery up(Database::db());
    up.prepare("UPDATE work_orders SET master_id=?, master_name_closed=? WHERE number=?");
    up.addBindValue(masterId);
    up.addBindValue(masterName);
    up.addBindValue(m_orderNumber);
    if (!up.exec()) return false;

    loadHeader();
    loadServices();
    QMessageBox::information(this, QString::fromUtf8("Готово"), QString::fromUtf8("Основного майстра збережено"));
    return true;
}

bool WorkPartsDialog::setServiceMaster(const QString& masterId, const QString& masterName)
{
    if (activeServiceId() <= 0 || masterId.isEmpty()) return false;
    QSqlDatabase db = Database::db();
    if (!db.transaction()) return false;
    QSqlQuery del(db);
    del.prepare("DELETE FROM service_masters WHERE service_id=?");
    del.addBindValue(activeServiceId());
    if (!del.exec()) { db.rollback(); return false; }
    QSqlQuery ins(db);
    ins.prepare("INSERT INTO service_masters(service_id, master_id, share_percent, role, master_name_closed) VALUES(?,?,?,?,?)");
    ins.addBindValue(activeServiceId());
    ins.addBindValue(masterId);
    ins.addBindValue(100.0);
    ins.addBindValue(QString::fromUtf8("master"));
    ins.addBindValue(masterName);
    if (!ins.exec()) { db.rollback(); return false; }
    if (!db.commit()) { db.rollback(); return false; }
    loadServices();
    return true;
}

bool WorkPartsDialog::setServicePrice(double price)
{
    if (activeServiceId() <= 0) return false;
    const double safePrice = qMax(0.0, price);
    QSqlQuery q(Database::db());
    q.prepare("UPDATE work_order_services SET price=?, amount=qty*? WHERE id=? AND order_number=?");
    q.addBindValue(safePrice);
    q.addBindValue(safePrice);
    q.addBindValue(activeServiceId());
    q.addBindValue(m_orderNumber);
    if (!q.exec()) return false;
    loadServices();
    loadHeader();
    return true;
}

bool WorkPartsDialog::clearServiceMaster()
{
    if (activeServiceId() <= 0) return false;
    QSqlQuery q(Database::db());
    q.prepare("DELETE FROM service_masters WHERE service_id=?");
    q.addBindValue(activeServiceId());
    const bool ok = q.exec();
    if (ok) loadServices();
    return ok;
}

void WorkPartsDialog::insertEmptyPartRow()
{
    const int row = m_partsTable->rowCount();
    m_partsTable->insertRow(row);
    auto* dateItem = makeTextItem(currentOrderDateDisplay(), true);
    dateItem->setData(true, RoleIsHint);
    m_partsTable->setItem(row, 0, dateItem);
    auto* oemItem = makeTextItem(QString(), true);
    oemItem->setData(true, RoleIsHint);
    m_partsTable->setItem(row, 1, oemItem);
    auto* nameItem = makeTextItem(partHintText(), true);
    nameItem->setData(true, RoleIsHint);
    nameItem->setData(RoleId, 0);
    m_partsTable->setItem(row, 2, nameItem);
    m_partsTable->setItem(row, 3, makeTextItem(QStringLiteral("1.00"), true));
    m_partsTable->setItem(row, 4, makeTextItem(QStringLiteral("0.00"), true));
    m_partsTable->setItem(row, 5, makeTextItem(QStringLiteral("0.00"), true));
    m_partsTable->setItem(row, 6, makeTextItem(QString(), true));
    m_partsTable->setItem(row, 7, makeTextItem(QString(), true));
}

bool WorkPartsDialog::savePartRow(int row)
{
    if (m_loadingParts || row < 0 || row >= m_partsTable->rowCount()) return false;

    auto* nameItem = m_partsTable->item(row, 2);
    if (!nameItem) return false;
    QString name = normalizeSentence(nameItem->text());
    if (isPartHintValue(name) || name.startsWith(QLatin1Char('+'))) name.clear();
    if (name.isEmpty()) return false;

    bool okQty = false, okPrice = false;
    const double qty = m_partsTable->item(row,3) ? parseLooseNumber(m_partsTable->item(row,3)->text(), &okQty) : 1.0;
    auto* priceItem = m_partsTable->item(row,4);
    const double typedPrice = priceItem ? parseLooseNumber(priceItem->text(), &okPrice) : 0.0;
    const QString store = m_partsTable->item(row,6) ? normalizeSentence(m_partsTable->item(row,6)->text()) : QString();
    const QString oemNumber = m_partsTable->item(row,1) ? m_partsTable->item(row,1)->text().trimmed() : QString();
    const QString orderedAt = m_partsTable->item(row,0) ? storedDateFromDisplay(m_partsTable->item(row,0)->text()) : QDate::currentDate().toString(Qt::ISODate);
    const double safeQty = okQty && qty > 0.0 ? qty : 1.0;

    const int partId = nameItem->data(RoleId).toInt();
    double purchasePrice = okPrice && typedPrice >= 0.0 ? typedPrice : 0.0;
    if (priceItem && partId > 0) {
        const double storedPurchase = priceItem->data(RolePurchasePrice).toDouble();
        const double storedDisplay = priceItem->data(RoleDisplayPrice).toDouble();
        if (qAbs(typedPrice - storedDisplay) < 0.005 && storedPurchase >= 0.0) {
            purchasePrice = storedPurchase;
        }
    }
    const double pct = effectivePartMarkupPercent(name, store);
    const double clientPrice = applyMarkup(purchasePrice, pct);

    if (priceItem) {
        priceItem->setData(RolePurchasePrice, purchasePrice);
        priceItem->setData(RoleDisplayPrice, clientPrice);
        priceItem->setData(RoleMarkupPercent, pct);
    }

    QSqlQuery q(Database::db());
    if (partId > 0) {
        q.prepare("UPDATE work_order_parts SET ordered_at=?, name=?, qty=?, price=?, amount=?, store=?, part_number=?, purchase_price=?, purchase_amount=?, markup_percent=? WHERE id=? AND order_number=?");
        q.addBindValue(orderedAt);
        q.addBindValue(name);
        q.addBindValue(safeQty);
        q.addBindValue(clientPrice);
        q.addBindValue(safeQty * clientPrice);
        q.addBindValue(store);
        q.addBindValue(oemNumber);
        q.addBindValue(purchasePrice);
        q.addBindValue(safeQty * purchasePrice);
        q.addBindValue(pct);
        q.addBindValue(partId);
        q.addBindValue(m_orderNumber);
    } else {
        q.prepare("INSERT INTO work_order_parts(order_number, ordered_at, store, part_number, name, qty, price, amount, service_id, ordered_by_admin, paid, purchase_price, purchase_amount, markup_percent) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        q.addBindValue(m_orderNumber);
        q.addBindValue(orderedAt);
        q.addBindValue(store);
        q.addBindValue(oemNumber);
        q.addBindValue(name);
        q.addBindValue(safeQty);
        q.addBindValue(clientPrice);
        q.addBindValue(safeQty * clientPrice);
        q.addBindValue(0);
        q.addBindValue(1);
        q.addBindValue(0);
        q.addBindValue(purchasePrice);
        q.addBindValue(safeQty * purchasePrice);
        q.addBindValue(pct);
    }
    if (!q.exec()) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), q.lastError().text());
        return false;
    }
    loadPartsForActiveService();
    loadHeader();
    focusSection(1);
    return true;
}

bool WorkPartsDialog::deleteActiveService()
{
    const int row = m_servicesTable ? m_servicesTable->currentRow() : -1;
    if (row < 0) return false;
    auto* item = m_servicesTable->item(row, 0);
    if (!item || item->data(RoleIsHint).toBool()) return false;
    const int serviceId = item->data(RoleId).toInt();
    const QString title = m_servicesTable->item(row, 0) ? m_servicesTable->item(row, 0)->text() : QString();
    const auto r = QMessageBox::question(this, QString::fromUtf8("Підтвердження"),
                                         QString::fromUtf8("Видалити роботу?\n%1").arg(title),
                                         QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (r != QMessageBox::Yes) return false;

    QSqlDatabase d = Database::db();
    if (!d.transaction()) return false;
    QSqlQuery q2(d);
    q2.prepare("DELETE FROM service_masters WHERE service_id=?");
    q2.addBindValue(serviceId);
    if (!q2.exec()) { d.rollback(); return false; }
    QSqlQuery q3(d);
    q3.prepare("DELETE FROM work_order_services WHERE order_number=? AND id=?");
    q3.addBindValue(m_orderNumber);
    q3.addBindValue(serviceId);
    if (!q3.exec()) { d.rollback(); return false; }
    if (!d.commit()) { d.rollback(); return false; }

    m_activeServiceId = 0;
    loadServices();
    ensureServiceSelected();
    loadHeader();
    return true;
}

bool WorkPartsDialog::deleteActivePart()
{
    const int row = m_partsTable ? m_partsTable->currentRow() : -1;
    if (row < 0) return false;
    auto* item = m_partsTable->item(row, 0);
    if (!item || item->data(RoleId).toInt() <= 0) return false;
    const int partId = item->data(RoleId).toInt();
    const auto r = QMessageBox::question(this, QString::fromUtf8("Підтвердження"),
                                         QString::fromUtf8("Видалити запчастину?\n%1").arg(item->text()),
                                         QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (r != QMessageBox::Yes) return false;
    QSqlQuery q(Database::db());
    q.prepare("DELETE FROM work_order_parts WHERE order_number=? AND id=?");
    q.addBindValue(m_orderNumber);
    q.addBindValue(partId);
    if (!q.exec()) return false;
    loadPartsForActiveService();
    loadHeader();
    return true;
}

void WorkPartsDialog::renumberServiceItems()
{
}

void WorkPartsDialog::openAddServicesDialog()
{
    QList<QStringList> existing;
    QSqlQuery q(Database::db());
    q.prepare(
        "SELECT s.id, COALESCE(s.title,''), COALESCE(s.price,0), "
        "COALESCE(MAX(NULLIF(m.name,'')), MAX(NULLIF(sm.master_name_closed,'')), '') "
        "FROM work_order_services s "
        "LEFT JOIN service_masters sm ON sm.service_id=s.id "
        "LEFT JOIN masters m ON m.id=sm.master_id "
        "WHERE s.order_number=? "
        "GROUP BY s.id, s.title, s.price "
        "ORDER BY s.id");
    q.addBindValue(m_orderNumber);
    if (q.exec()) while (q.next()) {
        existing << (QStringList() << q.value(1).toString() << FormatUtils::smartQty(q.value(2).toDouble(), 2) << q.value(3).toString());
    }

    const auto rows = runBatchEditor(this, existing.isEmpty() ? QString::fromUtf8("Додати нову роботу")
                                                            : QString::fromUtf8("Додати / редагувати роботи"),
                                     {QString::fromUtf8("Робота"), QString::fromUtf8("Вартість виконання робіт"), QString::fromUtf8("Майстер")},
                                     existing, QStringLiteral("orders.batch.services.add.header"));
    if (rows.isEmpty() && !existing.isEmpty()) return;
    if (rows.isEmpty()) return;

    const auto masters = Database::masters(true);
    QMap<QString, MasterRow> mastersByName;
    for (const auto& m : masters) mastersByName.insert(m.name.trimmed().toLower(), m);

    const QString primaryMasterId = m_masterCombo ? m_masterCombo->currentData().toString() : QString();
    const QString primaryMasterName = currentPrimaryMasterName(m_masterCombo);

    QSqlDatabase db = Database::db();
    if (!db.transaction()) return;

    QSqlQuery delSm(db);
    delSm.prepare("DELETE FROM service_masters WHERE service_id IN (SELECT id FROM work_order_services WHERE order_number=?)");
    delSm.addBindValue(m_orderNumber);
    if (!delSm.exec()) { db.rollback(); QMessageBox::critical(this, QString::fromUtf8("Помилка"), delSm.lastError().text()); return; }

    QSqlQuery delS(db);
    delS.prepare("DELETE FROM work_order_services WHERE order_number=?");
    delS.addBindValue(m_orderNumber);
    if (!delS.exec()) { db.rollback(); QMessageBox::critical(this, QString::fromUtf8("Помилка"), delS.lastError().text()); return; }

    int lastServiceId = 0;
    for (const auto& row : rows) {
        const QString title = normalizeSentence(row.value(0));
        if (title.trimmed().isEmpty()) continue;

        bool okPrice = false;
        const double price = parseLooseNumber(row.value(1).trimmed(), &okPrice);
        const double safePrice = okPrice ? qMax(0.0, price) : 0.0;

        QSqlQuery ins(db);
        ins.prepare("INSERT INTO work_order_services(order_number, title, qty, price, amount) VALUES(?,?,?,?,?)");
        ins.addBindValue(m_orderNumber);
        ins.addBindValue(title);
        ins.addBindValue(1.0);
        ins.addBindValue(safePrice);
        ins.addBindValue(safePrice);
        if (!ins.exec()) { db.rollback(); QMessageBox::critical(this, QString::fromUtf8("Помилка"), ins.lastError().text()); return; }

        lastServiceId = ins.lastInsertId().toInt();

        QString masterId = primaryMasterId;
        QString masterName = primaryMasterName;
        const QString enteredMasterName = row.value(2).trimmed();
        if (!enteredMasterName.isEmpty()) {
            const auto it = mastersByName.constFind(enteredMasterName.toLower());
            if (it != mastersByName.cend()) {
                masterId = it->id;
                masterName = it->name;
            } else {
                masterName = enteredMasterName;
            }
        }

        if (!masterId.isEmpty()) {
            QSqlQuery insMaster(db);
            insMaster.prepare("INSERT INTO service_masters(service_id, master_id, share_percent, role, master_name_closed) VALUES(?,?,?,?,?)");
            insMaster.addBindValue(lastServiceId);
            insMaster.addBindValue(masterId);
            insMaster.addBindValue(100.0);
            insMaster.addBindValue(QString::fromUtf8("master"));
            insMaster.addBindValue(masterName);
            if (!insMaster.exec()) { db.rollback(); QMessageBox::critical(this, QString::fromUtf8("Помилка"), insMaster.lastError().text()); return; }
        }
    }

    if (!db.commit()) { db.rollback(); return; }
    m_activeServiceId = lastServiceId;
    loadServices();
    ensureServiceSelected();
    loadHeader();
}

void WorkPartsDialog::openEditServicesDialog()
{
    QList<QStringList> existing;
    QSqlQuery q(Database::db());
    q.prepare(
        "SELECT s.id, COALESCE(s.title,''), COALESCE(s.price,0), "
        "COALESCE(MAX(NULLIF(m.name,'')), MAX(NULLIF(sm.master_name_closed,'')), '') "
        "FROM work_order_services s "
        "LEFT JOIN service_masters sm ON sm.service_id=s.id "
        "LEFT JOIN masters m ON m.id=sm.master_id "
        "WHERE s.order_number=? "
        "GROUP BY s.id, s.title, s.price "
        "ORDER BY s.id");
    q.addBindValue(m_orderNumber);
    if (q.exec()) while (q.next()) {
        existing << (QStringList() << q.value(1).toString() << FormatUtils::smartQty(q.value(2).toDouble(), 2) << q.value(3).toString());
    }

    const auto rows = runBatchEditor(this, QString::fromUtf8("Редагувати роботи"),
                                     {QString::fromUtf8("Робота"), QString::fromUtf8("Вартість виконання робіт"), QString::fromUtf8("Майстер")}, existing, QStringLiteral("orders.batch.services.edit.header"));
    if (rows.isEmpty() && !existing.isEmpty()) return;

    const auto masters = Database::masters(true);
    QMap<QString, MasterRow> mastersByName;
    for (const auto& m : masters) mastersByName.insert(m.name.trimmed().toLower(), m);

    const QString primaryMasterId = m_masterCombo ? m_masterCombo->currentData().toString() : QString();
    const QString primaryMasterName = currentPrimaryMasterName(m_masterCombo);

    QSqlDatabase db = Database::db();
    if (!db.transaction()) return;

    QSqlQuery delSm(db);
    delSm.prepare("DELETE FROM service_masters WHERE service_id IN (SELECT id FROM work_order_services WHERE order_number=?)");
    delSm.addBindValue(m_orderNumber);
    if (!delSm.exec()) { db.rollback(); QMessageBox::critical(this, QString::fromUtf8("Помилка"), delSm.lastError().text()); return; }

    QSqlQuery delS(db);
    delS.prepare("DELETE FROM work_order_services WHERE order_number=?");
    delS.addBindValue(m_orderNumber);
    if (!delS.exec()) { db.rollback(); QMessageBox::critical(this, QString::fromUtf8("Помилка"), delS.lastError().text()); return; }

    int lastServiceId = 0;
    for (const auto& row : rows) {
        const QString title = normalizeSentence(row.value(0));
        if (title.trimmed().isEmpty()) continue;

        bool okPrice = false;
        const double price = parseLooseNumber(row.value(1).trimmed(), &okPrice);
        const double safePrice = okPrice ? qMax(0.0, price) : 0.0;

        QSqlQuery ins(db);
        ins.prepare("INSERT INTO work_order_services(order_number, title, qty, price, amount) VALUES(?,?,?,?,?)");
        ins.addBindValue(m_orderNumber);
        ins.addBindValue(title);
        ins.addBindValue(1.0);
        ins.addBindValue(safePrice);
        ins.addBindValue(safePrice);
        if (!ins.exec()) { db.rollback(); QMessageBox::critical(this, QString::fromUtf8("Помилка"), ins.lastError().text()); return; }

        lastServiceId = ins.lastInsertId().toInt();

        QString masterId = primaryMasterId;
        QString masterName = primaryMasterName;
        const QString enteredMasterName = row.value(2).trimmed();
        if (!enteredMasterName.isEmpty()) {
            const auto it = mastersByName.constFind(enteredMasterName.toLower());
            if (it != mastersByName.cend()) {
                masterId = it->id;
                masterName = it->name;
            } else {
                masterName = enteredMasterName;
            }
        }

        if (!masterId.isEmpty()) {
            QSqlQuery insMaster(db);
            insMaster.prepare("INSERT INTO service_masters(service_id, master_id, share_percent, role, master_name_closed) VALUES(?,?,?,?,?)");
            insMaster.addBindValue(lastServiceId);
            insMaster.addBindValue(masterId);
            insMaster.addBindValue(100.0);
            insMaster.addBindValue(QString::fromUtf8("master"));
            insMaster.addBindValue(masterName);
            if (!insMaster.exec()) { db.rollback(); QMessageBox::critical(this, QString::fromUtf8("Помилка"), insMaster.lastError().text()); return; }
        }
    }

    if (!db.commit()) { db.rollback(); return; }
    m_activeServiceId = lastServiceId;
    loadServices();
    ensureServiceSelected();
    loadHeader();
}

void WorkPartsDialog::openAddPartsDialog()
{
    const auto rows = runBatchEditor(this, QString::fromUtf8("Додати запчастину"),
                                     {QString::fromUtf8("Дата замовлення"), QString::fromUtf8("OEM номер"), QString::fromUtf8("Запчастина"), QString::fromUtf8("Кіл-ть"), QString::fromUtf8("Ціна"), QString::fromUtf8("Вартість"), QString::fromUtf8("Магазин"), QString::fromUtf8("Замовник")}, {}, QStringLiteral("orders.batch.parts.add.header"));
    if (rows.isEmpty()) return;
    for (const auto& row : rows) {
        QSqlQuery q(Database::db());
        bool okQty = false, okPrice = false;
        const QString orderedAt = storedDateFromDisplay(row.value(0));
        const QString oemNumber = row.value(1).trimmed();
        const QString partName = normalizeSentence(row.value(2));
        const double qty = parseLooseNumber(row.value(3).trimmed(), &okQty);
        const double price = parseLooseNumber(row.value(4).trimmed(), &okPrice);
        const QString store = normalizeSentence(row.value(6));
        const double safeQty = okQty && qty > 0 ? qty : 1.0;
        const double purchasePrice = okPrice && price >= 0 ? price : 0.0;
        const double pct = effectivePartMarkupPercent(partName, store);
        const double clientPrice = applyMarkup(purchasePrice, pct);
        q.prepare("INSERT INTO work_order_parts(order_number, ordered_at, store, part_number, name, qty, price, amount, service_id, ordered_by_admin, paid, purchase_price, purchase_amount, markup_percent) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        q.addBindValue(m_orderNumber);
        q.addBindValue(orderedAt);
        q.addBindValue(store);
        q.addBindValue(oemNumber);
        q.addBindValue(partName);
        q.addBindValue(safeQty);
        q.addBindValue(clientPrice);
        q.addBindValue(safeQty * clientPrice);
        q.addBindValue(0);
        q.addBindValue(1);
        q.addBindValue(0);
        q.addBindValue(purchasePrice);
        q.addBindValue(safeQty * purchasePrice);
        q.addBindValue(pct);
        q.exec();
    }
    loadPartsForActiveService();
    loadHeader();
}

void WorkPartsDialog::openEditPartsDialog()
{
    QList<QStringList> existing;
    QSqlQuery q(Database::db());
    q.prepare("SELECT id, COALESCE(name,''), COALESCE(qty,1), COALESCE(purchase_price, COALESCE(price,0)), COALESCE(amount,0), COALESCE(store,''), COALESCE(part_number,''), COALESCE(ordered_at,'') FROM work_order_parts WHERE order_number=? ORDER BY id");
    q.addBindValue(m_orderNumber);
    if (q.exec()) {
        while (q.next()) {
            existing << (QStringList()
                         << displayDateFromStored(q.value(7).toString())
                         << q.value(6).toString()
                         << q.value(1).toString()
                         << FormatUtils::smartQty(q.value(2).toDouble(), 2)
                         << moneyText(q.value(3).toDouble())
                         << moneyText(q.value(4).toDouble())
                         << q.value(5).toString()
                         << QString());
        }
    }
    const auto rows = runBatchEditor(this, QString::fromUtf8("Редагувати запчастини"),
                                     {QString::fromUtf8("Дата замовлення"), QString::fromUtf8("OEM номер"), QString::fromUtf8("Запчастина"), QString::fromUtf8("Кіл-ть"), QString::fromUtf8("Ціна"), QString::fromUtf8("Вартість"), QString::fromUtf8("Магазин"), QString::fromUtf8("Замовник")},
                                     existing, QStringLiteral("orders.batch.parts.edit.header"));
    if (rows.isEmpty() && !existing.isEmpty()) return;

    QSqlQuery del(Database::db());
    del.prepare("DELETE FROM work_order_parts WHERE order_number=?");
    del.addBindValue(m_orderNumber);
    if (!del.exec()) return;

    for (const auto& row : rows) {
        bool okQty = false, okPrice = false;
        const QString orderedAt = storedDateFromDisplay(row.value(0));
        const QString oemNumber = row.value(1).trimmed();
        const QString partName = normalizeSentence(row.value(2));
        const double qty = parseLooseNumber(row.value(3).trimmed(), &okQty);
        const double price = parseLooseNumber(row.value(4).trimmed(), &okPrice);
        const QString store = normalizeSentence(row.value(6));
        const double safeQty = okQty && qty > 0 ? qty : 1.0;
        const double purchasePrice = okPrice && price >= 0 ? price : 0.0;
        const double pct = effectivePartMarkupPercent(partName, store);
        const double clientPrice = applyMarkup(purchasePrice, pct);

        QSqlQuery ins(Database::db());
        ins.prepare("INSERT INTO work_order_parts(order_number, ordered_at, store, part_number, name, qty, price, amount, service_id, ordered_by_admin, paid, purchase_price, purchase_amount, markup_percent) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        ins.addBindValue(m_orderNumber);
        ins.addBindValue(orderedAt);
        ins.addBindValue(store);
        ins.addBindValue(oemNumber);
        ins.addBindValue(partName);
        ins.addBindValue(safeQty);
        ins.addBindValue(clientPrice);
        ins.addBindValue(safeQty * clientPrice);
        ins.addBindValue(0);
        ins.addBindValue(1);
        ins.addBindValue(0);
        ins.addBindValue(purchasePrice);
        ins.addBindValue(safeQty * purchasePrice);
        ins.addBindValue(pct);
        ins.exec();
    }
    loadPartsForActiveService();
    loadHeader();
}

void WorkPartsDialog::showServicesMenu(const QPoint& pos)
{
    const int row = m_servicesTable->rowAt(pos.y());
    if (row >= 0) m_servicesTable->setCurrentCell(row, 0);
    QMenu menu(this);
    QAction* del = menu.addAction(QString::fromUtf8("Видалити роботу"));
    QAction* chosen = menu.exec(m_servicesTable->viewport()->mapToGlobal(pos));
    if (chosen == del) deleteActiveService();
}

void WorkPartsDialog::showPartsMenu(const QPoint& pos)
{
    const int row = m_partsTable->rowAt(pos.y());
    if (row >= 0) m_partsTable->setCurrentCell(row, 0);

    QMenu menu(this);
    QAction* del = menu.addAction(QString::fromUtf8("Видалити запчастину"));
    QAction* chosen = menu.exec(m_partsTable->viewport()->mapToGlobal(pos));
    if (chosen == del) deleteActivePart();
}
