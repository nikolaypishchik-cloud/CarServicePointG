#pragma once

#include <QDialog>

class QLabel;
class QTableWidget;
class QSplitter;
class QComboBox;
class QPushButton;

class WorkPartsDialog : public QDialog
{
    Q_OBJECT
public:
    explicit WorkPartsDialog(QWidget* parent, int orderNumber);

    void setEmbedded(bool on);
    bool isEmbedded() const { return m_embedded; }

signals:
    void requestOk();
    void requestCancel();
    void requestPdf();
    void requestCloseOrder();

private:
    void buildUi();
    void loadHeader();
    void loadMasterChoice();
    void loadServices();
    void loadPartsForActiveService();

    void ensureServiceSelected();
    void setActiveServiceId(int serviceId);
    void syncServiceVisualSelection();
    void focusSection(int section);

    bool insertService(const QString& title, const QString& prefix = QString());
    bool savePrimaryMaster();
    bool savePartRow(int row);
    void openAddServicesDialog();
    void openEditServicesDialog();
    void openAddPartsDialog();
    void openEditPartsDialog();
    bool deleteActiveService();
    bool deleteActivePart();
    bool setServiceMaster(const QString& masterId, const QString& masterName);
    bool setServicePrice(double price);
    bool clearServiceMaster();
    void insertEmptyPartRow();
    void renumberServiceItems();
    void showServicesMenu(const QPoint& pos);
    void showPartsMenu(const QPoint& pos);

    int activeServiceId() const;

    int m_orderNumber = -1;
    int m_activeServiceId = 0;
    bool m_embedded = false;
    bool m_syncingServices = false;
    bool m_loadingParts = false;

    QLabel* m_lblTitle = nullptr;
    QLabel* m_lblSub = nullptr;
    QLabel* m_lblPartHint = nullptr;

    QComboBox* m_masterCombo = nullptr;
    QPushButton* m_btnSaveMaster = nullptr;
    QPushButton* m_btnAddService = nullptr;
    QPushButton* m_btnEditService = nullptr;
    QPushButton* m_btnAddPart = nullptr;
    QPushButton* m_btnEditPart = nullptr;
    QPushButton* m_btnOutsource = nullptr;
    QPushButton* m_btnPdf = nullptr;
    QPushButton* m_btnCloseOrder = nullptr;

    QTableWidget* m_servicesTable = nullptr;
    QTableWidget* m_partsTable = nullptr;
    QSplitter* m_split = nullptr;
};
