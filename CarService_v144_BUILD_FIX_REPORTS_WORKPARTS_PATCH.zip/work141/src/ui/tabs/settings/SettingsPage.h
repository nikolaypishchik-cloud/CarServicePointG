#pragma once

#include <QWidget>
#include <QList>
#include <QMap>

class QLabel;
class QListWidget;
class QStackedWidget;
class QButtonGroup;

class SettingsPage : public QWidget
{
    Q_OBJECT
public:
    explicit SettingsPage(QWidget* parent=nullptr);

signals:
    void requestRefreshAll();

private:
    enum class Category {
        General,
        Ui,
        Personnel,
        Integrations,
        Finance,
        Reports,
        Outsource
    };

    struct Item {
        QString id;
        QString title;
    };

    void buildUi();
    void buildCategoryButtons(QWidget* parent);
    void buildRightPane(QWidget* parent);

    void setCategory(Category c);
    void rebuildItems();
    void showItem(const QString& id);

    QWidget* buildDetailWidget(const QString& id);
    QWidget* buildPlaceholderWidget(const QString& text);

    // Helpers
    static QString categoryTitle(Category c);

private:
    Category m_category = Category::General;

    QButtonGroup* m_catGroup = nullptr;
    QLabel* m_hdrTitle = nullptr;
    QListWidget* m_items = nullptr;
    QStackedWidget* m_detail = nullptr;
    QLabel* m_footer = nullptr;

    QMap<QString, int> m_detailIndexById;
    QMap<Category, QList<Item>> m_itemsByCategory;
};
