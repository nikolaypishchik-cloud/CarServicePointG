#include "ui/tabs/settings/SettingsPage.h"

#include "app/App.h"
#include "infrastructure/db/sqlite/Db.h"
#include "ui/theme/ThemeManager.h"
#include "integrations/opendatabot/OpenDataBotClient.h"
#include "ui/common/dialogs/MasterEditDialog.h"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFrame>
#include <QLabel>
#include <QPushButton>
#include <QButtonGroup>
#include <QListWidget>
#include <QStackedWidget>
#include <QSplitter>
#include <QGraphicsDropShadowEffect>
#include <QColor>
#include <QCheckBox>
#include <QSlider>
#include <QToolButton>
#include <QLineEdit>
#include <QFileDialog>
#include <QFileInfo>
#include <QFile>
#include <QDir>
#include <QMessageBox>
#include <QFormLayout>
#include <QComboBox>
#include <QPixmap>
#include <QApplication>
#include <QGroupBox>
#include <QTableWidget>
#include <QHeaderView>
#include <QDoubleSpinBox>
#include <QSqlQuery>
#include <QJsonDocument>
#include <QListView>
#include <QJsonObject>
#include <QTabWidget>
#include <QToolBar>
#include <QUuid>


#include <QPlainTextEdit>
#include <QSignalBlocker>
#include <QJsonArray>
#include <QFontComboBox>
#include <QSpinBox>
#include <QColorDialog>
#include <memory>
#include <QSet>



// Forward declarations for theme helpers used by outsource settings UI.
static bool isDarkUi();
static QString cPrimary();
static QString cSecondary();
static QString cPanelBg();
static QString cPanelBorder();
static QString cBarBg();
static QString cListText();
static QString cSelBg();

namespace {

static QString canonStoreKey_local(const QString& s)
{
    QString t = s.trimmed().toLower();
    t.replace(QChar(0x0456), QChar(0x0438));
    t.replace(QChar(0x0457), QChar(0x0438));
    t.replace(QChar(0x0454), QChar(0x0435));
    t.replace(QChar(0x0491), QChar(0x0433));
    QString out;
    out.reserve(t.size());
    for (const QChar& ch : t) {
        if (ch.isLetterOrNumber()) out.append(ch);
    }
    return out;
}

static bool isMotorOilPartName_local(const QString& name)
{
    const QString folded = name.toCaseFolded().simplified();
    return folded.contains(QString::fromUtf8("масло"))
        || folded.contains(QString::fromUtf8("мастило"))
        || folded.contains(QStringLiteral("engine oil"))
        || folded.contains(QStringLiteral("motor oil"))
        || folded == QStringLiteral("oil");
}

static QMap<QString,double> loadMarkupMapFromJsonObject(const QString& raw)
{
    QMap<QString,double> out;
    const auto doc = QJsonDocument::fromJson(raw.toUtf8());
    if (!doc.isObject()) return out;
    const auto obj = doc.object();
    for (auto it = obj.begin(); it != obj.end(); ++it) {
        const QString key = it.key().trimmed();
        bool ok = false;
        const double value = it.value().toVariant().toDouble(&ok);
        if (!key.isEmpty() && ok) out.insert(key, value);
    }
    return out;
}

static double lookupStoreMarkupPercent_local(const QMap<QString,double>& mp, const QString& store)
{
    const QString s = store.trimmed();
    if (s.isEmpty()) return 0.0;
    if (mp.contains(s)) return mp.value(s);
    const QString key = canonStoreKey_local(s);
    for (auto it = mp.begin(); it != mp.end(); ++it) {
        if (canonStoreKey_local(it.key()) == key) return it.value();
    }
    return 0.0;
}

static double effectivePartMarkupPercent_local(const QString& partName, const QString& store,
                                               const QMap<QString,double>& partsMap,
                                               const QMap<QString,double>& oilMap,
                                               double defaultParts, double defaultOil)
{
    if (isMotorOilPartName_local(partName)) {
        const double oilStorePct = lookupStoreMarkupPercent_local(oilMap, store);
        return oilStorePct > 0.0 ? oilStorePct : defaultOil;
    }
    const double storePct = lookupStoreMarkupPercent_local(partsMap, store);
    return storePct > 0.0 ? storePct : defaultParts;
}

static void recalcAllPartMarkupsFromSettings()
{
    const auto partsMap = loadMarkupMapFromJsonObject(Database::getSetting("settings.fin.store_markups", "{}").toString());
    const auto oilMap = loadMarkupMapFromJsonObject(Database::getSetting("settings.fin.oil_store_markups", "{}").toString());
    const double defaultParts = Database::getSetting("settings.fin.parts_markup", "0").toDouble();
    const double defaultOil = Database::getSetting("settings.fin.oil_markup", "0").toDouble();

    QSqlDatabase db = Database::db();
    if (!db.transaction()) return;

    QSqlQuery q(db);
    q.prepare("SELECT id, COALESCE(name,''), COALESCE(store,''), COALESCE(qty,1), COALESCE(purchase_price, CASE WHEN COALESCE(purchase_amount,0)>0 AND COALESCE(qty,0)>0 THEN COALESCE(purchase_amount,0)/COALESCE(qty,1) ELSE COALESCE(price,0) END), COALESCE(purchase_amount,0), COALESCE(markup_percent,0) FROM work_order_parts");
    if (!q.exec()) { db.rollback(); return; }

    QSqlQuery upd(db);
    upd.prepare("UPDATE work_order_parts SET price=?, amount=?, purchase_price=?, purchase_amount=?, markup_percent=? WHERE id=?");
    while (q.next()) {
        const int id = q.value(0).toInt();
        const QString partName = q.value(1).toString();
        const QString store = q.value(2).toString();
        const double qty = qMax(1.0, q.value(3).toDouble());
        double purchasePrice = q.value(4).toDouble();
        if (purchasePrice <= 0.0) {
            const double purchaseAmount = q.value(5).toDouble();
            if (purchaseAmount > 0.0 && qty > 0.0) purchasePrice = purchaseAmount / qty;
        }
        const double pct = effectivePartMarkupPercent_local(partName, store, partsMap, oilMap, defaultParts, defaultOil);
        const double clientPrice = purchasePrice * (1.0 + qMax(0.0, pct) / 100.0);
        upd.addBindValue(clientPrice);
        upd.addBindValue(clientPrice * qty);
        upd.addBindValue(purchasePrice);
        upd.addBindValue(purchasePrice * qty);
        upd.addBindValue(pct);
        upd.addBindValue(id);
        if (!upd.exec()) { db.rollback(); return; }
        upd.finish();
    }

    db.commit();
}

struct OutsourceEntry {
    QString id;
    QString company;
    QString address;
    QString contact;
    QString branch;
    QString note;
    double markup = 20.0;
};

static QJsonObject outsourceToJson(const OutsourceEntry& e)
{
    QJsonObject o;
    o["id"] = e.id;
    o["company"] = e.company;
    o["address"] = e.address;
    o["contact"] = e.contact;
    o["branch"] = e.branch;
    o["note"] = e.note;
    o["markup"] = e.markup;
    return o;
}

static OutsourceEntry outsourceFromJson(const QJsonObject& o)
{
    OutsourceEntry e;
    e.id = o.value("id").toString();
    if (e.id.isEmpty()) e.id = QUuid::createUuid().toString(QUuid::WithoutBraces);
    e.company = o.value("company").toString();
    e.address = o.value("address").toString();
    e.contact = o.value("contact").toString();
    e.branch = o.value("branch").toString();
    e.note = o.value("note").toString();
    e.markup = o.value("markup").toDouble(20.0);
    return e;
}

static QList<OutsourceEntry> loadOutsourceEntries()
{
    QList<OutsourceEntry> out;
    const auto raw = Database::getSetting("settings.out.items", QString()).toString();
    if (!raw.trimmed().isEmpty()) {
        const auto doc = QJsonDocument::fromJson(raw.toUtf8());
        if (doc.isArray()) {
            const auto arr = doc.array();
            for (const auto& v : arr) {
                if (v.isObject()) out.push_back(outsourceFromJson(v.toObject()));
            }
        }
    }
    if (out.isEmpty()) {
        out.push_back({QUuid::createUuid().toString(QUuid::WithoutBraces), QString::fromUtf8("Ремонт генераторів"), QString(), QString(), QString(), QString(), 20.0});
        out.push_back({QUuid::createUuid().toString(QUuid::WithoutBraces), QString::fromUtf8("Ремонт стартерів"), QString(), QString(), QString(), QString(), 20.0});
        out.push_back({QUuid::createUuid().toString(QUuid::WithoutBraces), QString::fromUtf8("Ремонт форсунок"), QString(), QString(), QString(), QString(), 20.0});
    }
    return out;
}

static void saveOutsourceEntries(const QList<OutsourceEntry>& entries)
{
    QJsonArray arr;
    for (const auto& e : entries) arr.push_back(outsourceToJson(e));
    Database::setSetting("settings.out.items", QString::fromUtf8(QJsonDocument(arr).toJson(QJsonDocument::Compact)));
}

class OutsourceSettingsWidget final : public QWidget
{
public:
    explicit OutsourceSettingsWidget(QWidget* parent=nullptr)
        : QWidget(parent)
    {
        m_entries = loadOutsourceEntries();
        buildUi();
        refreshList();
        if (!m_entries.isEmpty()) {
            m_list->setCurrentRow(0);
            openEditor(0);
        }
    }

private:
    QList<OutsourceEntry> m_entries;
    QListWidget* m_list = nullptr;
    QStackedWidget* m_stack = nullptr;
    QWidget* m_listPage = nullptr;
    QWidget* m_editPage = nullptr;
    QLabel* m_editTitle = nullptr;
    QLineEdit* m_company = nullptr;
    QLineEdit* m_address = nullptr;
    QLineEdit* m_contact = nullptr;
    QLineEdit* m_branch = nullptr;
    QPlainTextEdit* m_note = nullptr;
    QDoubleSpinBox* m_markup = nullptr;
    int m_currentIndex = -1;

    void buildUi()
    {
        auto* root = new QVBoxLayout(this);
        root->setContentsMargins(14, 14, 14, 14);
        root->setSpacing(10);

        auto* title = new QLabel(QString::fromUtf8("Аутсорс"), this);
        title->setStyleSheet(QString("font-size:16pt; font-weight:800; color:%1;").arg(cPrimary()));
        root->addWidget(title);

        m_stack = new QStackedWidget(this);
        root->addWidget(m_stack, 1);

        buildListPage();
        buildEditPage();
        m_stack->setCurrentWidget(m_listPage);
    }

    void buildListPage()
    {
        m_listPage = new QWidget(this);
        auto* l = new QVBoxLayout(m_listPage);
        l->setContentsMargins(0,0,0,0);
        l->setSpacing(12);

        auto* panel = new QFrame(m_listPage);
        panel->setStyleSheet(QString("QFrame{background:%1;border:1px solid %2;border-radius:14px;}"
                                    "QListWidget{background:transparent;border:none;color:%3;font-size:11pt;}"
                                    "QListWidget::item{padding:14px 18px;border-radius:10px;}"
                                    "QListWidget::item:selected{background:%4;}"
                                   ).arg(isDarkUi()?"#171b21":"#f5f5f5").arg(cPanelBorder()).arg(cPrimary()).arg(cSelBg()));
        auto* pl = new QVBoxLayout(panel);
        pl->setContentsMargins(14,14,14,14);
        pl->setSpacing(10);

        m_list = new QListWidget(panel);
        m_list->setSelectionMode(QAbstractItemView::SingleSelection);
        pl->addWidget(m_list, 1);
        l->addWidget(panel, 1);

        auto* btnRow = new QHBoxLayout();
        auto mk = [this](const QString& t){ auto* b=new QPushButton(t,this); b->setMinimumHeight(42); b->setMinimumWidth(160); return b; };
        auto* btnAdd = mk(QString::fromUtf8("Додати"));
        auto* btnDelete = mk(QString::fromUtf8("Видалити"));
        auto* btnSave = mk(QString::fromUtf8("Зберегти"));
        btnRow->addWidget(btnAdd);
        btnRow->addWidget(btnDelete);
        btnRow->addWidget(btnSave);
        btnRow->addStretch(1);
        l->addLayout(btnRow);

        auto* hint = new QLabel(QString::fromUtf8("Оберіть пункт праворуч для відкриття детальних налаштувань."), m_listPage);
        hint->setStyleSheet(QString("color:%1;font-size:10pt;").arg(cSecondary()));
        l->addWidget(hint);

        connect(m_list, &QListWidget::itemDoubleClicked, this, [this](QListWidgetItem* it) {
            if (!it) return;
            openEditor(m_list->row(it));
        });
        connect(m_list, &QListWidget::itemClicked, this, [this](QListWidgetItem* it) {
            if (!it) return;
            openEditor(m_list->row(it));
        });
        connect(btnAdd, &QPushButton::clicked, this, [this]() {
            OutsourceEntry e;
            e.id = QUuid::createUuid().toString(QUuid::WithoutBraces);
            e.company = QString::fromUtf8("Нова компанія");
            e.markup = 20.0;
            m_entries.push_back(e);
            refreshList();
            openEditor(m_entries.size()-1);
        });
        connect(btnDelete, &QPushButton::clicked, this, [this]() {
            const int row = m_list->currentRow();
            if (row < 0 || row >= m_entries.size()) return;
            m_entries.removeAt(row);
            saveOutsourceEntries(m_entries);
            refreshList();
            if (!m_entries.isEmpty()) m_list->setCurrentRow(qMin(row, m_entries.size()-1));
        });
        connect(btnSave, &QPushButton::clicked, this, [this]() {
            saveOutsourceEntries(m_entries);
            QMessageBox::information(this, QString::fromUtf8("Аутсорс"), QString::fromUtf8("Налаштування аутсорсу збережено."));
        });

        m_stack->addWidget(m_listPage);
    }

    void buildEditPage()
    {
        m_editPage = new QWidget(this);
        auto* l = new QVBoxLayout(m_editPage);
        l->setContentsMargins(0,0,0,0);
        l->setSpacing(12);

        auto* top = new QHBoxLayout();
        auto* btnBack = new QPushButton(QString::fromUtf8("← Назад"), m_editPage);
        btnBack->setMinimumHeight(42);
        btnBack->setMinimumWidth(160);
        m_editTitle = new QLabel(QString(), m_editPage);
        m_editTitle->setStyleSheet(QString("font-size:14pt; font-weight:800; color:%1;").arg(cPrimary()));
        auto* btnCancel = new QPushButton(QString::fromUtf8("Скасувати"), m_editPage);
        auto* btnApply = new QPushButton(QString::fromUtf8("Зберегти"), m_editPage);
        btnCancel->setMinimumHeight(42);
        btnApply->setMinimumHeight(42);
        btnCancel->setMinimumWidth(160);
        btnApply->setMinimumWidth(160);
        top->addWidget(btnBack);
        top->addWidget(m_editTitle, 1);
        top->addWidget(btnCancel);
        top->addWidget(btnApply);
        l->addLayout(top);

        auto* panel = new QFrame(m_editPage);
        panel->setStyleSheet(QString("QFrame{background:%1;border:1px solid %2;border-radius:18px;}"
                                    "QLineEdit,QPlainTextEdit,QDoubleSpinBox{background:%3;border:1px solid %2;border-radius:14px;padding:10px 14px;color:%4;}"
                                    "QPlainTextEdit{padding-top:12px;}"
                                    ).arg(isDarkUi()?"#161a20":"#f7f7f7").arg(cPanelBorder()).arg(isDarkUi()?"#1b2027":"#ffffff").arg(cPrimary()));
        auto* pl = new QVBoxLayout(panel);
        pl->setContentsMargins(20,20,20,20);
        pl->setSpacing(14);

        auto* tabChip = new QLabel(QString::fromUtf8("Компанія"), panel);
        tabChip->setStyleSheet(QString("background:%1;border:1px solid %2;border-radius:12px;padding:6px 14px;color:%3;").arg(isDarkUi()?"#222831":"#fff").arg(cPanelBorder()).arg(cPrimary()));
        pl->addWidget(tabChip, 0, Qt::AlignLeft);

        auto* form = new QFormLayout();
        form->setLabelAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        form->setFormAlignment(Qt::AlignTop);
        form->setHorizontalSpacing(26);
        form->setVerticalSpacing(16);

        m_company = new QLineEdit(panel);
        m_address = new QLineEdit(panel);
        m_contact = new QLineEdit(panel);
        m_branch = new QLineEdit(panel);
        m_note = new QPlainTextEdit(panel);
        m_note->setFixedHeight(120);
        m_markup = new QDoubleSpinBox(panel);
        m_markup->setRange(0.0, 300.0);
        m_markup->setDecimals(1);
        m_markup->setSuffix(QString::fromUtf8(" %"));
        m_markup->setSingleStep(1.0);
        m_markup->setMinimumWidth(180);

        m_company->setPlaceholderText(QString::fromUtf8("Компанія"));
        m_address->setPlaceholderText(QString::fromUtf8("Адреса / місто"));
        m_contact->setPlaceholderText(QString::fromUtf8("Ім'я та телефон"));
        m_branch->setPlaceholderText(QString::fromUtf8("Нова Пошта (№/адреса)"));
        m_note->setPlaceholderText(QString::fromUtf8("Примітка (опціонально)"));

        form->addRow(QString::fromUtf8("Компанія"), m_company);
        form->addRow(QString::fromUtf8("Де знаходиться (адреса)"), m_address);
        form->addRow(QString::fromUtf8("Відповідальний (ім'я, телефон)"), m_contact);
        form->addRow(QString::fromUtf8("Відділення НП"), m_branch);
        form->addRow(QString::fromUtf8("Примітка"), m_note);
        form->addRow(QString::fromUtf8("Доданий % до ремонту"), m_markup);
        pl->addLayout(form);
        l->addWidget(panel, 1);

        auto* hint = new QLabel(QString::fromUtf8("Оберіть пункт праворуч для відкриття детальних налаштувань."), m_editPage);
        hint->setStyleSheet(QString("color:%1;font-size:10pt;").arg(cSecondary()));
        l->addWidget(hint);

        connect(btnBack, &QPushButton::clicked, this, [this]() { m_stack->setCurrentWidget(m_listPage); });
        connect(btnCancel, &QPushButton::clicked, this, [this]() { m_stack->setCurrentWidget(m_listPage); });
        connect(btnApply, &QPushButton::clicked, this, [this]() {
            applyEditor();
            saveOutsourceEntries(m_entries);
            refreshList();
            m_stack->setCurrentWidget(m_listPage);
        });

        m_stack->addWidget(m_editPage);
    }

    void refreshList()
    {
        const QSignalBlocker blocker(m_list);
        m_list->clear();
        for (const auto& e : m_entries) {
            auto* it = new QListWidgetItem(e.company.trimmed().isEmpty() ? QString::fromUtf8("Без назви") : e.company, m_list);
            it->setData(Qt::UserRole, e.id);
            m_list->addItem(it);
        }
    }

    void openEditor(int row)
    {
        if (row < 0 || row >= m_entries.size()) return;
        m_currentIndex = row;
        const auto& e = m_entries[row];
        m_editTitle->setText(e.company.trimmed().isEmpty() ? QString::fromUtf8("Нова компанія") : e.company);
        m_company->setText(e.company);
        m_address->setText(e.address);
        m_contact->setText(e.contact);
        m_branch->setText(e.branch);
        m_note->setPlainText(e.note);
        m_markup->setValue(e.markup);
        m_stack->setCurrentWidget(m_editPage);
    }

    void applyEditor()
    {
        if (m_currentIndex < 0 || m_currentIndex >= m_entries.size()) return;
        auto& e = m_entries[m_currentIndex];
        e.company = m_company->text().trimmed();
        e.address = m_address->text().trimmed();
        e.contact = m_contact->text().trimmed();
        e.branch = m_branch->text().trimmed();
        e.note = m_note->toPlainText().trimmed();
        e.markup = m_markup->value();
    }
};
} // namespace
static bool isDarkUi()
{
    return ThemeManager::currentTheme() == "graphite";
}

static QString cPrimary()
{
    return isDarkUi() ? QStringLiteral("#f0f0f0") : QStringLiteral("#111");
}

static QString cSecondary()
{
    return isDarkUi() ? QStringLiteral("rgba(240,240,240,0.70)") : QStringLiteral("#444");
}

static QString cPanelBg()
{
    return isDarkUi() ? QStringLiteral("#111316") : QStringLiteral("#ffffff");
}

static QString cPanelBorder()
{
    return isDarkUi() ? QStringLiteral("#3a4048") : QStringLiteral("#3a3a3a");
}

static QString cBarBg()
{
    return isDarkUi() ? QStringLiteral("#2a2f35") : QStringLiteral("#8f8f8f");
}

static QString cListText()
{
    return isDarkUi() ? QStringLiteral("#eaeaea") : QStringLiteral("#111");
}

static QString cSelBg()
{
    return isDarkUi() ? QStringLiteral("rgba(255,255,255,0.08)") : QStringLiteral("rgba(0,0,0,0.06)");
}


static QPushButton* makeNavBtn(const QString& text, QWidget* parent)
{
    auto* b = new QPushButton(text, parent);
    b->setCheckable(true);
    b->setCursor(Qt::PointingHandCursor);
    b->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    b->setFixedHeight(44);
    b->setFocusPolicy(Qt::NoFocus);

    // Shadow to mimic "raised" glossy buttons
    auto* sh = new QGraphicsDropShadowEffect(b);
    sh->setBlurRadius(14);
    sh->setOffset(0, 2);
    sh->setColor(QColor(0,0,0,80));
    b->setGraphicsEffect(sh);

    return b;
}

SettingsPage::SettingsPage(QWidget* parent)
    : QWidget(parent)
{
    // Items (right list) for each category
    m_itemsByCategory[Category::General] = {
        {"general.sounds",      QString::fromUtf8("Звуки та голос")},
        {"general.animations",  QString::fromUtf8("Ефекти / Анімації")},
        {"general.branding",    QString::fromUtf8("Брендинг СТО")},
        {"general.updates",     QString::fromUtf8("Оновлення")},
    };

    m_itemsByCategory[Category::Ui] = {
        {"ui.font",             QString::fromUtf8("Шрифт")},
        {"ui.theme",            QString::fromUtf8("Тема інтерфейсу")},
        {"ui.tables",           QString::fromUtf8("Таблиці та відображення")},
    };

    m_itemsByCategory[Category::Personnel] = {
        {"staff.manage",        QString::fromUtf8("Майстри та адміністратори")},
    };

    m_itemsByCategory[Category::Integrations] = {
        {"int.apikeys",         QString::fromUtf8("API ключі")},
        {"int.stores",          QString::fromUtf8("Магазини")},
        {"int.gsheets",         QString::fromUtf8("Google Sheets")},
    };

    m_itemsByCategory[Category::Finance] = {
        {"fin.defaults",        QString::fromUtf8("Націнка запчастин")},
    };

    m_itemsByCategory[Category::Reports] = {
        {"rep.pdf",             QString::fromUtf8("PDF / друк")},
    };

    m_itemsByCategory[Category::Outsource] = {
        {"out.defaults",        QString::fromUtf8("Аутсорс")},
    };

    buildUi();
    setCategory(Category::General);
}

QString SettingsPage::categoryTitle(Category c)
{
    switch (c) {
    case Category::General:      return QString::fromUtf8("Загальні");
    case Category::Ui:           return QString::fromUtf8("Інтерфейс");
    case Category::Personnel:    return QString::fromUtf8("Персонал");
    case Category::Integrations: return QString::fromUtf8("Інтеграції");
    case Category::Finance:      return QString::fromUtf8("Фінанси");
    case Category::Reports:      return QString::fromUtf8("Звіти");
    case Category::Outsource:    return QString::fromUtf8("Аутсорс");
    }
    return QString();
}

void SettingsPage::buildUi()
{
    auto* root = new QHBoxLayout(this);
    root->setContentsMargins(0,0,0,0);
    root->setSpacing(10);

    // Left: categories (buttons)
    auto* left = new QFrame(this);
    left->setObjectName("settings_left");
    left->setFixedWidth(190);
    left->setStyleSheet(QString::fromUtf8(R"QSS(
        QFrame#settings_left { background: transparent; }
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                        stop:0 #ffffff, stop:1 #e6e6e6);
            border: 1px solid #bfc3c7;
            border-radius: 12px;
            color: #222;
            font-weight: 600;
            padding-left: 14px;
            text-align: left;
        }
        QPushButton:checked {
            background: #d7ffd7;
            border: 2px solid #3ccf3c;
        }
    )QSS"));

    buildCategoryButtons(left);

    // Right: framed pane
    auto* right = new QFrame(this);
    right->setObjectName("settings_right");
    right->setStyleSheet(QString::fromUtf8(R"QSS(
        QFrame#settings_right { background: transparent; }
        QFrame#box {
            background: %1;
            border: 2px solid %2;
        }
        QFrame#hdr, QFrame#ftr {
            background: %3;
        }
        QLabel#hdrTitle {
            color: %6;
            font-weight: 800;
            font-size: 12pt;
            padding-left: 10px;
        }
        QLabel#footerText {
            color: %7;
            padding-left: 10px;
            padding-top: 3px;
            padding-bottom: 3px;
            font-size: 9.5pt;
        }
        QListWidget {
            border: none;
            background: transparent;
            color: %4;
            font-size: 11pt;
        }
        QListWidget::item {
            padding: 10px 10px;
        }
        QListWidget::item:selected {
            background: %5;
            border-radius: 6px;
        }
    )QSS").arg(cPanelBg()).arg(cPanelBorder()).arg(cBarBg()).arg(cListText()).arg(cSelBg()).arg(cPrimary()).arg(cSecondary()));

    buildRightPane(right);

    root->addWidget(left);
    root->addWidget(right, 1);
}

void SettingsPage::buildCategoryButtons(QWidget* parent)
{
    auto* lay = new QVBoxLayout(parent);
    lay->setContentsMargins(10, 18, 10, 10);
    lay->setSpacing(14);

    m_catGroup = new QButtonGroup(this);
    m_catGroup->setExclusive(true);

    struct CBtn { Category c; QString t; };
    const QList<CBtn> btns = {
        {Category::General,      QString::fromUtf8("Загальні")},
        {Category::Ui,           QString::fromUtf8("Інтерфейс")},
        {Category::Personnel,    QString::fromUtf8("Персонал")},
        {Category::Integrations, QString::fromUtf8("Інтеграції")},
        {Category::Finance,      QString::fromUtf8("Фінанси")},
        {Category::Reports,      QString::fromUtf8("Звіти")},
        {Category::Outsource,    QString::fromUtf8("Аутсорс")},
    };

    int idx = 0;
    for (const auto& b : btns) {
        auto* btn = makeNavBtn(b.t, parent);
        m_catGroup->addButton(btn, idx++);
        lay->addWidget(btn);

        connect(btn, &QPushButton::clicked, this, [this, b]() {
            setCategory(b.c);
        });
    }

    lay->addStretch(1);
}

void SettingsPage::buildRightPane(QWidget* parent)
{
    auto* outer = new QVBoxLayout(parent);
    outer->setContentsMargins(0, 0, 0, 0);
    outer->setSpacing(0);

    auto* box = new QFrame(parent);
    box->setObjectName("box");

    auto* boxL = new QVBoxLayout(box);
    boxL->setContentsMargins(0,0,0,0);
    boxL->setSpacing(0);

    // Header bar
    auto* hdr = new QFrame(box);
    hdr->setObjectName("hdr");
    hdr->setFixedHeight(38);
    auto* hdrL = new QHBoxLayout(hdr);
    hdrL->setContentsMargins(0,0,0,0);

    m_hdrTitle = new QLabel(QString(), hdr);
    m_hdrTitle->setObjectName("hdrTitle");
    hdrL->addWidget(m_hdrTitle, 1);

    boxL->addWidget(hdr);

    // Content: list (left) + detail (right)
    auto* split = new QSplitter(Qt::Horizontal, box);
    split->setChildrenCollapsible(false);
    split->setHandleWidth(1);

    m_items = new QListWidget(split);
    m_items->setMinimumWidth(240);
    m_items->setSelectionMode(QAbstractItemView::SingleSelection);
    m_items->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);

    m_detail = new QStackedWidget(split);
    m_detail->addWidget(buildPlaceholderWidget(QString::fromUtf8("Оберіть пункт праворуч для відкриття детальних налаштувань.")));

    split->addWidget(m_items);
    split->addWidget(m_detail);
    split->setStretchFactor(0, 0);
    split->setStretchFactor(1, 1);

    boxL->addWidget(split, 1);

    // Footer bar
    auto* ftr = new QFrame(box);
    ftr->setObjectName("ftr");
    ftr->setFixedHeight(28);
    auto* ftrL = new QHBoxLayout(ftr);
    ftrL->setContentsMargins(0,0,0,0);

    m_footer = new QLabel(QString::fromUtf8("Оберіть пункт праворуч для відкриття детальних налаштувань."), ftr);
    m_footer->setObjectName("footerText");
    ftrL->addWidget(m_footer, 1);

    boxL->addWidget(ftr);

    outer->addWidget(box, 1);

    connect(m_items, &QListWidget::currentRowChanged, this, [this](int row) {
        if (row < 0) {
            m_detail->setCurrentIndex(0);
            m_footer->setText(QString::fromUtf8("Оберіть пункт праворуч для відкриття детальних налаштувань."));
            return;
        }
        const QString id = m_items->item(row)->data(Qt::UserRole).toString();
        showItem(id);
    });
}

QWidget* SettingsPage::buildPlaceholderWidget(const QString& text)
{
    auto* w = new QWidget(this);
    auto* l = new QVBoxLayout(w);
    l->setContentsMargins(20,20,20,20);
    auto* lbl = new QLabel(text, w);
    lbl->setWordWrap(true);
    lbl->setStyleSheet(QString("color:%1; font-size:11pt;").arg(cSecondary()));
    l->addWidget(lbl);
    l->addStretch(1);
    return w;
}

void SettingsPage::setCategory(Category c)
{
    m_category = c;

    // Update checked state in group
    const int idx = static_cast<int>(c);
    if (m_catGroup && idx >= 0 && idx < m_catGroup->buttons().size()) {
        if (auto* b = m_catGroup->button(idx)) b->setChecked(true);
    }

    m_hdrTitle->setText(categoryTitle(c));
    rebuildItems();
}

void SettingsPage::rebuildItems()
{
    m_items->clear();

    const auto items = m_itemsByCategory.value(m_category);
    for (const auto& it : items) {
        auto* li = new QListWidgetItem(it.title, m_items);
        li->setData(Qt::UserRole, it.id);
        m_items->addItem(li);
    }

    m_items->setCurrentRow(-1);
    m_detail->setCurrentIndex(0);
    m_footer->setText(QString::fromUtf8("Оберіть пункт праворуч для відкриття детальних налаштувань."));
}

void SettingsPage::showItem(const QString& id)
{
    if (!m_detailIndexById.contains(id)) {
        QWidget* w = buildDetailWidget(id);
        const int idx = m_detail->addWidget(w);
        m_detailIndexById[id] = idx;
    }
    m_detail->setCurrentIndex(m_detailIndexById.value(id, 0));

    // Footer hint
    const auto* cur = m_items->currentItem();
    m_footer->setText(cur ? QString::fromUtf8("Налаштування: %1").arg(cur->text())
                          : QString::fromUtf8("Налаштування"));
}

static bool getBool(const QString& k, bool defVal)
{
    return Database::getSetting(k, defVal).toBool();
}
static int getInt(const QString& k, int defVal)
{
    return Database::getSetting(k, defVal).toInt();
}
static double getDouble(const QString& k, double defVal)
{
    return Database::getSetting(k, defVal).toDouble();
}
static QString getStr(const QString& k, const QString& defVal = QString())
{
    return Database::getSetting(k, defVal).toString();
}
static void setVal(const QString& k, const QVariant& v)
{
    Database::setSetting(k, v);
}

QWidget* SettingsPage::buildDetailWidget(const QString& id)
{
    
    if (id == "staff.manage") {
        auto* w = new QWidget(this);
        auto* rootL = new QVBoxLayout(w);
        rootL->setContentsMargins(12,12,12,12);
        rootL->setSpacing(12);

        auto loadAdminSources = []() -> QJsonObject {
            const auto doc = QJsonDocument::fromJson(Database::getSetting(QStringLiteral("settings.staff.admin_salary_sources"), QStringLiteral("{}")).toString().toUtf8());
            return doc.isObject() ? doc.object() : QJsonObject();
        };
        auto saveAdminSources = [](const QJsonObject& obj) {
            Database::setSetting(QStringLiteral("settings.staff.admin_salary_sources"), QString::fromUtf8(QJsonDocument(obj).toJson(QJsonDocument::Compact)));
        };

        auto* header = new QHBoxLayout();
        auto* title = new QLabel(QString::fromUtf8("Майстри та адмін"), w);
        title->setStyleSheet(QString("font-size:16pt; font-weight:800; color:%1;").arg(cPrimary()));
        auto* btnCancel = new QPushButton(QString::fromUtf8("Скасувати"), w);
        auto* btnSave = new QPushButton(QString::fromUtf8("Зберегти"), w);
        btnCancel->setMinimumWidth(150);
        btnSave->setMinimumWidth(150);
        header->addWidget(title);
        header->addStretch(1);
        header->addWidget(btnCancel);
        header->addWidget(btnSave);
        rootL->addLayout(header);

        auto* mastersFrame = new QFrame(w);
        mastersFrame->setFrameShape(QFrame::StyledPanel);
        auto* mastersL = new QVBoxLayout(mastersFrame);
        mastersL->setContentsMargins(14,14,14,14);
        mastersL->setSpacing(10);

        auto* mastersLbl = new QLabel(QString::fromUtf8("Майстри"), mastersFrame);
        mastersLbl->setStyleSheet(QString("font-size:12pt; font-weight:700; color:%1;").arg(cPrimary()));
        mastersL->addWidget(mastersLbl, 0, Qt::AlignLeft);

        auto* mastersBar = new QHBoxLayout();
        auto* btnAddMaster = new QPushButton(QString::fromUtf8("+ Додати"), mastersFrame);
        auto* btnDeleteMaster = new QPushButton(QString::fromUtf8("Видалити"), mastersFrame);
        mastersBar->addWidget(btnAddMaster);
        mastersBar->addWidget(btnDeleteMaster);
        mastersBar->addStretch(1);
        mastersL->addLayout(mastersBar);

        auto* mastersTable = new QTableWidget(mastersFrame);
        mastersTable->setColumnCount(3);
        mastersTable->setHorizontalHeaderLabels({QStringLiteral("ID"), QString::fromUtf8("Ім'я"), QString::fromUtf8("% майстра")});
        mastersTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        mastersTable->setSelectionMode(QAbstractItemView::SingleSelection);
        mastersTable->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked | QAbstractItemView::EditKeyPressed);
        mastersTable->verticalHeader()->setVisible(false);
        mastersTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
        mastersTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
        mastersTable->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
        mastersTable->setMinimumHeight(260);
        mastersL->addWidget(mastersTable, 1);

        rootL->addWidget(mastersFrame, 1);

        auto* adminFrame = new QFrame(w);
        adminFrame->setFrameShape(QFrame::StyledPanel);
        auto* adminL = new QVBoxLayout(adminFrame);
        adminL->setContentsMargins(14,14,14,14);
        adminL->setSpacing(12);

        auto* adminLbl = new QLabel(QString::fromUtf8("Адмін"), adminFrame);
        adminLbl->setStyleSheet(QString("font-size:12pt; font-weight:700; color:%1;").arg(cPrimary()));
        adminL->addWidget(adminLbl, 0, Qt::AlignLeft);

        auto* form = new QFormLayout();
        form->setLabelAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        form->setFormAlignment(Qt::AlignLeft | Qt::AlignTop);
        form->setHorizontalSpacing(18);
        form->setVerticalSpacing(16);

        auto* adminName = new QLineEdit(adminFrame);
        auto* adminPercent = new QDoubleSpinBox(adminFrame);
        adminPercent->setRange(0.0, 100.0);
        adminPercent->setDecimals(2);
        adminPercent->setSuffix(QString::fromUtf8("%"));
        adminPercent->setSingleStep(1.0);

        auto* adminSource = new QComboBox(adminFrame);
        auto* adminSourceView = new QListView(adminSource);
        adminSource->setView(adminSourceView);
        adminSourceView->setStyleSheet(QStringLiteral(
            "QListView{background:#ffffff;color:#111111;border:1px solid #c7ccd4;outline:none;}"
            "QListView::item{background:#ffffff;color:#111111;padding:8px 10px;min-height:24px;}"
            "QListView::item:selected{background:#dfe6ef;color:#111111;}"));
        QPalette adminSourcePalette = adminSource->palette();
        adminSourcePalette.setColor(QPalette::Base, QColor(QStringLiteral("#ffffff")));
        adminSourcePalette.setColor(QPalette::Text, QColor(QStringLiteral("#111111")));
        adminSourcePalette.setColor(QPalette::HighlightedText, QColor(QStringLiteral("#111111")));
        adminSourcePalette.setColor(QPalette::Highlight, QColor(QStringLiteral("#dfe6ef")));
        adminSource->setPalette(adminSourcePalette);
        adminSourceView->setPalette(adminSourcePalette);
        adminSource->addItem(QString::fromUtf8("Доданий % (маржа)"), QStringLiteral("margin"));
        adminSource->addItem(QString::fromUtf8("Повна ціна для клієнта"), QStringLiteral("client_total"));
        adminSource->addItem(QString::fromUtf8("Ціна закупки"), QStringLiteral("purchase_total"));

        form->addRow(QString::fromUtf8("Ім'я:"), adminName);
        form->addRow(QString::fromUtf8("Відсоток адміна:"), adminPercent);
        form->addRow(QString::fromUtf8("База для зарплати адміна:"), adminSource);
        adminL->addLayout(form);

        auto* adminHint = new QLabel(
            QString::fromUtf8(u8"При виборі джерела зарплати база для розрахунку адміна автоматично використовується у вкладці «Звіти» та в PDF зарплати."),
            adminFrame);
        adminHint->setWordWrap(true);
        adminHint->setStyleSheet(QString("color:%1;").arg(cSecondary()));
        adminL->addWidget(adminHint);

        auto* adminButtons = new QHBoxLayout();
        auto* btnDeleteAdmin = new QPushButton(QString::fromUtf8("Видалити адміна"), adminFrame);
        auto* btnNewAdmin = new QPushButton(QString::fromUtf8("Новий адмін"), adminFrame);
        adminButtons->addWidget(btnDeleteAdmin);
        adminButtons->addWidget(btnNewAdmin);
        adminButtons->addStretch(1);
        adminL->addLayout(adminButtons);

        rootL->addWidget(adminFrame);

        auto currentAdminId = std::make_shared<QString>();

        auto reloadUi = [this, mastersTable, adminName, adminPercent, adminSource, currentAdminId, loadAdminSources]() {
            mastersTable->setRowCount(0);
            const auto masters = Database::masters(false);
            const auto payroll = Database::payrollPercents();
            const QJsonObject adminSources = loadAdminSources();

            MasterRow firstAdmin;
            int visualId = 1;
            for (const auto& row : masters) {
                if (row.role == QStringLiteral("master")) {
                    const int r = mastersTable->rowCount();
                    mastersTable->insertRow(r);

                    auto* idIt = new QTableWidgetItem(QString::number(visualId++));
                    idIt->setData(Qt::UserRole, row.id);
                    idIt->setFlags(idIt->flags() & ~Qt::ItemIsEditable);
                    mastersTable->setItem(r, 0, idIt);

                    auto* nameIt = new QTableWidgetItem(row.name);
                    nameIt->setData(Qt::UserRole, row.id);
                    mastersTable->setItem(r, 1, nameIt);

                    auto* pctIt = new QTableWidgetItem(QString::number(payroll.value(row.id, 0.0), 'f', 2));
                    mastersTable->setItem(r, 2, pctIt);
                } else if (row.role == QStringLiteral("admin") && firstAdmin.id.isEmpty()) {
                    firstAdmin = row;
                }
            }

            *currentAdminId = firstAdmin.id;
            adminName->setText(firstAdmin.name);
            adminPercent->setValue(firstAdmin.id.isEmpty() ? 0.0 : firstAdmin.adminPercent);
            const QString src = adminSources.value(firstAdmin.id).toString(QStringLiteral("margin"));
            const int idx = adminSource->findData(src);
            adminSource->setCurrentIndex(idx >= 0 ? idx : 0);
        };

        auto saveUi = [this, mastersTable, adminName, adminPercent, adminSource, currentAdminId, saveAdminSources, loadAdminSources]() {
            QSet<QString> seenMasterIds;
            for (int r = 0; r < mastersTable->rowCount(); ++r) {
                const QString id = mastersTable->item(r, 0) ? mastersTable->item(r, 0)->data(Qt::UserRole).toString() : QString();
                const QString name = mastersTable->item(r, 1) ? mastersTable->item(r, 1)->text().trimmed() : QString();
                bool okPct = false;
                QString pctText = mastersTable->item(r, 2) ? mastersTable->item(r, 2)->text().trimmed() : QString();
                pctText.replace(',', '.');
                const double pct = pctText.toDouble(&okPct);
                if (name.isEmpty()) continue;

                MasterRow m;
                m.id = id.isEmpty() ? QUuid::createUuid().toString(QUuid::WithoutBraces) : id;
                m.name = name;
                m.role = QStringLiteral("master");
                m.active = true;
                m.adminPercent = 0.0;
                if (!Database::upsertMaster(m)) {
                    QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не вдалося зберегти майстра '%1'.").arg(name));
                    return;
                }
                Database::setPayrollPercent(m.id, okPct ? pct : 0.0);
                seenMasterIds.insert(m.id);
            }

            for (const auto& row : Database::masters(false)) {
                if (row.role == QStringLiteral("master") && !seenMasterIds.contains(row.id)) {
                    Database::deleteMasterIfUnusedOrArchive(row.id);
                    Database::removePayrollPercent(row.id);
                }
            }

            QJsonObject adminSources = loadAdminSources();
            const QString adminNameText = adminName->text().trimmed();
            if (adminNameText.isEmpty()) {
                if (!currentAdminId->isEmpty()) {
                    Database::deleteMasterIfUnusedOrArchive(*currentAdminId);
                    adminSources.remove(*currentAdminId);
                    *currentAdminId = QString();
                }
            } else {
                MasterRow admin;
                admin.id = currentAdminId->isEmpty() ? QUuid::createUuid().toString(QUuid::WithoutBraces) : *currentAdminId;
                admin.name = adminNameText;
                admin.role = QStringLiteral("admin");
                admin.active = true;
                admin.adminPercent = adminPercent->value();
                if (!Database::upsertMaster(admin)) {
                    QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не вдалося зберегти адміністратора."));
                    return;
                }
                *currentAdminId = admin.id;
                adminSources.insert(admin.id, adminSource->currentData().toString());
            }
            saveAdminSources(adminSources);
            emit requestRefreshAll();
            QMessageBox::information(this, QString::fromUtf8("Готово"), QString::fromUtf8("Майстри та адміністратор збережені."));
        };

        QObject::connect(btnAddMaster, &QPushButton::clicked, w, [mastersTable]() {
            const int r = mastersTable->rowCount();
            mastersTable->insertRow(r);
            auto* idIt = new QTableWidgetItem(QString::number(r + 1));
            idIt->setData(Qt::UserRole, QString());
            idIt->setFlags(idIt->flags() & ~Qt::ItemIsEditable);
            mastersTable->setItem(r, 0, idIt);
            mastersTable->setItem(r, 1, new QTableWidgetItem(QString()));
            mastersTable->setItem(r, 2, new QTableWidgetItem(QStringLiteral("0")));
            mastersTable->setCurrentCell(r, 1);
            mastersTable->editItem(mastersTable->item(r, 1));
        });
        QObject::connect(btnDeleteMaster, &QPushButton::clicked, w, [mastersTable]() {
            const auto rows = mastersTable->selectionModel() ? mastersTable->selectionModel()->selectedRows() : QModelIndexList();
            if (rows.isEmpty()) return;
            mastersTable->removeRow(rows.first().row());
            for (int r = 0; r < mastersTable->rowCount(); ++r) {
                if (mastersTable->item(r,0)) mastersTable->item(r,0)->setText(QString::number(r + 1));
            }
        });
        QObject::connect(btnDeleteAdmin, &QPushButton::clicked, w, [adminName, adminPercent, adminSource, currentAdminId]() {
            adminName->clear();
            adminPercent->setValue(0.0);
            adminSource->setCurrentIndex(0);
            *currentAdminId = QString();
        });
        QObject::connect(btnNewAdmin, &QPushButton::clicked, w, [adminName, adminPercent, adminSource, currentAdminId]() {
            adminName->clear();
            adminPercent->setValue(0.0);
            adminSource->setCurrentIndex(0);
            *currentAdminId = QString();
            adminName->setFocus();
        });
        QObject::connect(btnCancel, &QPushButton::clicked, w, reloadUi);
        QObject::connect(btnSave, &QPushButton::clicked, w, saveUi);

        reloadUi();
        return w;
    }

    // --- GENERAL / Sounds ---
    // --- GENERAL / Sounds ---
    if (id == "general.sounds") {
        auto* w = new QWidget(this);
        auto* l = new QVBoxLayout(w);
        l->setContentsMargins(18,18,18,18);
        l->setSpacing(12);

        auto* title = new QLabel(QString::fromUtf8("Звуки та голос"), w);
        title->setStyleSheet(QString("font-size:14pt; font-weight:800; color:%1;").arg(cPrimary()));
        l->addWidget(title);

        auto* cb = new QCheckBox(QString::fromUtf8("Увімкнути звуки кнопок"), w);
        cb->setChecked(getBool("settings.sounds.enabled", true));
        l->addWidget(cb);

        auto* row = new QHBoxLayout();
        auto* lbl = new QLabel(QString::fromUtf8("Гучність:"), w);
        auto* sld = new QSlider(Qt::Horizontal, w);
        sld->setRange(0, 100);
        sld->setValue(getInt("settings.sounds.volume", 60));
        sld->setMaximumWidth(320);

        auto* val = new QLabel(QString::number(sld->value()) + "%", w);
        val->setMinimumWidth(50);

        row->addWidget(lbl);
        row->addWidget(sld);
        row->addWidget(val);
        row->addStretch(1);
        l->addLayout(row);

        auto* test = new QPushButton(QString::fromUtf8("Тест"), w);
        test->setFixedWidth(120);
        l->addWidget(test, 0, Qt::AlignLeft);

        auto* info = new QLabel(QString::fromUtf8("Примітка: повна система звуків буде перенесена окремим модулем (wav/ogg + мікшер)."), w);
        info->setWordWrap(true);
        info->setStyleSheet(QString("color:%1;").arg(cSecondary()));
        l->addWidget(info);

        l->addStretch(1);

        connect(cb, &QCheckBox::toggled, this, [](bool on) {
            setVal("settings.sounds.enabled", on);
        });
        connect(sld, &QSlider::valueChanged, this, [val](int v) {
            val->setText(QString::number(v) + "%");
            setVal("settings.sounds.volume", v);
        });
        connect(test, &QPushButton::clicked, this, [cb]() {
            if (!cb->isChecked()) return;
            QApplication::beep();
        });

        return w;
    }

    // --- GENERAL / Animations ---
    if (id == "general.animations") {
        auto* w = new QWidget(this);
        auto* root = new QVBoxLayout(w);
        root->setContentsMargins(16,16,16,16);
        root->setSpacing(12);

        auto mkActionBtn = [w](const QString& text) {
            auto* b = new QPushButton(text, w);
            b->setMinimumHeight(42);
            b->setMinimumWidth(170);
            b->setCursor(Qt::PointingHandCursor);
            b->setStyleSheet(QString::fromUtf8(
                "QPushButton{background:#f5f7fb;border:1px solid #cfd5dd;border-radius:14px;"
                "padding:10px 20px;color:#1e2740;font-weight:700;}"
                "QPushButton:hover{background:#ffffff;}"
                "QPushButton:pressed{background:#e9edf3;}"));
            return b;
        };

        auto* top = new QHBoxLayout();
        top->setSpacing(12);
        auto* btnBack = mkActionBtn(QString::fromUtf8("← Назад"));
        auto* title = new QLabel(QString::fromUtf8("Ефекти / Анімації"), w);
        title->setStyleSheet(QString("font-size:16pt; font-weight:800; color:%1;").arg(cPrimary()));
        auto* btnCancel = mkActionBtn(QString::fromUtf8("Скасувати"));
        auto* btnSave = mkActionBtn(QString::fromUtf8("Зберегти"));
        top->addWidget(btnBack);
        top->addWidget(title, 1);
        top->addWidget(btnCancel);
        top->addWidget(btnSave);
        root->addLayout(top);

        auto* stage = new QFrame(w);
        stage->setStyleSheet(QString::fromUtf8(
            "QFrame{background:rgba(255,255,255,0.10);border:1px solid rgba(255,255,255,0.18);border-radius:18px;}"));
        auto* stageL = new QVBoxLayout(stage);
        stageL->setContentsMargins(14,14,14,14);
        stageL->setSpacing(12);

        auto* chip = new QLabel(QString::fromUtf8("Ефекти / Анімації"), stage);
        chip->setStyleSheet(QString::fromUtf8(
            "background:#f8f9fc;border:1px solid #bfc6cf;border-radius:12px;padding:4px 14px;color:#27314b;font-weight:600;"));
        stageL->addWidget(chip, 0, Qt::AlignLeft);

        auto* panel = new QFrame(stage);
        panel->setStyleSheet(QString::fromUtf8(
            "QFrame{background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.22);border-radius:22px;}"
            "QLabel{color:%1;}"
            "QComboBox{background:#f7f8fb;border:1px solid #c7ccd4;border-radius:18px;padding:10px 16px;"
            "color:#1f2434;font-size:11pt;min-height:32px;}"
            "QSlider::groove:horizontal{height:6px;background:rgba(255,255,255,0.35);border-radius:3px;}"
            "QSlider::sub-page:horizontal{background:#49b8f2;border-radius:3px;}"
            "QSlider::handle:horizontal{background:#384255;border:2px solid #49b8f2;width:16px;height:16px;margin:-6px 0;border-radius:8px;}").arg(cPrimary()));
        auto* panelL = new QVBoxLayout(panel);
        panelL->setContentsMargins(22,20,22,20);
        panelL->setSpacing(12);

        auto* row1 = new QHBoxLayout();
        auto* levelLbl = new QLabel(QString::fromUtf8("Рівень ефектності:"), panel);
        levelLbl->setMinimumWidth(170);
        auto* level = new QComboBox(panel);
        level->addItem(QString::fromUtf8("Мінімальний"), "minimal");
        level->addItem(QString::fromUtf8("Стандартний"), "normal");
        level->addItem(QString::fromUtf8("Ultra"), "ultra");
        {
            const QString cur = getStr("settings.ui.effects_level", QStringLiteral("ultra"));
            const int idx = level->findData(cur);
            if (idx >= 0) level->setCurrentIndex(idx);
        }
        row1->addWidget(levelLbl);
        row1->addWidget(level, 1);
        panelL->addLayout(row1);

        auto* row2 = new QHBoxLayout();
        auto* overlayLbl = new QLabel(QString::fromUtf8("Затемнення фону (overlay):"), panel);
        overlayLbl->setMinimumWidth(230);
        auto* overlay = new QSlider(Qt::Horizontal, panel);
        overlay->setRange(0, 40);
        overlay->setValue(getInt("settings.ui.overlay_percent", 21));
        auto* overlayVal = new QLabel(QString::number(overlay->value()) + "%", panel);
        overlayVal->setMinimumWidth(48);
        row2->addWidget(overlayLbl);
        row2->addWidget(overlay, 1);
        row2->addWidget(overlayVal);
        panelL->addLayout(row2);

        auto* hint = new QLabel(QString::fromUtf8("Порада: на світлій темі overlay краще тримати 0–15%."), panel);
        hint->setWordWrap(true);
        hint->setStyleSheet(QString("color:%1; font-size:10.5pt;").arg(cSecondary()));
        panelL->addWidget(hint);

        stageL->addWidget(panel);
        root->addWidget(stage);
        root->addStretch(1);

        auto saveState = [level, overlay]() {
            setVal("settings.ui.effects_level", level->currentData().toString());
            setVal("settings.ui.overlay_percent", overlay->value());
        };
        auto loadState = [level, overlay, overlayVal]() {
            const QString cur = getStr("settings.ui.effects_level", QStringLiteral("ultra"));
            const int idx = level->findData(cur);
            if (idx >= 0) level->setCurrentIndex(idx);
            overlay->setValue(getInt("settings.ui.overlay_percent", 21));
            overlayVal->setText(QString::number(overlay->value()) + "%");
        };

        connect(btnBack, &QPushButton::clicked, this, [this]() { m_items->setCurrentRow(-1); });
        connect(btnCancel, &QPushButton::clicked, this, loadState);
        connect(btnSave, &QPushButton::clicked, this, [this, saveState]() {
            saveState();
            emit requestRefreshAll();
        });
        connect(overlay, &QSlider::valueChanged, this, [overlayVal](int v) {
            overlayVal->setText(QString::number(v) + "%");
        });

        return w;
    }

    // --- GENERAL / Branding ---
    if (id == "general.branding") {
        auto* w = new QWidget(this);
        auto* l = new QVBoxLayout(w);
        l->setContentsMargins(18,18,18,18);
        l->setSpacing(12);

        auto* title = new QLabel(QString::fromUtf8("Брендинг СТО"), w);
        title->setStyleSheet(QString("font-size:14pt; font-weight:800; color:%1;").arg(cPrimary()));
        l->addWidget(title);

        auto* form = new QFormLayout();
        form->setLabelAlignment(Qt::AlignLeft);
        form->setFormAlignment(Qt::AlignTop);
        form->setHorizontalSpacing(12);
        form->setVerticalSpacing(10);

        auto* name = new QLineEdit(getStr("settings.branding.name", QString::fromUtf8("CarServicePointG")), w);
        auto* phone = new QLineEdit(getStr("settings.branding.phone", QString()), w);

        auto* logoRow = new QWidget(w);
        auto* logoL = new QHBoxLayout(logoRow);
        logoL->setContentsMargins(0,0,0,0);

        auto* logoPath = new QLineEdit(getStr("settings.branding.logo", QString()), logoRow);
        auto* browse = new QToolButton(logoRow);
        browse->setText("...");

        logoL->addWidget(logoPath, 1);
        logoL->addWidget(browse);

        form->addRow(QString::fromUtf8("Назва СТО:"), name);
        form->addRow(QString::fromUtf8("Телефон:"), phone);
        form->addRow(QString::fromUtf8("Логотип (PNG):"), logoRow);

        l->addLayout(form);

        auto* preview = new QLabel(w);
        preview->setFixedHeight(120);
        preview->setStyleSheet(QString("border:1px solid %1; background:%2;").arg(cPanelBorder()).arg(isDarkUi() ? "#0f1113" : "#fafafa"));
        preview->setAlignment(Qt::AlignCenter);
        l->addWidget(preview);

        auto updatePreview = [preview, logoPath]() {
            const QString p = logoPath->text().trimmed();
            if (p.isEmpty() || !QFileInfo::exists(p)) {
                preview->setText(QString::fromUtf8("Немає логотипу"));
                preview->setPixmap(QPixmap());
                return;
            }
            QPixmap pm(p);
            if (pm.isNull()) {
                preview->setText(QString::fromUtf8("Не вдалося завантажити"));
                preview->setPixmap(QPixmap());
                return;
            }
            preview->setPixmap(pm.scaled(preview->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
        };

        updatePreview();

        l->addStretch(1);

        connect(name, &QLineEdit::editingFinished, this, [name]() {
            setVal("settings.branding.name", name->text().trimmed());
        });
        connect(phone, &QLineEdit::editingFinished, this, [phone]() {
            setVal("settings.branding.phone", phone->text().trimmed());
        });
        connect(logoPath, &QLineEdit::editingFinished, this, [logoPath, updatePreview]() {
            setVal("settings.branding.logo", logoPath->text().trimmed());
            updatePreview();
        });
        connect(browse, &QToolButton::clicked, this, [logoPath, updatePreview, this]() {
    const QString f = QFileDialog::getOpenFileName(this,
        QString::fromUtf8("Вибір логотипу"),
        QString(),
        QString::fromUtf8("Зображення (*.png *.jpg *.jpeg)"));
    if (f.isEmpty()) return;

    // Copy into app data dir so the logo is always available for PDFs.
    const QString ext = QFileInfo(f).suffix().isEmpty() ? QStringLiteral("png") : QFileInfo(f).suffix();
    const QString dstDir = QDir(App::dataDir()).filePath("branding");
    QDir().mkpath(dstDir);
    const QString dst = QDir(dstDir).filePath(QStringLiteral("logo.") + ext);

    // Best-effort overwrite
    if (QFileInfo::exists(dst)) QFile::remove(dst);
    QFile::copy(f, dst);

    logoPath->setText(dst);
    setVal("settings.branding.logo", dst);
    updatePreview();
});

        return w;
    }

    // --- GENERAL / Updates ---
    if (id == "general.updates") {
        auto* w = new QWidget(this);
        auto* l = new QVBoxLayout(w);
        l->setContentsMargins(18,18,18,18);
        l->setSpacing(12);

        auto* title = new QLabel(QString::fromUtf8("Оновлення"), w);
        title->setStyleSheet(QString("font-size:14pt; font-weight:800; color:%1;").arg(cPrimary()));
        l->addWidget(title);

        auto* cb = new QCheckBox(QString::fromUtf8("Перевіряти оновлення при запуску"), w);
        cb->setChecked(getBool("settings.updates.auto", true));
        l->addWidget(cb);

        auto* row = new QHBoxLayout();
        auto* btn = new QPushButton(QString::fromUtf8("Перевірити зараз"), w);
        btn->setFixedWidth(180);
        row->addWidget(btn);
        row->addStretch(1);
        l->addLayout(row);

        auto* info = new QLabel(QString::fromUtf8("Модуль автооновлень буде перенесено наступним кроком (GitHub Releases / Inno)."), w);
        info->setWordWrap(true);
        info->setStyleSheet(QString("color:%1;").arg(cSecondary()));
        l->addWidget(info);

        l->addStretch(1);

        connect(cb, &QCheckBox::toggled, this, [](bool on) {
            setVal("settings.updates.auto", on);
        });
        connect(btn, &QPushButton::clicked, this, [this]() {
            QMessageBox::information(this,
                QString::fromUtf8("Оновлення"),
                QString::fromUtf8("Перевірка оновлень буде додана у наступних версіях.\nЗараз це заглушка інтерфейсу."));
        });

        return w;
    }

    // --- UI / Font ---
    if (id == "ui.font") {
        auto* w = new QWidget(this);
        auto* root = new QVBoxLayout(w);
        root->setContentsMargins(16,16,16,16);
        root->setSpacing(12);

        auto mkActionBtn = [w](const QString& text) {
            auto* b = new QPushButton(text, w);
            b->setMinimumHeight(42);
            b->setMinimumWidth(170);
            b->setCursor(Qt::PointingHandCursor);
            b->setStyleSheet(QString::fromUtf8(
                "QPushButton{background:#f5f7fb;border:1px solid #cfd5dd;border-radius:14px;"
                "padding:10px 20px;color:#1e2740;font-weight:700;}"
                "QPushButton:hover{background:#ffffff;}"
                "QPushButton:pressed{background:#e9edf3;}"));
            return b;
        };

        auto* top = new QHBoxLayout();
        top->setSpacing(12);
        auto* btnBack = mkActionBtn(QString::fromUtf8("← Назад"));
        auto* title = new QLabel(QString::fromUtf8("Шрифт"), w);
        title->setStyleSheet(QString("font-size:16pt; font-weight:800; color:%1;").arg(cPrimary()));
        auto* btnCancel = mkActionBtn(QString::fromUtf8("Скасувати"));
        auto* btnSave = mkActionBtn(QString::fromUtf8("Зберегти"));
        top->addWidget(btnBack);
        top->addWidget(title, 1);
        top->addWidget(btnCancel);
        top->addWidget(btnSave);
        root->addLayout(top);

        auto* stage = new QFrame(w);
        stage->setStyleSheet(QString::fromUtf8(
            "QFrame{background:rgba(255,255,255,0.10);border:1px solid rgba(255,255,255,0.18);border-radius:18px;}"));
        auto* stageL = new QVBoxLayout(stage);
        stageL->setContentsMargins(14,14,14,14);
        stageL->setSpacing(12);

        auto* chip = new QLabel(QString::fromUtf8("Шрифт інтерфейсу"), stage);
        chip->setStyleSheet(QString::fromUtf8(
            "background:#f8f9fc;border:1px solid #bfc6cf;border-radius:12px;padding:4px 14px;color:#27314b;font-weight:600;"));
        stageL->addWidget(chip, 0, Qt::AlignLeft);

        auto* panel = new QFrame(stage);
        panel->setStyleSheet(QString::fromUtf8(
            "QFrame{background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.22);border-radius:22px;}"
            "QLabel{color:%1;}"
            "QLineEdit,QSpinBox,QFontComboBox{background:#f7f8fb;border:1px solid #c7ccd4;border-radius:16px;padding:8px 12px;color:#1f2434;font-size:11pt;min-height:32px;}").arg(cPrimary()));
        auto* panelL = new QVBoxLayout(panel);
        panelL->setContentsMargins(22,20,22,20);
        panelL->setSpacing(14);

        auto* form1 = new QHBoxLayout();
        auto* familyLbl = new QLabel(QString::fromUtf8("Шрифт:"), panel);
        familyLbl->setMinimumWidth(90);
        auto* family = new QFontComboBox(panel);
        family->setCurrentFont(QFont(getStr("settings.ui.font_family", QStringLiteral("Times New Roman"))));
        form1->addWidget(familyLbl);
        form1->addWidget(family, 1);
        panelL->addLayout(form1);

        auto* form2 = new QHBoxLayout();
        auto* sizeLbl = new QLabel(QString::fromUtf8("Розмір:"), panel);
        sizeLbl->setMinimumWidth(90);
        auto* size = new QSpinBox(panel);
        size->setRange(8, 28);
        size->setValue(getInt("settings.ui.font_size", 13));
        size->setFixedWidth(86);

        auto* colorLbl = new QLabel(QString::fromUtf8("Колір:"), panel);
        colorLbl->setMinimumWidth(70);
        auto* pickColor = mkActionBtn(QString::fromUtf8("Вибрати…"));
        pickColor->setMinimumWidth(150);
        pickColor->setMaximumWidth(150);
        auto* sample = new QLineEdit(panel);
        sample->setReadOnly(true);
        sample->setText(QString::fromUtf8("Приклад тексту / Sample"));
        form2->addWidget(sizeLbl);
        form2->addWidget(size);
        form2->addSpacing(16);
        form2->addWidget(colorLbl);
        form2->addWidget(pickColor);
        form2->addSpacing(8);
        form2->addWidget(sample, 1);
        panelL->addLayout(form2);

        auto* form3 = new QHBoxLayout();
        auto* tableLbl = new QLabel(QString::fromUtf8("Таблиця: текст"), panel);
        tableLbl->setMinimumWidth(140);
        auto* tableSize = new QSpinBox(panel);
        tableSize->setRange(8, 24);
        tableSize->setValue(getInt("settings.ui.table_font_size", 13));
        tableSize->setFixedWidth(86);

        auto* hdrLbl = new QLabel(QString::fromUtf8("Заголовки"), panel);
        hdrLbl->setMinimumWidth(110);
        auto* hdrSize = new QSpinBox(panel);
        hdrSize->setRange(8, 28);
        hdrSize->setValue(getInt("settings.ui.heading_font_size", 13));
        hdrSize->setFixedWidth(86);

        form3->addWidget(tableLbl);
        form3->addWidget(tableSize);
        form3->addSpacing(20);
        form3->addWidget(hdrLbl);
        form3->addWidget(hdrSize);
        form3->addStretch(1);
        panelL->addLayout(form3);

        auto* hint = new QLabel(QString::fromUtf8("Після збереження стиль застосунку оновиться одразу."), panel);
        hint->setStyleSheet(QString("color:%1; font-size:10.5pt;").arg(cSecondary()));
        panelL->addWidget(hint);

        stageL->addWidget(panel);
        root->addWidget(stage);
        root->addStretch(1);

        auto chosen = std::make_shared<QColor>(QColor(getStr("settings.ui.font_color", QStringLiteral("#1f2434"))));
        if (!chosen->isValid()) *chosen = QColor("#1f2434");

        auto applyPreview = [sample, family, size]() {
            QFont f = family->currentFont();
            f.setPointSize(size->value());
            sample->setFont(f);
        };
        auto updateColorButton = [pickColor, sample](const QColor& c) {
            const QString css = QString("QPushButton{background:%1;border:1px solid #cfd5dd;border-radius:14px;padding:10px 20px;color:%2;font-weight:700;}")
                                    .arg(c.lighter(180).name(), c.name());
            pickColor->setStyleSheet(css);
            sample->setStyleSheet(QString("color:%1;").arg(c.name()));
        };
        applyPreview();
        updateColorButton(*chosen);

        auto saveState = [family, size, tableSize, hdrSize, chosen]() {
            setVal("settings.ui.font_family", family->currentFont().family());
            setVal("settings.ui.font_size", size->value());
            setVal("settings.ui.table_font_size", tableSize->value());
            setVal("settings.ui.heading_font_size", hdrSize->value());
            setVal("settings.ui.font_color", chosen->name());
        };
        auto loadState = [family, size, tableSize, hdrSize, applyPreview, updateColorButton, chosen]() {
            family->setCurrentFont(QFont(getStr("settings.ui.font_family", QStringLiteral("Times New Roman"))));
            size->setValue(getInt("settings.ui.font_size", 13));
            tableSize->setValue(getInt("settings.ui.table_font_size", 13));
            hdrSize->setValue(getInt("settings.ui.heading_font_size", 13));
            *chosen = QColor(getStr("settings.ui.font_color", QStringLiteral("#1f2434")));
            if (!chosen->isValid()) *chosen = QColor("#1f2434");
            applyPreview();
            updateColorButton(*chosen);
        };

        connect(btnBack, &QPushButton::clicked, this, [this]() { m_items->setCurrentRow(-1); });
        connect(btnCancel, &QPushButton::clicked, this, loadState);
        connect(btnSave, &QPushButton::clicked, this, [this, saveState]() {
            saveState();
            emit requestRefreshAll();
        });
        connect(family, &QFontComboBox::currentFontChanged, this, [applyPreview](const QFont&) { applyPreview(); });
        connect(size, qOverload<int>(&QSpinBox::valueChanged), this, [applyPreview](int) { applyPreview(); });
        connect(pickColor, &QPushButton::clicked, this, [this, chosen, updateColorButton]() {
            const QColor c = QColorDialog::getColor(*chosen, this, QString::fromUtf8("Виберіть колір шрифту"));
            if (!c.isValid()) return;
            *chosen = c;
            updateColorButton(*chosen);
        });

        return w;
    }

    // --- UI / Theme ---
    if (id == "ui.theme") {
        auto* w = new QWidget(this);
        auto* l = new QVBoxLayout(w);
        l->setContentsMargins(18,18,18,18);
        l->setSpacing(12);

        auto* title = new QLabel(QString::fromUtf8("Тема інтерфейсу"), w);
        title->setStyleSheet(QString("font-size:14pt; font-weight:800; color:%1;").arg(cPrimary()));
        l->addWidget(title);

        auto* row = new QHBoxLayout();
        row->addWidget(new QLabel(QString::fromUtf8("Тема:"), w));

        auto* cb = new QComboBox(w);
        cb->addItem(QString::fromUtf8("Графіт (темна)"), "graphite");
        cb->addItem(QString::fromUtf8("Світла"), "light");

        const QString cur = ThemeManager::currentTheme();
        const int idx = cb->findData(cur);
        if (idx >= 0) cb->setCurrentIndex(idx);

        row->addWidget(cb);
        row->addStretch(1);
        l->addLayout(row);

        auto* hint = new QLabel(QString::fromUtf8("Після зміни теми інтерфейс застосовується одразу."), w);
        hint->setStyleSheet(QString("color:%1;").arg(cSecondary()));
        l->addWidget(hint);

        l->addStretch(1);

        connect(cb, &QComboBox::currentIndexChanged, this, [cb, this](int) {
            const QString theme = cb->currentData().toString();
            ThemeManager::setTheme(theme);
            emit requestRefreshAll();
        });

        return w;
    }

    // --- UI / Tables ---
    if (id == "ui.tables") {
        auto* w = new QWidget(this);
        auto* l = new QVBoxLayout(w);
        l->setContentsMargins(18,18,18,18);
        l->setSpacing(12);

        auto* title = new QLabel(QString::fromUtf8("Таблиці та відображення"), w);
        title->setStyleSheet(QString("font-size:14pt; font-weight:800; color:%1;").arg(cPrimary()));
        l->addWidget(title);

        auto* cb = new QCheckBox(QString::fromUtf8("Робити таблиці світлими (білий фон)"), w);
        cb->setChecked(getBool("settings.ui.white_tables", true));
        l->addWidget(cb);

        auto* info = new QLabel(QString::fromUtf8("Це налаштування застосовується до всіх таблиць (QTableView/QTableWidget) одразу."), w);
        info->setWordWrap(true);
        info->setStyleSheet(QString("color:%1;").arg(cSecondary()));
        l->addWidget(info);

        l->addStretch(1);

        connect(cb, &QCheckBox::toggled, this, [this](bool on) {
            setVal("settings.ui.white_tables", on);
            ThemeManager::setTheme(ThemeManager::currentTheme());
            emit requestRefreshAll();
        });

        return w;
    }

    // --- Integrations / API keys ---
    if (id == "int.apikeys") {
        auto* w = new QWidget(this);
        auto* l = new QVBoxLayout(w);
        l->setContentsMargins(18,18,18,18);
        l->setSpacing(12);

        auto* title = new QLabel(QString::fromUtf8("API ключі"), w);
        title->setStyleSheet(QString("font-size:14pt; font-weight:800; color:%1;").arg(cPrimary()));
        l->addWidget(title);

        auto* info = new QLabel(QString::fromUtf8("Тут можна додати ключі сервісів для автоматичного підбору даних авто за держномером / VIN. Зараз підключено OpenDataBot: номер авто → VIN → базові дані авто."), w);
        info->setWordWrap(true);
        info->setStyleSheet(QString("color:%1;").arg(cSecondary()));
        l->addWidget(info);

        auto* demoMode = new QCheckBox(QString::fromUtf8("Demo режим (без ключів, для тесту UI)"), w);
        demoMode->setChecked(getBool("settings.int.odb.demo_mode", false));
        l->addWidget(demoMode);

        auto* form = new QFormLayout();
        form->setHorizontalSpacing(12);
        form->setVerticalSpacing(10);

        auto* baseUrl = new QLineEdit(getStr("settings.int.odb.base_url", QStringLiteral("https://opendatabot.com/api/v4")), w);
        auto* apiKey = new QLineEdit(getStr("settings.int.odb.api_key", QString()), w);
        auto* apiKeyParam = new QLineEdit(getStr("settings.int.odb.api_key_param", QStringLiteral("apiKey")), w);
        auto* headerName = new QLineEdit(getStr("settings.int.odb.header_name", QString()), w);
        auto* plateEndpoint = new QLineEdit(getStr("settings.int.odb.plate_endpoint", QStringLiteral("transport")), w);
        auto* plateParam = new QLineEdit(getStr("settings.int.odb.plate_param", QStringLiteral("number")), w);
        auto* vinEndpoint = new QLineEdit(getStr("settings.int.odb.vin_endpoint", QStringLiteral("transport")), w);
        auto* vinParam = new QLineEdit(getStr("settings.int.odb.vin_param", QStringLiteral("vin")), w);
        auto* testPlate = new QLineEdit(getStr("settings.int.odb.test_plate", QStringLiteral("AE6190XC")), w);

        apiKey->setEchoMode(QLineEdit::PasswordEchoOnEdit);
        baseUrl->setPlaceholderText(QString::fromUtf8("https://opendatabot.com/api/v4"));
        plateEndpoint->setPlaceholderText(QString::fromUtf8("transport"));
        plateParam->setPlaceholderText(QString::fromUtf8("number"));
        apiKeyParam->setPlaceholderText(QString::fromUtf8("apiKey"));
        headerName->setPlaceholderText(QString::fromUtf8("X-Api-Key або порожньо"));
        vinEndpoint->setPlaceholderText(QString::fromUtf8("transport"));
        vinParam->setPlaceholderText(QString::fromUtf8("vin"));

        form->addRow(QString::fromUtf8("Base URL:"), baseUrl);
        form->addRow(QString::fromUtf8("API key:"), apiKey);
        form->addRow(QString::fromUtf8("API key param (query):"), apiKeyParam);
        form->addRow(QString::fromUtf8("Header name:"), headerName);
        form->addRow(QString::fromUtf8("Plate endpoint:"), plateEndpoint);
        form->addRow(QString::fromUtf8("Plate param:"), plateParam);
        form->addRow(QString::fromUtf8("VIN endpoint:"), vinEndpoint);
        form->addRow(QString::fromUtf8("VIN param:"), vinParam);
        form->addRow(QString::fromUtf8("Тестовий номер:"), testPlate);
        l->addLayout(form);

        auto* example = new QLabel(w);
        example->setWordWrap(true);
        example->setStyleSheet(QString("color:%1;").arg(cSecondary()));
        auto updateExample = [=]() {
            setVal("settings.int.odb.base_url", baseUrl->text().trimmed());
            setVal("settings.int.odb.api_key", apiKey->text().trimmed());
            setVal("settings.int.odb.api_key_param", apiKeyParam->text().trimmed());
            setVal("settings.int.odb.header_name", headerName->text().trimmed());
            setVal("settings.int.odb.plate_endpoint", plateEndpoint->text().trimmed());
            setVal("settings.int.odb.plate_param", plateParam->text().trimmed());
            setVal("settings.int.odb.vin_endpoint", vinEndpoint->text().trimmed());
            setVal("settings.int.odb.vin_param", vinParam->text().trimmed());
            setVal("settings.int.odb.test_plate", testPlate->text().trimmed());
            const QString preview = OpenDataBotClient::buildPlateLookupUrl(testPlate->text().trimmed());
            example->setText(QString::fromUtf8("Приклад запиту: %1").arg(preview));
        };
        updateExample();
        l->addWidget(example);

        auto* row = new QHBoxLayout();
        auto* save = new QPushButton(QString::fromUtf8("Зберегти"), w);
        auto* test = new QPushButton(QString::fromUtf8("Тест запиту"), w);
        save->setFixedWidth(160);
        test->setFixedWidth(160);
        row->addWidget(save);
        row->addWidget(test);
        row->addStretch(1);
        l->addLayout(row);

        auto saveAll = [=]() {
            setVal("settings.int.odb.demo_mode", demoMode->isChecked());
            setVal("settings.int.odb.base_url", baseUrl->text().trimmed());
            setVal("settings.int.odb.api_key", apiKey->text().trimmed());
            setVal("settings.int.odb.api_key_param", apiKeyParam->text().trimmed());
            setVal("settings.int.odb.header_name", headerName->text().trimmed());
            setVal("settings.int.odb.plate_endpoint", plateEndpoint->text().trimmed());
            setVal("settings.int.odb.plate_param", plateParam->text().trimmed());
            setVal("settings.int.odb.vin_endpoint", vinEndpoint->text().trimmed());
            setVal("settings.int.odb.vin_param", vinParam->text().trimmed());
            setVal("settings.int.odb.test_plate", testPlate->text().trimmed());
            updateExample();
        };

        connect(save, &QPushButton::clicked, this, [this, saveAll]() {
            saveAll();
            QMessageBox::information(this,
                QString::fromUtf8("OpenDataBot"),
                QString::fromUtf8("Параметри OpenDataBot збережено. Після введення держномера у формі нового наряду дані авто будуть підставлятися автоматично."));
        });
        connect(test, &QPushButton::clicked, this, [this, testPlate, saveAll]() {
            saveAll();
            if (testPlate->text().trimmed().isEmpty()) {
                QMessageBox::warning(this,
                    QString::fromUtf8("Тест OpenDataBot"),
                    QString::fromUtf8("Введіть тестовий держномер."));
                return;
            }
            OpenDataBotClient::lookupByPlate(this, testPlate->text().trimmed(), [this](const OpenDataBotClient::VehicleLookupResult& result) {
                if (!result.success) {
                    QMessageBox::warning(this,
                        QString::fromUtf8("Тест OpenDataBot"),
                        result.error.isEmpty() ? QString::fromUtf8("Сервіс не повернув дані.") : result.error);
                    return;
                }
                QMessageBox::information(this,
                    QString::fromUtf8("Тест OpenDataBot"),
                    QString::fromUtf8("Отримано дані:\nVIN: %1\nАвто: %2\nРік: %3\nКолір: %4\nПальне: %5")
                        .arg(result.vin.isEmpty() ? QString::fromUtf8("—") : result.vin,
                             result.carDisplay.isEmpty() ? QString::fromUtf8("—") : result.carDisplay,
                             result.year > 0 ? QString::number(result.year) : QString::fromUtf8("—"),
                             result.color.isEmpty() ? QString::fromUtf8("—") : result.color,
                             result.fuelType.isEmpty() ? QString::fromUtf8("—") : result.fuelType));
            });
        });

        const auto editors = QList<QLineEdit*>{baseUrl, apiKey, apiKeyParam, headerName, plateEndpoint, plateParam, vinEndpoint, vinParam, testPlate};
        for (auto* editor : editors) {
            connect(editor, &QLineEdit::editingFinished, this, updateExample);
        }
        connect(demoMode, &QCheckBox::toggled, this, [saveAll](bool) { saveAll(); });

        l->addStretch(1);
        return w;
    }

    if (id == "int.stores") {
        auto* w = new QWidget(this);
        auto* l = new QVBoxLayout(w);
        l->setContentsMargins(18,18,18,18);
        l->setSpacing(12);
        auto* title = new QLabel(QString::fromUtf8("Магазини"), w);
        title->setStyleSheet(QString("font-size:14pt; font-weight:800; color:%1;").arg(cPrimary()));
        l->addWidget(title);
        auto* info = new QLabel(QString::fromUtf8("Тут буде налаштування API магазинів та постачальників запчастин. На цьому кроці додано лише OpenDataBot для автозаповнення форми нового наряду за держномером."), w);
        info->setWordWrap(true);
        info->setStyleSheet(QString("color:%1;").arg(cSecondary()));
        l->addWidget(info);
        l->addStretch(1);
        return w;
    }

    // --- Integrations / Google Sheets ---
    if (id == "int.gsheets") {
        auto* w = new QWidget(this);
        auto* l = new QVBoxLayout(w);
        l->setContentsMargins(18,18,18,18);
        l->setSpacing(12);

        auto* title = new QLabel(QString::fromUtf8("Google Sheets"), w);
        title->setStyleSheet(QString("font-size:14pt; font-weight:800; color:%1;").arg(cPrimary()));
        l->addWidget(title);

        auto* form = new QFormLayout();
        form->setHorizontalSpacing(12);
        form->setVerticalSpacing(10);

        auto* url = new QLineEdit(getStr("settings.int.gs_url", QString()), w);
        auto* token = new QLineEdit(getStr("settings.int.gs_token", QString()), w);

        form->addRow(QString::fromUtf8("URL (Apps Script):"), url);
        form->addRow(QString::fromUtf8("Токен доступу:"), token);
        l->addLayout(form);

        auto* row = new QHBoxLayout();
        auto* save = new QPushButton(QString::fromUtf8("Зберегти"), w);
        auto* test = new QPushButton(QString::fromUtf8("Тест (скоро)"), w);
        save->setFixedWidth(140);
        test->setFixedWidth(140);
        row->addWidget(save);
        row->addWidget(test);
        row->addStretch(1);
        l->addLayout(row);

        auto* info = new QLabel(QString::fromUtf8("Імпорт/експорт із Google Sheets буде перенесено після звітів по запчастинам."), w);
        info->setWordWrap(true);
        info->setStyleSheet(QString("color:%1;").arg(cSecondary()));
        l->addWidget(info);

        l->addStretch(1);

        connect(save, &QPushButton::clicked, this, [url, token]() {
            setVal("settings.int.gs_url", url->text().trimmed());
            setVal("settings.int.gs_token", token->text().trimmed());
        });
        connect(test, &QPushButton::clicked, this, [this]() {
    const QString url = getStr("settings.int.gs_url").trimmed();
    const QString tok = getStr("settings.int.gs_token").trimmed();
    if (url.isEmpty() || tok.isEmpty()) {
        QMessageBox::warning(this,
            QString::fromUtf8("Тест інтеграції"),
            QString::fromUtf8("Заповніть URL та token."));
        return;
    }
    QMessageBox::information(this,
        QString::fromUtf8("Тест інтеграції"),
        QString::fromUtf8("Параметри збережені.\nURL: %1\nToken: %2…")
            .arg(url)
            .arg(tok.left(6)));
});

        return w;
    }

    
// --- Reports / PDF ---
if (id == "rep.pdf") {
    auto* w = new QWidget(this);
    auto* l = new QVBoxLayout(w);
    l->setContentsMargins(18,18,18,18);
    l->setSpacing(12);

    auto* title = new QLabel(QString::fromUtf8("PDF / друк"), w);
    title->setStyleSheet(QString("font-size:14pt; font-weight:800; color:%1;").arg(cPrimary()));
    l->addWidget(title);

    auto* cbLogo = new QCheckBox(QString::fromUtf8("Додавати логотип у PDF"), w);
    cbLogo->setChecked(getBool("settings.reports.pdf.include_logo", true));
    l->addWidget(cbLogo);

    auto* cbPhone = new QCheckBox(QString::fromUtf8("Додавати телефон у футер"), w);
    cbPhone->setChecked(getBool("settings.reports.pdf.include_phone", true));
    l->addWidget(cbPhone);

    auto* footerRow = new QHBoxLayout();
    footerRow->addWidget(new QLabel(QString::fromUtf8("Текст футера:"), w));
    auto* footer = new QLineEdit(getStr("settings.reports.pdf.footer_text", QString()), w);
    footerRow->addWidget(footer, 1);
    l->addLayout(footerRow);

    auto* hint = new QLabel(QString::fromUtf8("Ці параметри використовуються у друці наряду та звітах."), w);
    hint->setWordWrap(true);
    hint->setStyleSheet(QString("color:%1;").arg(cSecondary()));
    l->addWidget(hint);

    l->addStretch(1);

    connect(cbLogo, &QCheckBox::toggled, this, [](bool on) { setVal("settings.reports.pdf.include_logo", on); });
    connect(cbPhone, &QCheckBox::toggled, this, [](bool on) { setVal("settings.reports.pdf.include_phone", on); });
    connect(footer, &QLineEdit::editingFinished, this, [footer]() {
        setVal("settings.reports.pdf.footer_text", footer->text().trimmed());
    });

    return w;
}

// --- Finance / Defaults ---
if (id == "fin.defaults") {
    auto* w = new QWidget(this);
    auto* l = new QVBoxLayout(w);
    l->setContentsMargins(18,18,18,18);
    l->setSpacing(12);

    auto* title = new QLabel(QString::fromUtf8("Націнка запчастин"), w);
    title->setStyleSheet(QString("font-size:16pt; font-weight:800; color:%1;").arg(cPrimary()));
    l->addWidget(title);

    auto makeGroup = [this, w](const QString& caption) {
        auto* gb = new QGroupBox(caption, w);
        gb->setStyleSheet(QString::fromUtf8(R"QSS(
            QGroupBox {
                font-weight: 700;
                border: 1px solid %1;
                border-radius: 14px;
                margin-top: 14px;
                padding-top: 18px;
                background: %2;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 14px;
                padding: 3px 12px;
                background: %2;
                border: 1px solid %1;
                border-radius: 10px;
            }
        )QSS").arg(cPanelBorder(), cPanelBg()));
        auto* gl = new QVBoxLayout(gb);
        gl->setContentsMargins(16, 18, 16, 16);
        gl->setSpacing(10);
        return gb;
    };

    auto* partsGroup = makeGroup(QString::fromUtf8("Запчастини"));
    auto* oilGroup = makeGroup(QString::fromUtf8("Моторне мастило"));

    auto* partsLayout = qobject_cast<QVBoxLayout*>(partsGroup->layout());
    auto* oilLayout = qobject_cast<QVBoxLayout*>(oilGroup->layout());

    auto makeHeader = [w](const QString& leftText, const QString& rightText) {
        auto* row = new QWidget(w);
        auto* hl = new QHBoxLayout(row);
        hl->setContentsMargins(0,0,0,0);
        hl->setSpacing(10);
        auto* left = new QLabel(leftText, row);
        auto* right = new QLabel(rightText, row);
        left->setMinimumWidth(280);
        left->setStyleSheet("font-weight:700;");
        right->setFixedWidth(160);
        right->setAlignment(Qt::AlignCenter);
        right->setStyleSheet("font-weight:700;");
        hl->addWidget(left, 1);
        hl->addWidget(right);
        return row;
    };

    partsLayout->addWidget(makeHeader(QString::fromUtf8("Назва магазину"), QString::fromUtf8("Доданий %")));
    oilLayout->addWidget(makeHeader(QString::fromUtf8("Назва магазину"), QString::fromUtf8("Доданий %")));

    auto* partsRowsWrap = new QWidget(partsGroup);
    auto* partsRows = new QVBoxLayout(partsRowsWrap);
    partsRows->setContentsMargins(0,0,0,0);
    partsRows->setSpacing(10);
    partsLayout->addWidget(partsRowsWrap);

    auto* oilRowsWrap = new QWidget(oilGroup);
    auto* oilRows = new QVBoxLayout(oilRowsWrap);
    oilRows->setContentsMargins(0,0,0,0);
    oilRows->setSpacing(10);
    oilLayout->addWidget(oilRowsWrap);

    auto makeButtonsRow = [w](const QString& addText) {
        auto* row = new QWidget(w);
        auto* hl = new QHBoxLayout(row);
        hl->setContentsMargins(0,0,0,0);
        hl->setSpacing(10);
        auto* add = new QPushButton(addText, row);
        auto* del = new QPushButton(QString::fromUtf8("Видалити"), row);
        add->setMinimumHeight(40);
        del->setMinimumHeight(40);
        add->setMinimumWidth(180);
        del->setMinimumWidth(140);
        hl->addWidget(add, 0);
        hl->addWidget(del, 0);
        hl->addStretch(1);
        row->setProperty("addBtn", QVariant::fromValue<QObject*>(add));
        row->setProperty("delBtn", QVariant::fromValue<QObject*>(del));
        return row;
    };

    auto* partsBtns = makeButtonsRow(QString::fromUtf8("Додати магазин"));
    auto* oilBtns = makeButtonsRow(QString::fromUtf8("Додати магазин"));
    partsLayout->addWidget(partsBtns);
    oilLayout->addWidget(oilBtns);

    auto* hint = new QLabel(QString::fromUtf8("Якщо для магазину задано відсоток, він автоматично додається до ціни запчастини в наряді та PDF. Якщо % не задано або дорівнює 0, ціна залишається без змін."), w);
    hint->setWordWrap(true);
    hint->setStyleSheet(QString("color:%1;").arg(cSecondary()));

    auto* actions = new QWidget(w);
    auto* actionsLay = new QHBoxLayout(actions);
    actionsLay->setContentsMargins(0,0,0,0);
    actionsLay->setSpacing(10);
    auto* btnReset = new QPushButton(QString::fromUtf8("Скасувати"), actions);
    auto* btnSave = new QPushButton(QString::fromUtf8("Зберегти"), actions);
    btnReset->setMinimumHeight(42);
    btnSave->setMinimumHeight(42);
    btnReset->setMinimumWidth(150);
    btnSave->setMinimumWidth(150);
    actionsLay->addStretch(1);
    actionsLay->addWidget(btnReset);
    actionsLay->addWidget(btnSave);

    l->addWidget(partsGroup);
    l->addWidget(oilGroup);
    l->addWidget(hint);
    l->addWidget(actions);
    l->addStretch(1);

    struct MarkupRowWidgets {
        QWidget* root = nullptr;
        QLineEdit* store = nullptr;
        QDoubleSpinBox* pct = nullptr;
    };

    auto* partRowsList = new QList<MarkupRowWidgets>();
    auto* oilRowsList = new QList<MarkupRowWidgets>();

    auto createRow = [w](QVBoxLayout* host, QList<MarkupRowWidgets>* list, const QString& storeName, double pctValue) {
        MarkupRowWidgets rw;
        rw.root = new QWidget(w);
        auto* hl = new QHBoxLayout(rw.root);
        hl->setContentsMargins(0,0,0,0);
        hl->setSpacing(10);
        rw.store = new QLineEdit(rw.root);
        rw.store->setPlaceholderText(QString::fromUtf8("Напр.: Еліт"));
        rw.store->setText(storeName);
        rw.store->setMinimumHeight(42);
        rw.pct = new QDoubleSpinBox(rw.root);
        rw.pct->setRange(0.0, 300.0);
        rw.pct->setDecimals(1);
        rw.pct->setSuffix(" %");
        rw.pct->setValue(pctValue);
        rw.pct->setButtonSymbols(QAbstractSpinBox::NoButtons);
        rw.pct->setMinimumHeight(42);
        rw.pct->setFixedWidth(160);
        hl->addWidget(rw.store, 1);
        hl->addWidget(rw.pct, 0);
        host->addWidget(rw.root);
        list->append(rw);
    };

    auto clearRows = [](QVBoxLayout* host, QList<MarkupRowWidgets>* list) {
        while (!list->isEmpty()) {
            MarkupRowWidgets rw = list->takeLast();
            host->removeWidget(rw.root);
            delete rw.root;
        }
    };

    auto collectJson = [](const QList<MarkupRowWidgets>& list) {
        QJsonObject obj;
        for (const auto& row : list) {
            const QString key = row.store->text().trimmed();
            if (key.isEmpty()) continue;
            obj.insert(key, row.pct->value());
        }
        return QString::fromUtf8(QJsonDocument(obj).toJson(QJsonDocument::Compact));
    };

    auto loadRowsFromSetting = [&](const QString& settingKey, QVBoxLayout* host, QList<MarkupRowWidgets>* list, const QList<QPair<QString,double>>& fallbackRows) {
        clearRows(host, list);
        const QString raw = Database::getSetting(settingKey, "{}").toString();
        const auto doc = QJsonDocument::fromJson(raw.toUtf8());
        QList<QPair<QString,double>> rows;
        if (doc.isObject()) {
            const auto obj = doc.object();
            for (auto it = obj.begin(); it != obj.end(); ++it) {
                rows.append({it.key(), it.value().toDouble()});
            }
        }
        if (rows.isEmpty()) rows = fallbackRows;
        if (rows.isEmpty()) rows.append({QString(), 0.0});
        for (const auto& pair : rows) createRow(host, list, pair.first, pair.second);
    };

    auto deleteLastFilledRow = [](QVBoxLayout* host, QList<MarkupRowWidgets>* list) {
        if (list->isEmpty()) return;
        int idx = list->size() - 1;
        while (idx > 0) {
            const auto& row = list->at(idx);
            if (!row.store->text().trimmed().isEmpty() || row.pct->value() != 0.0) break;
            --idx;
        }
        auto rw = list->takeAt(idx);
        host->removeWidget(rw.root);
        delete rw.root;
        if (list->isEmpty()) {
            // caller should add an empty row back if needed
        }
    };

    auto reloadUi = [&]() {
        loadRowsFromSetting("settings.fin.store_markups", partsRows, partRowsList, {
            {QString(), 0.0}, {QString(), 0.0}, {QString(), 0.0}
        });
        QList<QPair<QString,double>> oilFallback;
        const double oldOilDefault = getDouble("settings.fin.oil_markup", 0.0);
        if (oldOilDefault > 0.0) oilFallback.append({QString(), oldOilDefault});
        else oilFallback.append({QString(), 0.0});
        loadRowsFromSetting("settings.fin.oil_store_markups", oilRows, oilRowsList, oilFallback);
    };

    reloadUi();

    auto* partsAddBtn = qobject_cast<QPushButton*>(partsBtns->property("addBtn").value<QObject*>());
    auto* partsDelBtn = qobject_cast<QPushButton*>(partsBtns->property("delBtn").value<QObject*>());
    auto* oilAddBtn = qobject_cast<QPushButton*>(oilBtns->property("addBtn").value<QObject*>());
    auto* oilDelBtn = qobject_cast<QPushButton*>(oilBtns->property("delBtn").value<QObject*>());

    connect(partsAddBtn, &QPushButton::clicked, this, [=]() {
        createRow(partsRows, partRowsList, QString(), 0.0);
    });
    connect(oilAddBtn, &QPushButton::clicked, this, [=]() {
        createRow(oilRows, oilRowsList, QString(), 0.0);
    });
    connect(partsDelBtn, &QPushButton::clicked, this, [=]() {
        deleteLastFilledRow(partsRows, partRowsList);
        if (partRowsList->isEmpty()) createRow(partsRows, partRowsList, QString(), 0.0);
    });
    connect(oilDelBtn, &QPushButton::clicked, this, [=]() {
        deleteLastFilledRow(oilRows, oilRowsList);
        if (oilRowsList->isEmpty()) createRow(oilRows, oilRowsList, QString(), 0.0);
    });

    connect(btnReset, &QPushButton::clicked, this, [reloadUi]() {
        reloadUi();
    });

    connect(btnSave, &QPushButton::clicked, this, [=]() {
        setVal("settings.fin.store_markups", collectJson(*partRowsList));
        setVal("settings.fin.oil_store_markups", collectJson(*oilRowsList));

        double oilDefault = 0.0;
        for (const auto& row : *oilRowsList) {
            if (!row.store->text().trimmed().isEmpty()) {
                oilDefault = row.pct->value();
                break;
            }
            if (row.pct->value() > 0.0) {
                oilDefault = row.pct->value();
            }
        }
        setVal("settings.fin.oil_markup", oilDefault);
        recalcAllPartMarkupsFromSettings();
        QMessageBox::information(w, QString::fromUtf8("Збережено"), QString::fromUtf8("Націнки для запчастин збережено і перераховано для всіх запчастин."));
    });

    return w;
}

// --- Outsource / Defaults ---
if (id == "out.defaults") {
    return new OutsourceSettingsWidget(this);
}

// Default placeholder for not-yet-ported sections
    return buildPlaceholderWidget(QString::fromUtf8("Цей розділ буде перенесено у наступних версіях."));
}
