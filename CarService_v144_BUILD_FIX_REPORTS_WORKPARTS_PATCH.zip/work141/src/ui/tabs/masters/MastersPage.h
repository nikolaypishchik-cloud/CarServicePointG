#pragma once

#include <QWidget>

class QLineEdit;
class QToolButton;
class QTableWidget;
class QCheckBox;

class MastersPage : public QWidget
{
    Q_OBJECT
public:
    explicit MastersPage(QWidget* parent=nullptr);

    void refresh();

signals:
    void requestRefreshAll();

private:
    QString selectedMasterId() const;

    void addMaster();
    void editMaster();
    void toggleActive();
    void deleteMaster();

    QLineEdit* m_search = nullptr;
    QCheckBox* m_showArchived = nullptr;
    QTableWidget* m_table = nullptr;

    bool m_loading = false;
};
