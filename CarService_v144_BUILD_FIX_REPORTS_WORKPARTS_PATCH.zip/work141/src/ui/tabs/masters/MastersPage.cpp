#include "ui/tabs/masters/MastersPage.h"

#include "infrastructure/db/sqlite/Db.h"
#include "ui/common/dialogs/MasterEditDialog.h"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QToolButton>
#include <QLineEdit>
#include <QTableWidget>
#include <QHeaderView>
#include <QMessageBox>
#include <QCheckBox>
#include <QDoubleSpinBox>
#include <QLabel>

static void setCell(QTableWidget* t, int r, int c, const QString& text, bool bold=false)
{
    auto* it = new QTableWidgetItem(text);
    if (bold) {
        QFont f = it->font();
        f.setBold(true);
        it->setFont(f);
    }
    t->setItem(r, c, it);
}

MastersPage::MastersPage(QWidget* parent)
    : QWidget(parent)
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(0,0,0,0);
    root->setSpacing(10);

    // Toolbar
    auto* bar = new QHBoxLayout();
    bar->setContentsMargins(0,0,0,0);

    auto* btnAdd = new QToolButton(this);
    btnAdd->setText(QString::fromUtf8("➕ Додати"));
    auto* btnEdit = new QToolButton(this);
    btnEdit->setText(QString::fromUtf8("✏️ Редагувати"));
    auto* btnActive = new QToolButton(this);
    btnActive->setText(QString::fromUtf8("🗄️ Архів/Відновити"));
    auto* btnDelete = new QToolButton(this);
    btnDelete->setText(QString::fromUtf8("🗑️ Видалити"));

    m_showArchived = new QCheckBox(QString::fromUtf8("Показати архів"), this);

    m_search = new QLineEdit(this);
    m_search->setPlaceholderText(QString::fromUtf8("Пошук: ім'я…"));

    bar->addWidget(btnAdd);
    bar->addWidget(btnEdit);
    bar->addWidget(btnActive);
    bar->addWidget(btnDelete);
    bar->addSpacing(10);
    bar->addWidget(m_showArchived);
    bar->addStretch(1);
    bar->addWidget(m_search);

    root->addLayout(bar);

    // Table
    m_table = new QTableWidget(this);
    m_table->setColumnCount(5);
    m_table->setHorizontalHeaderLabels({
        QString::fromUtf8("Ім'я"),
        QString::fromUtf8("Роль"),
        QString::fromUtf8("З/п %"),
        QString::fromUtf8("Адмін %"),
        QString::fromUtf8("Активний")
    });
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setAlternatingRowColors(true);
    m_table->horizontalHeader()->setStretchLastSection(true);
    m_table->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    m_table->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(3, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(4, QHeaderView::ResizeToContents);

    root->addWidget(m_table, 1);

    connect(btnAdd, &QToolButton::clicked, this, &MastersPage::addMaster);
    connect(btnEdit, &QToolButton::clicked, this, &MastersPage::editMaster);
    connect(btnActive, &QToolButton::clicked, this, &MastersPage::toggleActive);
    connect(btnDelete, &QToolButton::clicked, this, &MastersPage::deleteMaster);

    connect(m_search, &QLineEdit::textChanged, this, [this]() { refresh(); });
    connect(m_showArchived, &QCheckBox::toggled, this, [this]() { refresh(); });

    connect(m_table, &QTableWidget::cellDoubleClicked, this, [this](int, int) { editMaster(); });

    refresh();
    emit requestRefreshAll();
}

QString MastersPage::selectedMasterId() const
{
    if (!m_table) return QString();
    auto sel = m_table->selectionModel()->selectedRows();
    if (sel.isEmpty()) return QString();
    const int r = sel.first().row();
    auto* it = m_table->item(r, 0);
    if (!it) return QString();
    return it->data(Qt::UserRole + 1).toString();
}

void MastersPage::refresh()
{
    if (!m_table) return;
    m_loading = true;

    const bool showArchived = m_showArchived->isChecked();
    const QString filter = m_search->text().trimmed().toLower();

    const auto masters = Database::masters(!showArchived);
    const auto percents = Database::payrollPercents();

    m_table->setRowCount(0);

    for (const auto& m : masters) {
        if (!filter.isEmpty() && !m.name.toLower().contains(filter)) continue;

        const int r = m_table->rowCount();
        m_table->insertRow(r);

        // Name
        auto* nameIt = new QTableWidgetItem(m.name);
        nameIt->setData(Qt::UserRole + 1, m.id);
        if (!m.active) {
            QFont f = nameIt->font();
            f.setStrikeOut(true);
            nameIt->setFont(f);
        }
        m_table->setItem(r, 0, nameIt);

        // Role
        const QString roleLabel = (m.role == "admin") ? QString::fromUtf8("Адмін") : QString::fromUtf8("Майстер");
        setCell(m_table, r, 1, roleLabel);

        // Payroll percent editor
        auto* sp = new QDoubleSpinBox(m_table);
        sp->setRange(0, 100);
        sp->setDecimals(2);
        sp->setSuffix(QString::fromUtf8(" %"));
        sp->setValue(percents.value(m.id, 0.0));
        sp->setEnabled(m.active);
        m_table->setCellWidget(r, 2, sp);
        connect(sp, qOverload<double>(&QDoubleSpinBox::valueChanged), this, [this, id=m.id](double v) {
            if (m_loading) return;
            Database::setPayrollPercent(id, v);
        });

        // Admin percent
        setCell(m_table, r, 3, QString::number(m.adminPercent, 'f', 2));

        // Active
        setCell(m_table, r, 4, m.active ? QString::fromUtf8("Так") : QString::fromUtf8("Ні"));
    }

    m_loading = false;
}

void MastersPage::addMaster()
{
    MasterEditDialog dlg(this);
    if (dlg.exec() != QDialog::Accepted) return;

    const auto m = dlg.data();
    if (m.name.isEmpty()) {
        QMessageBox::warning(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Ім'я не може бути порожнім."));
        return;
    }

    if (!Database::upsertMaster(m)) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не вдалося зберегти майстра."));
        return;
    }
    Database::setPayrollPercent(m.id, dlg.payrollPercent());
    refresh();
    emit requestRefreshAll();
}

void MastersPage::editMaster()
{
    const QString id = selectedMasterId();
    if (id.isEmpty()) return;

    const auto masters = Database::masters(false);
    MasterRow cur;
    bool found = false;
    for (const auto& m : masters) {
        if (m.id == id) { cur = m; found = true; break; }
    }
    if (!found) return;

    const double pct = Database::payrollPercents().value(id, 0.0);

    MasterEditDialog dlg(this);
    dlg.setData(cur, pct);

    if (dlg.exec() != QDialog::Accepted) return;

    const auto upd = dlg.data();
    if (upd.name.isEmpty()) {
        QMessageBox::warning(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Ім'я не може бути порожнім."));
        return;
    }

    if (!Database::upsertMaster(upd)) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не вдалося зберегти майстра."));
        return;
    }
    Database::setPayrollPercent(upd.id, dlg.payrollPercent());
    refresh();
    emit requestRefreshAll();
}

void MastersPage::toggleActive()
{
    const QString id = selectedMasterId();
    if (id.isEmpty()) return;

    const auto masters = Database::masters(false);
    for (const auto& m : masters) {
        if (m.id != id) continue;
        Database::setMasterActive(id, !m.active);
        break;
    }
    refresh();
    emit requestRefreshAll();
}

void MastersPage::deleteMaster()
{
    const QString id = selectedMasterId();
    if (id.isEmpty()) return;

    auto res = QMessageBox::question(
        this,
        QString::fromUtf8("Підтвердження"),
        QString::fromUtf8("Видалити майстра?\nЯкщо майстер використовується у нарядах — буде лише заархівований."),
        QMessageBox::Yes | QMessageBox::No
    );
    if (res != QMessageBox::Yes) return;

    if (!Database::deleteMasterIfUnusedOrArchive(id)) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не вдалося видалити/архівувати майстра."));
        return;
    }

    refresh();
    emit requestRefreshAll();
}
