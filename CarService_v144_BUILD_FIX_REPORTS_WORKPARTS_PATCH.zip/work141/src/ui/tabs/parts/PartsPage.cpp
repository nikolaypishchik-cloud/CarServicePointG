#include "ui/tabs/parts/PartsPage.h"

#include "infrastructure/db/sqlite/Db.h"
#include "ui/common/dialogs/OrderDialog.h"
#include "core/util/FormatUtils.h"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QTableWidget>
#include <QHeaderView>
#include <QLineEdit>
#include <QDateEdit>
#include <QPushButton>
#include <QSizePolicy>
#include <QLabel>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlDatabase>
#include <QTableWidgetItem>
#include <QAbstractItemView>
#include <QVariant>
#include <QDate>
#include <QStyle>
#include <QFontMetrics>
#include <QSignalBlocker>
#include <QRegularExpression>
#include <algorithm>

namespace {
constexpr int ColId = 0;
constexpr int ColDate = 1;
constexpr int ColStore = 2;
constexpr int ColArticle = 3;
constexpr int ColName = 4;
constexpr int ColQty = 5;
constexpr int ColPrice = 6;
constexpr int ColAmount = 7;
constexpr int ColOrder = 8;
constexpr int ColAuto = 9;
constexpr int ColPaid = 10;

QString escLike(QString s)
{
    s.replace(QStringLiteral("\\"), QStringLiteral("\\\\"));
    s.replace(QStringLiteral("%"), QStringLiteral("\\%"));
    s.replace(QStringLiteral("_"), QStringLiteral("\\_"));
    return s;
}

QTableWidgetItem* makeItem(const QString& text, int align = Qt::AlignLeft | Qt::AlignVCenter)
{
    auto* item = new QTableWidgetItem(text);
    item->setTextAlignment(align);
    return item;
}

QString buttonStyle(bool paid)
{
    if (paid) {
        return QString::fromUtf8(
            "QPushButton {"
            " background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #d8d8d8, stop:1 #8c8c8c);"
            " color:white; border:1px solid #666; border-radius:10px; font-weight:700; padding:2px 8px; text-align:center; }"
            "QPushButton:hover { background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #e4e4e4, stop:1 #9a9a9a); }"
            "QPushButton:pressed { padding-top:3px; padding-left:9px; }");
    }
    return QString::fromUtf8(
        "QPushButton {"
        " background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #ff8e8e, stop:1 #c51f1f);"
        " color:white; border:1px solid #7a1010; border-radius:10px; font-weight:700; padding:2px 8px; text-align:center; }"
        "QPushButton:hover { background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #ffaaaa, stop:1 #d62b2b); }"
        "QPushButton:pressed { padding-top:3px; padding-left:9px; }");
}


QDate normalizeBusinessDate(QDate d)
{
    if (d.isValid() && d.year() >= 1900 && d.year() < 2000) {
        d = d.addYears(100);
    }
    return d;
}

QDate parseTableDate(const QString& raw)
{
    const QString s = raw.trimmed();
    for (const QString& fmt : {QStringLiteral("yyyy-MM-dd"), QStringLiteral("dd.MM.yyyy"), QStringLiteral("dd.MM.yy")}) {
        QDate d = QDate::fromString(s, fmt);
        if (d.isValid()) return normalizeBusinessDate(d);
    }

    static const QRegularExpression iso2(QStringLiteral(R"((\d{4})-(\d{2})-(\d{2}))"));
    const auto m = iso2.match(s);
    if (m.hasMatch()) {
        int y = m.captured(1).toInt();
        const int mon = m.captured(2).toInt();
        const int day = m.captured(3).toInt();
        if (y >= 1900 && y < 2000) y += 100;
        return QDate(y, mon, day);
    }
    return {};
}

QString displayDate(const QString& raw)
{
    const QDate d = parseTableDate(raw);
    return d.isValid() ? d.toString(QStringLiteral("dd.MM.yy")) : raw.trimmed();
}

int rowHeightForText(const QFontMetrics& fm, const QString& text, int width, int minHeight)
{
    const QRect r = fm.boundingRect(QRect(0, 0, qMax(10, width), 10000), Qt::TextWordWrap, text);
    return qMax(minHeight, r.height() + 10);
}
}

PartsPage::PartsPage(QWidget* parent)
    : QWidget(parent)
{
    buildUi();
    refresh();
}

void PartsPage::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(12, 12, 12, 12);
    root->setSpacing(10);

    auto* bar = new QHBoxLayout();
    bar->setContentsMargins(0,0,0,0);
    bar->setSpacing(10);

    m_search = new QLineEdit(this);
    m_search->setPlaceholderText(QString::fromUtf8("Пошук: артикул/назва/магазин або авто"));
    m_search->setMinimumHeight(34);
    m_search->setMinimumWidth(260);
    m_search->setMaximumWidth(320);

    m_dateFrom = new QDateEdit(this);
    m_dateTo = new QDateEdit(this);
    for (auto* edit : {m_dateFrom, m_dateTo}) {
        edit->setCalendarPopup(true);
        edit->setDisplayFormat(QStringLiteral("dd.MM.yy"));
        edit->setMinimumHeight(34);
        edit->setMinimumWidth(128);
        edit->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        edit->setKeyboardTracking(false);
    }

    auto* fromLbl = new QLabel(QString::fromUtf8("Від:"), this);
    auto* toLbl = new QLabel(QString::fromUtf8("По:"), this);

    m_findBtn = new QPushButton(QString::fromUtf8("🔍 Знайти"), this);
    m_deleteBtn = new QPushButton(QString::fromUtf8("🗑 Видалити"), this);
    m_openOrderBtn = new QPushButton(QString::fromUtf8("Відкрити наряд"), this);
    QFont toolBtnFont = m_findBtn->font();
    toolBtnFont.setPointSizeF(qMax(8.0, toolBtnFont.pointSizeF() - 1.0));
    for (auto* btn : {m_findBtn, m_deleteBtn, m_openOrderBtn}) {
        btn->setMinimumHeight(34);
        btn->setCursor(Qt::PointingHandCursor);
        btn->setFont(toolBtnFont);
    }
    m_findBtn->setIconSize(QSize(13, 13));
    m_deleteBtn->setIcon(style()->standardIcon(QStyle::SP_TrashIcon));
    m_deleteBtn->setIconSize(QSize(13, 13));

    bar->addWidget(fromLbl);
    bar->addWidget(m_dateFrom);
    bar->addWidget(toLbl);
    bar->addWidget(m_dateTo);
    bar->addSpacing(14);
    bar->addWidget(m_search, 0);
    bar->addWidget(m_findBtn);
    bar->addWidget(m_deleteBtn);
    bar->addWidget(m_openOrderBtn);
    root->addLayout(bar);

    m_hint = new QLabel(QString::fromUtf8("Архів запчастин — тут показані всі запчастини, які були додані в наряди."), this);
    m_hint->setWordWrap(true);
    root->addWidget(m_hint);

    m_table = new QTableWidget(this);
    m_table->setColumnCount(11);
    m_table->setHorizontalHeaderLabels({
        QStringLiteral("ID"),
        QString::fromUtf8("Дата"),
        QString::fromUtf8("Магазин"),
        QString::fromUtf8("Артикул"),
        QString::fromUtf8("Назва"),
        QString::fromUtf8("Кіл-ть"),
        QString::fromUtf8("Ціна"),
        QString::fromUtf8("Сума"),
        QString::fromUtf8("Наряд"),
        QString::fromUtf8("Авто"),
        QString::fromUtf8("Сплачено")
    });
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::ExtendedSelection);
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setAlternatingRowColors(false);
    m_table->verticalHeader()->setVisible(false);
    m_table->setShowGrid(true);
    m_table->setSortingEnabled(false);
    m_table->setWordWrap(true);
    m_table->setColumnHidden(ColId, true);
    m_table->horizontalHeader()->setSectionResizeMode(ColDate, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(ColStore, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(ColArticle, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(ColName, QHeaderView::Stretch);
    m_table->horizontalHeader()->setSectionResizeMode(ColQty, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(ColPrice, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(ColAmount, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(ColOrder, QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(ColAuto, QHeaderView::Stretch);
    m_table->horizontalHeader()->setSectionResizeMode(ColPaid, QHeaderView::Fixed);
    m_table->setColumnWidth(ColPaid, 190);
    m_table->horizontalHeader()->setDefaultAlignment(Qt::AlignCenter);
    root->addWidget(m_table, 1);

    connect(m_findBtn, &QPushButton::clicked, this, &PartsPage::refresh);
    connect(m_search, &QLineEdit::returnPressed, this, &PartsPage::refresh);
    connect(m_search, &QLineEdit::textChanged, this, &PartsPage::applyFilter);
    connect(m_deleteBtn, &QPushButton::clicked, this, &PartsPage::deleteSelectedParts);
    connect(m_openOrderBtn, &QPushButton::clicked, this, &PartsPage::openSelectedOrder);
    connect(m_dateFrom, &QDateEdit::dateChanged, this, &PartsPage::applyFilter);
    connect(m_dateTo, &QDateEdit::dateChanged, this, &PartsPage::applyFilter);
    connect(m_table->horizontalHeader(), &QHeaderView::sectionResized, this, [this](int, int, int) { updateRowHeights(); });
}

int PartsPage::selectedPartId() const
{
    const QList<int> ids = selectedPartIds();
    return ids.isEmpty() ? -1 : ids.first();
}

int PartsPage::selectedOrderNumber() const
{
    if (!m_table) return -1;
    const auto rows = m_table->selectionModel() ? m_table->selectionModel()->selectedRows() : QModelIndexList();
    if (rows.isEmpty()) return -1;
    const int row = rows.first().row();
    bool ok = false;
    const int orderNumber = m_table->item(row, ColOrder) ? m_table->item(row, ColOrder)->data(Qt::EditRole).toInt(&ok) : -1;
    return ok ? orderNumber : -1;
}

QList<int> PartsPage::selectedPartIds() const
{
    QList<int> out;
    if (!m_table || !m_table->selectionModel()) return out;
    const QModelIndexList rows = m_table->selectionModel()->selectedRows();
    for (const QModelIndex& idx : rows) {
        if (auto* item = m_table->item(idx.row(), ColId)) {
            bool ok = false;
            const int id = item->data(Qt::EditRole).toInt(&ok);
            if (ok) out.append(id);
        }
    }
    std::sort(out.begin(), out.end());
    out.erase(std::unique(out.begin(), out.end()), out.end());
    return out;
}

void PartsPage::refresh()
{
    loadRows();
    syncDateRangeFromTable();
    applyFilter();
    updateRowHeights();
}

void PartsPage::loadRows()
{
    if (!m_table) return;
    m_table->setRowCount(0);

    QSqlQuery q(Database::db());
    const QString sql =
        "SELECT p.id, "
        "       COALESCE(p.ordered_at,''), "
        "       COALESCE(p.store,''), "
        "       COALESCE(p.part_number,''), "
        "       COALESCE(p.name,''), "
        "       COALESCE(p.qty,0), "
        "       COALESCE(p.price,0), "
        "       COALESCE(p.amount,0), "
        "       COALESCE(p.order_number,0), "
        "       TRIM(COALESCE(o.plate,'') || CASE WHEN COALESCE(o.car,'')<>'' THEN ' | ' || o.car ELSE '' END), "
        "       COALESCE(p.paid,0) "
        "FROM work_order_parts p "
        "LEFT JOIN work_orders o ON o.number=p.order_number "
        "ORDER BY COALESCE(p.paid,0) ASC, p.ordered_at DESC, p.id DESC";

    if (!q.exec(sql)) {
        QMessageBox::warning(this, QString::fromUtf8("Помилка"), q.lastError().text());
        return;
    }

    int row = 0;
    while (q.next()) {
        m_table->insertRow(row);
        const int id = q.value(0).toInt();
        const QString dateRaw = q.value(1).toString();
        const QString date = displayDate(dateRaw);
        const QString store = q.value(2).toString();
        const QString article = q.value(3).toString();
        const QString name = q.value(4).toString();
        const double qty = q.value(5).toDouble();
        const double price = q.value(6).toDouble();
        const double amount = q.value(7).toDouble();
        const int orderNumber = q.value(8).toInt();
        const QString car = q.value(9).toString();
        const bool paid = q.value(10).toInt() != 0;

        auto* idItem = new QTableWidgetItem();
        idItem->setData(Qt::EditRole, id);
        m_table->setItem(row, ColId, idItem);

        auto* dateItem = makeItem(date);
        dateItem->setData(Qt::UserRole, id);
        m_table->setItem(row, ColDate, dateItem);
        m_table->setItem(row, ColStore, makeItem(store));
        m_table->setItem(row, ColArticle, makeItem(article));
        m_table->setItem(row, ColName, makeItem(name));

        auto* qtyItem = makeItem(FormatUtils::formatNumberSpaces(qty, qty == qRound64(qty) ? 0 : 2), Qt::AlignCenter);
        qtyItem->setData(Qt::EditRole, qty);
        m_table->setItem(row, ColQty, qtyItem);

        auto* priceItem = makeItem(FormatUtils::money(price, 0) + QString::fromUtf8(" грн"), Qt::AlignRight | Qt::AlignVCenter);
        priceItem->setData(Qt::EditRole, price);
        m_table->setItem(row, ColPrice, priceItem);

        auto* amountItem = makeItem(FormatUtils::money(amount, 0) + QString::fromUtf8(" грн"), Qt::AlignRight | Qt::AlignVCenter);
        amountItem->setData(Qt::EditRole, amount);
        if (!paid) {
            amountItem->setBackground(QColor(170, 30, 30));
            amountItem->setForeground(QColor(Qt::white));
        }
        m_table->setItem(row, ColAmount, amountItem);

        auto* orderItem = makeItem(QString::number(orderNumber), Qt::AlignCenter);
        orderItem->setData(Qt::EditRole, orderNumber);
        m_table->setItem(row, ColOrder, orderItem);
        m_table->setItem(row, ColAuto, makeItem(car));

        auto* payBtn = new QPushButton(paid ? QString::fromUtf8("Сплачено") : QString::fromUtf8("Не сплачено"), m_table);
        payBtn->setMinimumWidth(190);
        payBtn->setMinimumHeight(28);
        payBtn->setMaximumHeight(28);
        payBtn->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        payBtn->setCursor(Qt::PointingHandCursor);
        QFont payFont = payBtn->font();
        payFont.setPointSizeF(qMax(7.5, payFont.pointSizeF() - 1.0));
        payBtn->setFont(payFont);
        payBtn->setStyleSheet(buttonStyle(paid));
        connect(payBtn, &QPushButton::clicked, this, [this, id, paid]() {
            togglePaidForPart(id, !paid);
        });
        m_table->setCellWidget(row, ColPaid, payBtn);

        ++row;
    }

    updateRowHeights();
}

void PartsPage::applyFilter()
{
    if (!m_table || !m_search) return;
    const QString f = m_search->text().trimmed();
    const QString needle = f.toLower();
    const QDate from = m_dateFrom ? m_dateFrom->date() : QDate();
    const QDate to = m_dateTo ? m_dateTo->date() : QDate();

    for (int r = 0; r < m_table->rowCount(); ++r) {
        bool matchText = needle.isEmpty();
        if (!matchText) {
            for (int c : {ColDate, ColStore, ColArticle, ColName, ColOrder, ColAuto}) {
                if (auto* item = m_table->item(r, c)) {
                    if (item->text().toLower().contains(needle)) {
                        matchText = true;
                        break;
                    }
                }
            }
        }

        bool matchDate = true;
        if (auto* item = m_table->item(r, ColDate)) {
            const QDate rowDate = parseTableDate(item->text());
            if (rowDate.isValid()) {
                if (from.isValid() && rowDate < from) matchDate = false;
                if (to.isValid() && rowDate > to) matchDate = false;
            }
        }

        m_table->setRowHidden(r, !(matchText && matchDate));
    }
    updateRowHeights();
}

void PartsPage::syncDateRangeFromTable()
{
    if (!m_dateFrom || !m_dateTo || !m_table || m_table->rowCount() <= 0) return;

    QDate minDate;
    QDate maxDate;
    for (int r = 0; r < m_table->rowCount(); ++r) {
        const auto* item = m_table->item(r, ColDate);
        const QDate d = item ? parseTableDate(item->text()) : QDate();
        if (!d.isValid()) continue;
        if (!minDate.isValid() || d < minDate) minDate = d;
        if (!maxDate.isValid() || d > maxDate) maxDate = d;
    }
    if (!minDate.isValid() || !maxDate.isValid()) return;

    const QSignalBlocker b1(m_dateFrom);
    const QSignalBlocker b2(m_dateTo);
    m_dateFrom->setMinimumDate(minDate);
    m_dateFrom->setMaximumDate(maxDate);
    m_dateTo->setMinimumDate(minDate);
    m_dateTo->setMaximumDate(maxDate);
    m_dateFrom->setDate(minDate);
    m_dateTo->setDate(maxDate);
}

void PartsPage::updateRowHeights()
{
    if (!m_table) return;

    const int minButtonHeight = 19;
    const int minRowHeight = 27;
    const int nameWidth = m_table->columnWidth(ColName) - 12;
    const QFontMetrics fm(m_table->font());

    for (int r = 0; r < m_table->rowCount(); ++r) {
        int rowHeight = minRowHeight;
        if (auto* item = m_table->item(r, ColName)) {
            rowHeight = qMax(rowHeight, rowHeightForText(fm, item->text(), nameWidth, minRowHeight));
        }
        if (auto* btn = qobject_cast<QPushButton*>(m_table->cellWidget(r, ColPaid))) {
            btn->setFixedHeight(minButtonHeight);
        }
        m_table->setRowHeight(r, rowHeight);
    }
}

void PartsPage::togglePaidForPart(int partId, bool newPaidState)
{
    if (partId <= 0) return;
    if (!Database::setPartPaid(partId, newPaidState)) {
        QMessageBox::warning(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не вдалося змінити стан оплати запчастини."));
        return;
    }
    emit requestRefreshAll();
}

void PartsPage::openSelectedOrder()
{
    const int orderNumber = selectedOrderNumber();
    if (orderNumber <= 0) {
        QMessageBox::information(this, QString::fromUtf8("Наряд"), QString::fromUtf8("Спочатку виберіть рядок із запчастиною."));
        return;
    }
    OrderDialog dlg(this, orderNumber);
    dlg.openWorkPartsTab();
    dlg.exec();
    emit requestRefreshAll();
}

void PartsPage::deleteSelectedParts()
{
    const QList<int> ids = selectedPartIds();
    if (ids.isEmpty()) {
        QMessageBox::information(this, QString::fromUtf8("Видалення"), QString::fromUtf8("Спочатку виберіть позиції запчастин."));
        return;
    }

    if (QMessageBox::question(this, QString::fromUtf8("Підтвердження"),
                              QString::fromUtf8("Видалити вибрані позиції запчастин?\nДія незворотна.")) != QMessageBox::Yes) {
        return;
    }

    QSqlDatabase d = Database::db();
    if (!d.transaction()) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не можу відкрити транзакцію"));
        return;
    }

    for (int id : ids) {
        QSqlQuery q(d);
        q.prepare("DELETE FROM work_order_parts WHERE id=?");
        q.addBindValue(id);
        if (!q.exec()) {
            d.rollback();
            QMessageBox::critical(this, QString::fromUtf8("Помилка"), q.lastError().text());
            return;
        }
    }

    d.commit();
    emit requestRefreshAll();
}
