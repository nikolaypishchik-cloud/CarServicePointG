#pragma once

#include <QWidget>
#include <QList>

class QTableWidget;
class QLineEdit;
class QPushButton;
class QLabel;
class QDateEdit;

class PartsPage : public QWidget
{
    Q_OBJECT
public:
    explicit PartsPage(QWidget* parent=nullptr);

    void refresh();

signals:
    void requestRefreshAll();

private:
    int selectedPartId() const;
    int selectedOrderNumber() const;
    QList<int> selectedPartIds() const;

    void buildUi();
    void loadRows();
    void applyFilter();
    void togglePaidForPart(int partId, bool newPaidState);
    void openSelectedOrder();
    void deleteSelectedParts();
    void syncDateRangeFromTable();
    void updateRowHeights();

    QTableWidget* m_table = nullptr;
    QLineEdit* m_search = nullptr;
    QPushButton* m_findBtn = nullptr;
    QPushButton* m_deleteBtn = nullptr;
    QPushButton* m_openOrderBtn = nullptr;
    QLabel* m_hint = nullptr;
    QDateEdit* m_dateFrom = nullptr;
    QDateEdit* m_dateTo = nullptr;
};
