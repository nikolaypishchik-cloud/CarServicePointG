#include "ui/theme/ThemeManager.h"

#include "infrastructure/db/sqlite/Db.h"

#include <QApplication>

static QString qssGraphite()
{
    QString qss = QString::fromUtf8(R"QSS(
        QWidget {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 #3f4650,
                                        stop:0.20 #56606c,
                                        stop:0.48 #687482,
                                        stop:0.78 #7a8796,
                                        stop:1 #8995a3);
            color: #f7f8fa;
            font-size: 10.5pt;
        }
        QMainWindow {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 #3f4650,
                                        stop:0.20 #56606c,
                                        stop:0.48 #687482,
                                        stop:0.78 #7a8796,
                                        stop:1 #8995a3);
        }

        #sidebar, QFrame#Sidebar {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 rgba(38,42,48,0.98),
                                        stop:1 rgba(26,30,35,0.98));
            border-right: 1px solid rgba(255,255,255,0.12);
        }
        #content {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 rgba(63,70,80,0.96),
                                        stop:0.18 rgba(89,98,110,0.97),
                                        stop:0.52 rgba(113,124,137,0.97),
                                        stop:0.82 rgba(132,144,156,0.96),
                                        stop:1 rgba(143,154,166,0.95));
        }
        #top_pill {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 rgba(22,27,33,0.78),
                                        stop:0.18 rgba(52,61,72,0.68),
                                        stop:0.50 rgba(112,124,138,0.56),
                                        stop:0.82 rgba(54,63,74,0.68),
                                        stop:1 rgba(26,31,37,0.78));
            border: 1px solid rgba(255,255,255,0.26);
            border-radius: 16px;
            padding: 2px;
        }
        #top_title { color: #ffffff; font-weight: 800; }
        QLabel#Title { color: #ffffff; font-size: 18pt; font-weight: 700; }
        QLabel { color: #f7f8fa; background: transparent; }
        QFormLayout QLabel, QWidget[role="fieldLabel"] { background: transparent; border: none; }

        QDialog, QMessageBox {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                        stop:0 #40454c,
                                        stop:1 #2c3137);
        }

        QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateTimeEdit, QDateEdit, QTextEdit, QPlainTextEdit {
            background: #ffffff;
            color: #111111;
            border: 1px solid rgba(28,31,36,0.20);
            border-radius: 9px;
            padding: 6px 10px;
            selection-background-color: rgba(106,160,255,0.30);
            selection-color: #111111;
        }
        QLineEdit:focus, QComboBox:focus, QTextEdit:focus, QPlainTextEdit:focus {
            border: 1px solid #7ea4f4;
            background: #ffffff;
            color: #111111;
        }
        QComboBox QAbstractItemView {
            background: #ffffff;
            color: #111111;
            border: 1px solid rgba(28,31,36,0.20);
            selection-background-color: #dfe6ef;
            selection-color: #111111;
            outline: none;
        }
        QComboBox QAbstractItemView::item {
            background: #ffffff;
            color: #111111;
            padding: 6px 10px;
            min-height: 24px;
        }
        QComboBox QAbstractItemView::item:selected {
            background: #dfe6ef;
            color: #111111;
        }

        QToolButton, QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 rgba(255,255,255,0.18),
                                        stop:0.10 rgba(255,255,255,0.08),
                                        stop:0.11 rgba(63,72,82,0.90),
                                        stop:0.55 rgba(42,48,56,0.94),
                                        stop:1 rgba(26,31,37,0.96));
            color: #f8f9fb;
            border: 1px solid rgba(255,255,255,0.16);
            border-radius: 11px;
            padding: 7px 14px;
            font-weight: 650;
        }
        #sidebar QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 rgba(48,54,61,0.98),
                                        stop:1 rgba(29,34,40,0.98));
            color: #fbfbfc;
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 14px;
            padding: 11px 12px;
            font-weight: 650;
        }
        QToolButton:hover, QPushButton:hover,
        #sidebar QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 rgba(255,255,255,0.24),
                                        stop:0.10 rgba(255,255,255,0.12),
                                        stop:0.11 rgba(79,89,101,0.94),
                                        stop:0.55 rgba(53,60,69,0.96),
                                        stop:1 rgba(35,41,48,0.98));
            border: 1px solid rgba(180,210,255,0.42);
        }
        QToolButton:pressed, QPushButton:pressed,
        #sidebar QPushButton:pressed { background: rgba(23,27,32,0.98); }
        QPushButton:checked, #sidebar QPushButton:checked {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 rgba(59,78,105,0.98),
                                        stop:1 rgba(39,54,75,0.98));
            border: 1px solid rgba(145,185,255,0.70);
        }

        QTabWidget::pane {
            border: 1px solid rgba(255,255,255,0.18);
            border-radius: 14px;
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 rgba(255,255,255,0.10),
                                        stop:0.20 rgba(255,255,255,0.05),
                                        stop:0.55 rgba(255,255,255,0.02),
                                        stop:1 rgba(255,255,255,0.00));
        }
        QTabBar::tab {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 rgba(255,255,255,0.18),
                                        stop:0.10 rgba(255,255,255,0.10),
                                        stop:0.11 rgba(83,94,107,0.82),
                                        stop:0.55 rgba(54,62,72,0.76),
                                        stop:1 rgba(31,36,43,0.88));
            color: #f5f7fa;
            border: 1px solid rgba(255,255,255,0.24);
            border-bottom: none;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            padding: 8px 14px;
            margin-right: 3px;
        }
        QTabBar::tab:selected {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 rgba(255,255,255,0.30),
                                        stop:0.09 rgba(255,255,255,0.16),
                                        stop:0.10 rgba(109,122,138,0.78),
                                        stop:0.55 rgba(71,81,93,0.74),
                                        stop:1 rgba(41,47,55,0.84));
            border: 1px solid rgba(255,255,255,0.34);
        }

        QGroupBox {
            border: 1px solid rgba(255,255,255,0.12);
            border-radius: 10px;
            margin-top: 10px;
            padding-top: 10px;
            font-weight: 600;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 6px;
            color: #ffffff;
        }

        QScrollArea, QListView, QTreeView {
            background: transparent;
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 10px;
        }

        QTableView, QTableWidget {
            background: #ffffff;
            alternate-background-color: #ffffff;
            color: #111111;
            gridline-color: #d9dee4;
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 0px;
            outline: none;
        }
        QTableView::item, QTableWidget::item {
            background: #ffffff;
            color: #111111;
            padding: 4px 6px;
            border-right: 1px solid #e7ebf0;
            border-bottom: 1px solid #edf1f5;
        }
        QTableView::item:hover, QTableWidget::item:hover {
            background: #eef4ff;
            color: #111111;
        }
        QTableView::item:selected, QTableWidget::item:selected {
            background: #d8e6ff;
            color: #111111;
        }
        QHeaderView::section {
            background: #f5f7fa;
            color: #111111;
            padding: 7px 8px;
            border: none;
            border-right: 1px solid #dde3ea;
            border-bottom: 1px solid #d7dde4;
            font-weight: 700;
        }
        QHeaderView::section:hover { background: #edf3fb; }
        QTableView QHeaderView::section:vertical,
        QTableWidget QHeaderView::section:vertical {
            background: #ffffff;
            color: #111111;
            border-right: 1px solid #dde3ea;
            border-bottom: 1px solid #d7dde4;
        }

        QTableCornerButton::section {
            background: #ffffff;
            border: none;
            border-right: 1px solid #dde3ea;
            border-bottom: 1px solid #d7dde4;
        }

        QScrollBar:vertical {
            background: rgba(16,18,22,0.20);
            width: 10px;
            margin: 8px 2px 8px 2px;
            border-radius: 5px;
        }
        QScrollBar::handle:vertical {
            background: rgba(240,244,248,0.30);
            min-height: 28px;
            border-radius: 5px;
        }
        QScrollBar:horizontal {
            background: rgba(16,18,22,0.20);
            height: 10px;
            margin: 2px 8px 2px 8px;
            border-radius: 5px;
        }
        QScrollBar::handle:horizontal {
            background: rgba(240,244,248,0.30);
            min-width: 28px;
            border-radius: 5px;
        }
        QScrollBar::add-line, QScrollBar::sub-line,
        QScrollBar::add-page, QScrollBar::sub-page { background: transparent; border: none; }
    )QSS");

    return qss;
}

static QString qssLight()
{
    QString qss = QString::fromUtf8(R"QSS(
        QWidget { background: #f2f4f7; color: #14171a; font-size: 10.5pt; }
        #sidebar { background: #ffffff; border-right: 1px solid #d5dbe3; }
        #content { background: transparent; }
        #top_pill { background: #ffffff; border: 1px solid #d5dbe3; border-radius: 14px; }
        #top_title { color: #111; font-weight: 800; }
        QMainWindow { background: #f2f4f7; }
        QFrame#Sidebar { background: #ffffff; border-right: 1px solid #d5dbe3; }
        QLabel#Title { color: #111418; font-size: 18pt; font-weight: 700; }
        QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateTimeEdit, QDateEdit {
            background: #ffffff; border: 1px solid #d5dbe3; border-radius: 8px;
            padding: 6px 10px;
        }
        QLineEdit:focus, QComboBox:focus { border: 1px solid #2f6fed; }
        QComboBox QAbstractItemView {
            background: #ffffff;
            color: #14171a;
            border: 1px solid #d5dbe3;
            selection-background-color: #eef3ff;
            selection-color: #14171a;
            outline: none;
        }
        QComboBox QAbstractItemView::item {
            background: #ffffff;
            color: #14171a;
            padding: 6px 10px;
            min-height: 24px;
        }
        QComboBox QAbstractItemView::item:selected {
            background: #eef3ff;
            color: #14171a;
        }
        QTableView {
            background: #ffffff;
            alternate-background-color: #f7f9fc;
            gridline-color: #d5dbe3;
            border: 1px solid #d5dbe3;
            border-radius: 10px;
        }
        QHeaderView::section {
            background: #ffffff;
            color: #14171a;
            padding: 6px 8px;
            border: 0px;
            border-bottom: 1px solid #d5dbe3;
        }
        QToolButton, QPushButton {
            background: #ffffff;
            border: 1px solid #d5dbe3;
            border-radius: 10px;
            padding: 7px 12px;
        }
        QToolButton:hover, QPushButton:hover { background: #eef3ff; border: 1px solid #b7c6ff; }
        QToolButton:pressed, QPushButton:pressed { background: #e7ecf5; }
        QPushButton:checked { border: 1px solid #2f6fed; }
        QDialog { background: #f2f4f7; }
        QMessageBox { background: #f2f4f7; }
    )QSS");
    const bool whiteTables = Database::getSetting("settings.ui.white_tables", true).toBool();
    if (whiteTables) {
        qss += QString::fromUtf8(R"QSS(

QTableView, QTableWidget {
    background: #ffffff;
    alternate-background-color: #f2f2f2;
    color: #111;
    gridline-color: #d0d0d0;
    border: 1px solid #d0d0d0;
    border-radius: 10px;
}
QHeaderView::section {
    background: #f7f7f7;
    color: #111;
    padding: 6px 8px;
    border: 0px;
    border-bottom: 1px solid #d0d0d0;
}
QTableView::item:selected, QTableWidget::item:selected {
    background: rgba(106,160,255,0.25);
    color: #111;
}
)QSS");
    }
    return qss;
}

QString ThemeManager::currentTheme()
{
    QString t = Database::getSetting("ui.theme", "graphite").toString().trimmed().toLower();
    if (t != "light" && t != "graphite") t = "graphite";
    return t;
}

void ThemeManager::applySavedTheme()
{
    setTheme(currentTheme());
}

void ThemeManager::setTheme(const QString& name)
{
    const QString t = name.trimmed().toLower();
    if (t == "light") {
        qApp->setStyleSheet(qssLight());
        Database::setSetting("ui.theme", "light");
    } else {
        qApp->setStyleSheet(qssGraphite());
        Database::setSetting("ui.theme", "graphite");
    }
}
