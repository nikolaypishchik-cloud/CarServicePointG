#pragma once

#include <QDialog>
#include <QString>
#include "integrations/opendatabot/OpenDataBotClient.h"

class QShowEvent;

class QSpinBox;
class QDateTimeEdit;
class QComboBox;
class QLineEdit;
class QDoubleSpinBox;
class QCheckBox;
class QTableWidget;
class QPushButton;
class QLabel;
class QTabWidget;

class WorkPartsDialog;

class OrderDialog : public QDialog
{
    Q_OBJECT
public:
    explicit OrderDialog(QWidget* parent=nullptr, int orderNumber=-1);

    void setReadOnly(bool on);
    void openWorkPartsTab();
    void exportPdfPreviewAndOpen();

protected:
    void accept() override;
    void reject() override;
    void showEvent(QShowEvent* event) override;
    bool eventFilter(QObject* watched, QEvent* event) override;

private:
    void centerOnScreen();
    void lookupVehicleByPlateIfConfigured();
    void applyVehicleLookupResult(const OpenDataBotClient::VehicleLookupResult& result);

    void buildUi();
    void loadMasters();
    void editServiceMasters(int row);
    void loadOrder(int number);
    bool ensureDraftOrder();
    QString selectedFuelType() const;
    void setSelectedFuelType(const QString& fuelType);

    double servicesTotal() const;
    double partsTotal() const;

    void updateServiceRow(int row);
    void updatePartRow(int row);
    void refreshTotals();

    void exportPdf(const QString& outFile);

    int m_orderNumber = -1;
    bool m_readOnly = false;
    bool m_isNewOrder = false;
    bool m_draftCreated = false;
    bool m_vehicleLookupInProgress = false;
    bool m_vehicleLookupWarned = false;
    QString m_lastLookupPlate;

    QSpinBox* m_num = nullptr;
    QDateTimeEdit* m_opened = nullptr;
    QComboBox* m_status = nullptr;
    QLineEdit* m_plate = nullptr;
    QLineEdit* m_vin = nullptr;
    QLineEdit* m_car = nullptr;
    QLineEdit* m_color = nullptr;
    QSpinBox* m_year = nullptr;
    QSpinBox* m_odometer = nullptr;
    QLineEdit* m_engineCode = nullptr;
    QLineEdit* m_engineVolume = nullptr;
    QCheckBox* m_fuelDiesel = nullptr;
    QCheckBox* m_fuelPetrol = nullptr;
    QCheckBox* m_fuelHybrid = nullptr;
    QCheckBox* m_fuelElectric = nullptr;
    QLineEdit* m_client = nullptr;
    QLineEdit* m_phone = nullptr;
    QComboBox* m_master = nullptr;
    QDoubleSpinBox* m_discount = nullptr;

    QTabWidget* m_tabs = nullptr;
    WorkPartsDialog* m_workPartsPage = nullptr;

    QPushButton* m_btnPrint = nullptr;
    QPushButton* m_btnCopy = nullptr;
    QLabel* m_totals = nullptr;
};
