#include "ui/common/dialogs/MasterEditDialog.h"

#include <QFormLayout>
#include <QLineEdit>
#include <QComboBox>
#include <QDoubleSpinBox>
#include <QCheckBox>
#include <QDialogButtonBox>
#include <QVBoxLayout>
#include <QUuid>

MasterEditDialog::MasterEditDialog(QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle(QString::fromUtf8("Майстер"));

    auto* root = new QVBoxLayout(this);
    auto* form = new QFormLayout();
    form->setLabelAlignment(Qt::AlignRight);

    m_name = new QLineEdit(this);
    m_role = new QComboBox(this);
    m_role->addItem(QString::fromUtf8("Майстер"), "master");
    m_role->addItem(QString::fromUtf8("Адмін"), "admin");

    m_payrollPercent = new QDoubleSpinBox(this);
    m_payrollPercent->setRange(0, 100);
    m_payrollPercent->setDecimals(2);
    m_payrollPercent->setSuffix(QString::fromUtf8(" %"));

    m_adminPercent = new QDoubleSpinBox(this);
    m_adminPercent->setRange(0, 100);
    m_adminPercent->setDecimals(2);
    m_adminPercent->setSuffix(QString::fromUtf8(" %"));

    m_active = new QCheckBox(QString::fromUtf8("Активний"), this);
    m_active->setChecked(true);

    form->addRow(QString::fromUtf8("Ім'я:"), m_name);
    form->addRow(QString::fromUtf8("Роль:"), m_role);
    form->addRow(QString::fromUtf8("З/п %:"), m_payrollPercent);
    form->addRow(QString::fromUtf8("Адмін % (маржа):"), m_adminPercent);
    form->addRow(QString(), m_active);

    root->addLayout(form);

    auto* bb = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    root->addWidget(bb);

    connect(bb, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(bb, &QDialogButtonBox::rejected, this, &QDialog::reject);
    connect(m_role, &QComboBox::currentIndexChanged, this, &MasterEditDialog::onRoleChanged);

    // default
    m_id = QUuid::createUuid().toString(QUuid::WithoutBraces);
    onRoleChanged();
}

void MasterEditDialog::setData(const MasterRow& m, double payrollPercent)
{
    m_id = m.id;
    m_name->setText(m.name);
    int idx = m_role->findData(m.role);
    if (idx >= 0) m_role->setCurrentIndex(idx);
    m_adminPercent->setValue(m.adminPercent);
    m_payrollPercent->setValue(payrollPercent);
    m_active->setChecked(m.active);
    onRoleChanged();
}

MasterRow MasterEditDialog::data() const
{
    MasterRow m;
    m.id = m_id;
    m.name = m_name->text().trimmed();
    m.role = m_role->currentData().toString();
    m.adminPercent = m_adminPercent->value();
    m.active = m_active->isChecked();
    return m;
}

double MasterEditDialog::payrollPercent() const
{
    return m_payrollPercent->value();
}

void MasterEditDialog::onRoleChanged()
{
    const QString role = m_role->currentData().toString();
    const bool isAdmin = (role == "admin");
    m_adminPercent->setEnabled(isAdmin);
}
