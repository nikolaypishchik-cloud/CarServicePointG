#include "ui/common/dialogs/OrderDialog.h"

#include "ui/tabs/orders/WorkPartsDialog.h"

#include "infrastructure/db/sqlite/Db.h"
#include "core/util/PlateUtils.h"
#include "core/util/FormatUtils.h"
#include "integrations/opendatabot/OpenDataBotClient.h"

#include <QStringList>
#include <QRegularExpression>

namespace {
static QString toPlateDisplayLetters(QString s) {
    for (QChar& ch : s) {
        switch (ch.unicode()) {
            case 'A': ch = QChar(u'А'); break;
            case 'B': ch = QChar(u'В'); break;
            case 'C': ch = QChar(u'С'); break;
            case 'E': ch = QChar(u'Е'); break;
            case 'H': ch = QChar(u'Н'); break;
            case 'I': ch = QChar(u'І'); break;
            case 'K': ch = QChar(u'К'); break;
            case 'M': ch = QChar(u'М'); break;
            case 'O': ch = QChar(u'О'); break;
            case 'P': ch = QChar(u'Р'); break;
            case 'T': ch = QChar(u'Т'); break;
            case 'X': ch = QChar(u'Х'); break;
            default: break;
        }
    }
    return s;
}

static QString capitalizeSentence(QString s) {
    s = s.trimmed();
    if (s.isEmpty()) return s;
    // Uppercase first letter only (rest unchanged)
    const QChar first = s.at(0).toUpper();
    s[0] = first;
    return s;
}

static QString titleCaseWords(QString s) {
    s = s.trimmed();
    if (s.isEmpty()) return s;
    const auto parts = s.split(QRegularExpression("\\s+"), Qt::SkipEmptyParts);
    QStringList out;
    out.reserve(parts.size());
    for (QString p : parts) {
        if (p.contains('.')) {
            out << p.toUpper();
        } else if (!p.isEmpty()) {
            p[0] = p.at(0).toUpper();
            out << p;
        }
    }
    return out.join(' ');
}

static QString formatPlateProgressive(const QString& input)
{
    const QString norm = PlateUtils::normalizePlate(input);
    if (norm.isEmpty()) return QString();

    QString a1, nums, a2;
    for (const QChar& ch : norm) {
        if (ch.isLetter()) {
            if (a1.size() < 2 && nums.isEmpty() && a2.isEmpty()) a1 += ch;
            else if (!a1.isEmpty() && nums.size() >= 1 && a2.size() < 2) a2 += ch;
        } else if (ch.isDigit()) {
            if (a2.isEmpty() && nums.size() < 4) nums += ch;
        }
    }

    a1 = toPlateDisplayLetters(a1);
    a2 = toPlateDisplayLetters(a2);

    QString out;
    if (!a1.isEmpty()) out += a1;
    if (!nums.isEmpty()) {
        if (!out.isEmpty()) out += ' ';
        out += nums;
    }
    if (!a2.isEmpty()) {
        if (!out.isEmpty()) out += ' ';
        out += a2;
    }
    return out;
}
} // namespace

#include <QApplication>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QGridLayout>
#include <QLabel>
#include <QSpinBox>
#include <QDateTimeEdit>
#include <QComboBox>
#include <QLineEdit>
#include <QDoubleSpinBox>
#include <QCheckBox>
#include <QTableWidget>
#include <QHeaderView>
#include <QPushButton>
#include <QDialogButtonBox>
#include <QTabWidget>
#include <QWidget>
#include <QMessageBox>
#include <QPixmap>
#include <QFileInfo>
#include <QFileDialog>
#include <QDir>
#include <QStandardPaths>
#include <QUrl>
#include <QDesktopServices>
#include <QSqlQuery>
#include <QSqlError>
#include <QDateTime>
#include <QOverload>
#include <QList>
#include <QPdfWriter>
#include <QPageSize>
#include <QPageLayout>
#include <QPainter>
#include <QTimer>
#include <QSignalBlocker>
#include <QGuiApplication>
#include <QScreen>
#include <QShowEvent>
#include <QCursor>
#include <QWindow>
#include <QEvent>
#include <QMouseEvent>
#include <QFocusEvent>

static QString orderPdfPreviewPath(int orderNumber)
{
    QString baseDir = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
    if (baseDir.trimmed().isEmpty()) {
        baseDir = QDir::tempPath();
    }
    QDir dir(baseDir);
    dir.mkpath(QStringLiteral("pdf_preview"));
    return dir.filePath(QStringLiteral("pdf_preview/naryad_%1_preview.pdf").arg(orderNumber > 0 ? orderNumber : 0));
}

static bool openPdfFileSafely(const QString& outFile, QWidget* owner)
{
    const QString absPath = QFileInfo(outFile).absoluteFilePath();
    const auto topLevels = QApplication::topLevelWidgets();
    for (QWidget* w : topLevels) {
        if (!w || w == owner) continue;
        if (!w->isVisible()) continue;
        if (!w->isModal()) continue;
        if (owner && (w == owner->window() || w->isAncestorOf(owner) || owner->isAncestorOf(w))) {
            return false;
        }
    }
    return QDesktopServices::openUrl(QUrl::fromLocalFile(absPath));
}

static void setItem(QTableWidget* t, int r, int c, const QString& v)
{
    auto* it = new QTableWidgetItem(v);
    t->setItem(r, c, it);
}

static QString itemText(QTableWidget* t, int r, int c)
{
    if (!t) return QString();
    auto* it = t->item(r, c);
    return it ? it->text().trimmed() : QString();
}

static double itemDouble(QTableWidget* t, int r, int c)
{
    bool ok = false;
    double v = itemText(t, r, c).replace(',', '.').toDouble(&ok);
    return ok ? v : 0.0;
}

static QString labelStyle()
{
    return QString::fromUtf8("font-weight:700; color:#111111; padding-right:8px;");
}

static QString editorPlaceholderStyle()
{
    return QString::fromUtf8(
        "QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateTimeEdit { min-height: 28px; padding: 4px 10px; background:qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #f1f3f6, stop:0.45 #fafbfc, stop:0.55 #ffffff, stop:1 #e4e8ed); border:1px solid rgba(70,78,90,0.55); border-radius:12px; color:#101214; selection-background-color:#cfe3ff; }"
        " QLineEdit::placeholder, QAbstractSpinBox::placeholderText { color:#7a828d; }"
        " QCheckBox { spacing: 6px; }"
    );
}

static QString dialogMetallicStyle()
{
    return QString::fromUtf8(
        "QDialog#orderDialog {"
        " background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #48515c, stop:0.18 #5b6470, stop:0.32 #73808e, stop:0.38 #96a4b3, stop:0.45 #7a8795, stop:0.62 #66717d, stop:1 #858f9b);"
        "}"
        "QWidget#orderFormTab, QWidget#orderFormSurface, QWidget#orderFormShell { background:transparent; border:none; border-radius:0px; }"
        "QTabWidget::pane { background:transparent; border:none; top:-1px; }"
        "QTabBar::tab { color:#f5f7fa; font-weight:700; padding:10px 18px; margin-right:3px;"
        "  background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #3a4350, stop:0.5 #2d3540, stop:0.52 #6b7683, stop:0.64 #3a4350, stop:1 #27303a);"
        "  border:1px solid rgba(255,255,255,0.12); border-bottom:none; border-top-left-radius:12px; border-top-right-radius:12px; }"
        "QTabBar::tab:selected { color:#ffffff; background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #55606c, stop:0.18 #7f8c99, stop:0.35 #a9b7c5, stop:0.44 #d6dde6, stop:0.54 #8b98a5, stop:0.74 #596471, stop:1 #404955); }"
        "QTabBar::tab:!selected { margin-top:4px; }"
    );
}

static QString volumetricButtonStyle()
{
    return QString::fromUtf8(
        "QPushButton {"
        " color:#ffffff; font-weight:700;"
        " background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #3d4856, stop:0.48 #2c3440, stop:0.52 #1f2630, stop:1 #151b22);"
        " border:1px solid rgba(255,255,255,0.18); border-radius:16px;"
        " padding:8px 22px;"
        "}"
        "QPushButton:hover { background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #4b5766, stop:0.5 #333d4a, stop:1 #1c242d); }"
        "QPushButton:pressed { padding-top:10px; padding-bottom:6px; background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #1a2028, stop:1 #3a4654); }"
    );
}


static QStringList collectMissingRequiredOrderFields(QLineEdit* plate, QLineEdit* vin, QSpinBox* odometer, QDateTimeEdit* opened);

static QString requiredFieldsWarning(const QStringList& missing)
{
    if (missing.isEmpty()) return QString();
    return QString::fromUtf8("Не введено: %1").arg(missing.join(QString::fromUtf8(", ")));
}

static QString flatOrderFieldStyle()
{
    return QString::fromUtf8(
        "QComboBox::drop-down, QDateTimeEdit::drop-down { width: 0px; border: none; }"
        "QComboBox::down-arrow, QDateTimeEdit::down-arrow { image: none; width: 0px; height: 0px; }"
        "QSpinBox::up-button, QSpinBox::down-button, QDoubleSpinBox::up-button, QDoubleSpinBox::down-button { width: 0px; border: none; }"
        "QSpinBox::up-arrow, QSpinBox::down-arrow, QDoubleSpinBox::up-arrow, QDoubleSpinBox::down-arrow { image: none; width: 0px; height: 0px; }"
    );
}

OrderDialog::OrderDialog(QWidget* parent, int orderNumber)
    : QDialog(parent), m_orderNumber(orderNumber), m_isNewOrder(orderNumber <= 0)
{
    setModal(true);
    setWindowFlag(Qt::WindowMaximizeButtonHint, true);

    setObjectName(QStringLiteral("orderDialog"));
    if (m_isNewOrder) {
        resize(1180, 646);
        setMinimumSize(980, 620);
    } else {
        resize(1480, 860);
        setMinimumSize(1220, 720);
    }
    setStyleSheet(dialogMetallicStyle());

    buildUi();
    if (windowTitle().isEmpty()) {
        setWindowTitle(m_isNewOrder ? QString::fromUtf8("Новий наряд (додати авто)") : QString::fromUtf8("Редагування наряду"));
    }
    if (!m_isNewOrder) {
        QTimer::singleShot(0, this, [this] { showMaximized(); });
    }
    loadMasters();

    if (m_orderNumber > 0) {
        loadOrder(m_orderNumber);
        m_num->setValue(m_orderNumber);
        m_num->setEnabled(false);
    } else if (m_num) {
        m_num->setValue(0);
    }
}


void OrderDialog::buildUi()
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(6,6,6,6);
    root->setSpacing(4);
    root->setSizeConstraint(QLayout::SetNoConstraint);

    auto* formTab = new QWidget(this);
    formTab->setObjectName(QStringLiteral("orderFormTab"));
    formTab->setAttribute(Qt::WA_StyledBackground, true);
    auto* formRoot = new QVBoxLayout(formTab);
    formRoot->setContentsMargins(0,0,0,0);
    formRoot->setSpacing(2);

    auto* formShell = new QWidget(this);
    formShell->setObjectName(QStringLiteral("orderFormShell"));
    formShell->setAttribute(Qt::WA_StyledBackground, true);
    auto* shellLay = new QHBoxLayout(formShell);
    shellLay->setContentsMargins(0, 0, 0, 0);
    shellLay->setSpacing(0);

    auto* formPane = new QWidget(formShell);
    formPane->setObjectName(QStringLiteral("orderFormSurface"));
    formPane->setAttribute(Qt::WA_StyledBackground, true);
    formPane->setMaximumWidth(QWIDGETSIZE_MAX);
    formPane->setMinimumWidth(900);
    auto* grid = new QGridLayout(formPane);
    grid->setContentsMargins(0, 0, 0, 0);
    grid->setHorizontalSpacing(12);
    grid->setVerticalSpacing(6);
    grid->setColumnMinimumWidth(0, 260);
    grid->setColumnMinimumWidth(1, 590);
    grid->setColumnMinimumWidth(2, 220);
    grid->setColumnStretch(0, 0);
    grid->setColumnStretch(1, 7);
    grid->setColumnStretch(2, 3);

    int row = 0;
    auto addFullRow = [&](const QString& label, QWidget* editor) {
        auto* lbl = new QLabel(label, formPane);
        lbl->setStyleSheet(labelStyle());
        lbl->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        lbl->setMinimumWidth(250);
        lbl->setContentsMargins(0, 0, 10, 0);
        editor->setStyleSheet(editor->styleSheet() + editorPlaceholderStyle());
        grid->addWidget(lbl, row, 0, Qt::AlignRight | Qt::AlignVCenter);
        grid->addWidget(editor, row, 1, 1, 2);
        ++row;
    };

    m_num = new QSpinBox(this);
    m_num->setRange(0, 9999999);
    m_num->setSpecialValueText(QString::fromUtf8("Авто"));
    m_num->setToolTip(QString::fromUtf8("0 = автоматичний номер наряду"));
    m_num->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_num->setStyleSheet(editorPlaceholderStyle() + flatOrderFieldStyle());

    m_opened = new QDateTimeEdit(QDateTime::currentDateTime(), this);
    m_opened->setCalendarPopup(true);
    m_opened->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_opened->setDisplayFormat(QString::fromUtf8("dd.MM.yy HH:mm"));
    m_opened->setStyleSheet(editorPlaceholderStyle() + flatOrderFieldStyle());

    m_status = new QComboBox(this);
    m_status->addItem("open");
    m_status->addItem("in_progress");
    m_status->addItem("closed");
    m_status->setStyleSheet(editorPlaceholderStyle() + flatOrderFieldStyle());

    m_plate = new QLineEdit(this);
    m_plate->setPlaceholderText(QString::fromUtf8("Напр: AA 1234 BC"));

    m_vin = new QLineEdit(this);
    m_vin->setPlaceholderText(QString::fromUtf8("VIN (обов'язково)"));

    m_car = new QLineEdit(this);
    m_car->setPlaceholderText(QString::fromUtf8("Напр: Volvo XC60"));

    m_color = new QLineEdit(this);
    m_color->setPlaceholderText(QString::fromUtf8("Напр: Чорний"));

    m_year = new QSpinBox(this);
    m_year->setRange(1950, 2100);
    m_year->setSpecialValueText(QString());
    m_year->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_year->setStyleSheet(editorPlaceholderStyle() + flatOrderFieldStyle());
    m_year->setValue(m_year->minimum());
    m_year->clear();

    m_odometer = new QSpinBox(this);
    m_odometer->setRange(0, 2000000);
    m_odometer->setSingleStep(1000);
    m_odometer->setGroupSeparatorShown(true);
    m_odometer->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_odometer->setStyleSheet(editorPlaceholderStyle() + flatOrderFieldStyle());
    m_odometer->setValue(m_odometer->minimum());
    m_odometer->clear();

    m_engineCode = new QLineEdit(this);
    m_engineCode->setPlaceholderText(QString::fromUtf8("Маркування двигуна (напр: D4, B5204T)"));

    m_engineVolume = new QLineEdit(this);
    m_engineVolume->setPlaceholderText(QString::fromUtf8("Об'єм (напр: 2.0)"));

    m_client = new QLineEdit(this);
    m_client->setPlaceholderText(QString::fromUtf8("ПІБ клієнта"));

    m_phone = new QLineEdit(this);
    m_phone->setPlaceholderText(QString::fromUtf8("Напр: +380501234567"));

    m_master = new QComboBox(this);
    m_master->setStyleSheet(editorPlaceholderStyle() + flatOrderFieldStyle());

    m_discount = new QDoubleSpinBox(this);
    m_discount->setRange(0, 1000000);
    m_discount->setDecimals(2);
    m_discount->setSuffix(QString::fromUtf8(" грн"));
    m_discount->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_discount->setStyleSheet(editorPlaceholderStyle() + flatOrderFieldStyle());
    m_discount->installEventFilter(this);
    m_discount->clear();

    auto capitalizeFirst = [](QString s) -> QString {
        s = s.trimmed();
        if (s.isEmpty()) return s;
        s[0] = s[0].toUpper();
        return s;
    };
    connect(m_plate, &QLineEdit::textChanged, this, [this](const QString& text) {
        if (!m_plate) return;
        const QString formatted = formatPlateProgressive(text);
        if (formatted == text) return;
        const int oldCursor = m_plate->cursorPosition();
        const int trailing = static_cast<int>(text.size()) - oldCursor;
        QSignalBlocker blocker(m_plate);
        m_plate->setText(formatted);
        const int formattedSize = static_cast<int>(formatted.size());
        const int newPos = std::max(0, formattedSize - trailing);
        m_plate->setCursorPosition(std::min(newPos, formattedSize));
    });
    connect(m_plate, &QLineEdit::editingFinished, this, [this]() {
        const auto norm = PlateUtils::normalizePlate(m_plate->text());
        m_plate->setText(PlateUtils::formatPlateDisplay(norm));
        lookupVehicleByPlateIfConfigured();
    });
    connect(m_vin, &QLineEdit::editingFinished, this, [this]() {
        m_vin->setText(m_vin->text().trimmed().toUpper());
    });
    connect(m_car, &QLineEdit::editingFinished, this, [this, capitalizeFirst]() {
        m_car->setText(capitalizeFirst(m_car->text()));
    });
    connect(m_color, &QLineEdit::editingFinished, this, [this, capitalizeFirst]() {
        m_color->setText(capitalizeFirst(m_color->text()));
    });
    connect(m_client, &QLineEdit::editingFinished, this, [this, capitalizeFirst]() {
        m_client->setText(capitalizeSentence(m_client->text()));
    });

    addFullRow(QString::fromUtf8("№ наряду:"), m_num);
    addFullRow(QString::fromUtf8("Відкрито:"), m_opened);
    addFullRow(QString::fromUtf8("Статус:"), m_status);
    addFullRow(QString::fromUtf8("Номер авто:"), m_plate);
    addFullRow(QString::fromUtf8("VIN:"), m_vin);
    addFullRow(QString::fromUtf8("Авто (марка/модель):"), m_car);
    addFullRow(QString::fromUtf8("Колір:"), m_color);
    addFullRow(QString::fromUtf8("Рік випуску:"), m_year);
    addFullRow(QString::fromUtf8("Одометр (км):"), m_odometer);

    auto* engineLabel = new QLabel(QString::fromUtf8("Двигун (маркування / об'єм):"), formPane);
    engineLabel->setStyleSheet(labelStyle());
    engineLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    engineLabel->setMinimumWidth(250);
    engineLabel->setContentsMargins(0, 0, 10, 0);
    m_engineCode->setStyleSheet(editorPlaceholderStyle());
    m_engineVolume->setStyleSheet(editorPlaceholderStyle());
    m_engineCode->setMinimumHeight(24);
    m_engineVolume->setMinimumHeight(24);
    grid->addWidget(engineLabel, row, 0, Qt::AlignRight | Qt::AlignVCenter);
    grid->addWidget(m_engineCode, row, 1);
    grid->addWidget(m_engineVolume, row, 2);
    ++row;

    auto* fuelLabel = new QLabel(QString::fromUtf8("Пальне:"), formPane);
    fuelLabel->setStyleSheet(labelStyle());
    fuelLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    fuelLabel->setMinimumWidth(250);
    fuelLabel->setContentsMargins(0, 0, 10, 0);
    auto* fuelWrap = new QWidget(formPane);
    auto* fuelLay = new QHBoxLayout(fuelWrap);
    fuelLay->setContentsMargins(0,0,0,0);
    fuelLay->setSpacing(12);
    m_fuelDiesel = new QCheckBox(QString::fromUtf8("Дизель"), fuelWrap);
    m_fuelPetrol = new QCheckBox(QString::fromUtf8("Бензин (газ)"), fuelWrap);
    m_fuelHybrid = new QCheckBox(QString::fromUtf8("Гібрид"), fuelWrap);
    m_fuelElectric = new QCheckBox(QString::fromUtf8("Електро"), fuelWrap);
    for (auto* cb : {m_fuelDiesel, m_fuelPetrol, m_fuelHybrid, m_fuelElectric}) {
        cb->setStyleSheet(QString::fromUtf8("QCheckBox { color:#111111; font-size:14px; font-weight:600; }"));
        fuelLay->addWidget(cb);
        connect(cb, &QCheckBox::clicked, this, [this, cb](bool checked) {
            if (!checked) return;
            for (auto* other : {m_fuelDiesel, m_fuelPetrol, m_fuelHybrid, m_fuelElectric}) {
                if (other && other != cb) other->setChecked(false);
            }
        });
    }
    fuelLay->addStretch(1);
    grid->addWidget(fuelLabel, row, 0, Qt::AlignRight | Qt::AlignVCenter);
    grid->addWidget(fuelWrap, row, 1, 1, 2);
    ++row;

    addFullRow(QString::fromUtf8("Клієнт:"), m_client);
    addFullRow(QString::fromUtf8("Телефон:"), m_phone);
    addFullRow(QString::fromUtf8("Майстер:"), m_master);
    addFullRow(QString::fromUtf8("Знижка:"), m_discount);
    grid->setRowStretch(row, 1);

    shellLay->addWidget(formPane, 1, Qt::AlignTop);

    formRoot->addWidget(formShell);

    m_tabs = new QTabWidget(this);
    m_tabs->addTab(formTab, m_isNewOrder ? QString::fromUtf8("Дані нового наряду") : QString::fromUtf8("Дані наряду"));

    if (!m_isNewOrder) {
    auto* workTab = new QWidget(this);
    auto* workLay = new QVBoxLayout(workTab);
    workLay->setContentsMargins(0,0,0,0);
    m_workPartsPage = new WorkPartsDialog(workTab, m_orderNumber);
    m_workPartsPage->setEmbedded(true);
    m_workPartsPage->setMinimumSize(0, 0);
    m_workPartsPage->setMaximumSize(QWIDGETSIZE_MAX, QWIDGETSIZE_MAX);
    workLay->addWidget(m_workPartsPage, 1);
    connect(m_workPartsPage, &WorkPartsDialog::requestPdf, this, [this]() {
        const QString outFile = orderPdfPreviewPath(m_orderNumber > 0 ? m_orderNumber : (m_num ? m_num->value() : 0));
        exportPdf(outFile);
        openPdfFileSafely(outFile, this);
    });
    connect(m_workPartsPage, &WorkPartsDialog::requestCloseOrder, this, [this]() {
        const int idx = m_status->findText(QStringLiteral("closed"));
        if (idx >= 0) m_status->setCurrentIndex(idx);
        accept();
    });
    m_tabs->addTab(workTab, QString::fromUtf8("Роботи та запчастини"));
    }
    root->addWidget(m_tabs, 1);

    auto* buttonsRow = new QHBoxLayout();
    buttonsRow->setContentsMargins(0, 0, 0, 0);
    buttonsRow->setSpacing(8);
    buttonsRow->addStretch(1);
    auto* btnOk = new QPushButton(QStringLiteral("OK"), this);
    auto* btnCancel = new QPushButton(QString::fromUtf8("Скасувати"), this);
    btnOk->setMinimumWidth(128);
    btnCancel->setMinimumWidth(128);
    btnOk->setMinimumHeight(36);
    btnCancel->setMinimumHeight(36);
    btnOk->setStyleSheet(volumetricButtonStyle());
    btnCancel->setStyleSheet(volumetricButtonStyle());
    buttonsRow->addWidget(btnOk);
    buttonsRow->addWidget(btnCancel);
    root->addLayout(buttonsRow);

    connect(btnOk, &QPushButton::clicked, this, &OrderDialog::accept);
    connect(btnCancel, &QPushButton::clicked, this, &OrderDialog::reject);

    connect(m_tabs, &QTabWidget::currentChanged, this, [this](int index) {
        if (!m_tabs || index != 1) return;
        if (ensureDraftOrder() && m_workPartsPage) {
            m_workPartsPage->raise();
            refreshTotals();
        } else if (m_tabs) {
            m_tabs->setCurrentIndex(0);
        }
    });

    refreshTotals();
}



void OrderDialog::lookupVehicleByPlateIfConfigured()
{
    if (!m_isNewOrder || m_readOnly || m_vehicleLookupInProgress || !m_plate) {
        return;
    }

    const QString plate = PlateUtils::normalizePlate(m_plate->text());
    if (plate.isEmpty()) {
        return;
    }

    if (!OpenDataBotClient::isConfigured()) {
        return;
    }

    if (plate == m_lastLookupPlate && ((m_vin && !m_vin->text().trimmed().isEmpty()) || (m_car && !m_car->text().trimmed().isEmpty()))) {
        return;
    }

    m_vehicleLookupInProgress = true;
    m_lastLookupPlate = plate;

    OpenDataBotClient::lookupByPlate(this, plate, [this, plate](const OpenDataBotClient::VehicleLookupResult& result) {
        m_vehicleLookupInProgress = false;
        if (plate != m_lastLookupPlate) {
            return;
        }

        if (!result.success) {
            if (!m_vehicleLookupWarned) {
                m_vehicleLookupWarned = true;
                QMessageBox::warning(this,
                                     QString::fromUtf8("OpenDataBot"),
                                     result.error.isEmpty()
                                         ? QString::fromUtf8("Не вдалося автоматично отримати дані авто за держномером.")
                                         : result.error);
            }
            return;
        }

        m_vehicleLookupWarned = false;
        applyVehicleLookupResult(result);
    });
}

void OrderDialog::applyVehicleLookupResult(const OpenDataBotClient::VehicleLookupResult& result)
{
    if (m_vin && m_vin->text().trimmed().isEmpty() && !result.vin.isEmpty()) {
        m_vin->setText(result.vin.trimmed().toUpper());
    }
    if (m_car && m_car->text().trimmed().isEmpty() && !result.carDisplay.isEmpty()) {
        m_car->setText(titleCaseWords(result.carDisplay));
    }
    if (m_color && m_color->text().trimmed().isEmpty() && !result.color.isEmpty()) {
        m_color->setText(capitalizeSentence(result.color));
    }
    if (m_year && m_year->value() <= m_year->minimum() && result.year > 0) {
        m_year->setValue(result.year);
    }
    if (m_engineVolume && m_engineVolume->text().trimmed().isEmpty() && !result.engineVolume.isEmpty()) {
        m_engineVolume->setText(result.engineVolume.trimmed());
    }
    if (!result.fuelType.isEmpty()) {
        setSelectedFuelType(result.fuelType);
    }
}


QString OrderDialog::selectedFuelType() const
{
    if (m_fuelDiesel && m_fuelDiesel->isChecked()) return QString::fromUtf8("Дизель");
    if (m_fuelPetrol && m_fuelPetrol->isChecked()) return QString::fromUtf8("Бензин (газ)");
    if (m_fuelHybrid && m_fuelHybrid->isChecked()) return QString::fromUtf8("Гібрид");
    if (m_fuelElectric && m_fuelElectric->isChecked()) return QString::fromUtf8("Електро");
    return QString::fromUtf8("Не вказано");
}

void OrderDialog::setSelectedFuelType(const QString& fuelType)
{
    for (auto* cb : {m_fuelDiesel, m_fuelPetrol, m_fuelHybrid, m_fuelElectric}) {
        if (cb) cb->setChecked(false);
    }
    const QString t = fuelType.trimmed();
    if (m_fuelDiesel && (t.compare(QString::fromUtf8("Дизель"), Qt::CaseInsensitive) == 0 || t.compare(QStringLiteral("diesel"), Qt::CaseInsensitive) == 0)) m_fuelDiesel->setChecked(true);
    else if (m_fuelPetrol && (t.contains(QString::fromUtf8("Бенз"), Qt::CaseInsensitive) || t.compare(QStringLiteral("petrol"), Qt::CaseInsensitive) == 0 || t.compare(QStringLiteral("gas"), Qt::CaseInsensitive) == 0)) m_fuelPetrol->setChecked(true);
    else if (m_fuelHybrid && (t.compare(QString::fromUtf8("Гібрид"), Qt::CaseInsensitive) == 0 || t.compare(QStringLiteral("hybrid"), Qt::CaseInsensitive) == 0)) m_fuelHybrid->setChecked(true);
    else if (m_fuelElectric && (t.compare(QString::fromUtf8("Електро"), Qt::CaseInsensitive) == 0 || t.compare(QStringLiteral("electric"), Qt::CaseInsensitive) == 0)) m_fuelElectric->setChecked(true);
}

void OrderDialog::loadMasters()
{
    m_master->clear();
    auto list = Database::masters(true);
    for (const auto& m : list) {
        m_master->addItem(m.name, m.id);
    }
}

void OrderDialog::loadOrder(int number)
{
    QSqlQuery q(Database::db());
    q.prepare("SELECT number, opened_at, status, plate, vin, car, color, car_year, odometer, engine_type, engine_volume, fuel_type, client, client_phone, master_id, discount FROM work_orders WHERE number=?");
    q.addBindValue(number);
    if (!q.exec() || !q.next()) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Наряд не знайдено"));
        return;
    }

    m_opened->setDateTime(QDateTime::fromString(q.value(1).toString(), Qt::ISODate));
    const QString status = q.value(2).toString();
    int si = m_status->findText(status);
    if (si >= 0) m_status->setCurrentIndex(si);
    m_plate->setText(q.value(3).toString());
    m_vin->setText(q.value(4).toString());
    m_car->setText(q.value(5).toString());
    if (m_color) m_color->setText(q.value(6).toString());
    if (m_year) m_year->setValue(q.value(7).toInt());
    if (m_odometer) m_odometer->setValue(q.value(8).toInt());
    if (m_engineCode) m_engineCode->setText(q.value(9).toString());
    if (m_engineVolume) m_engineVolume->setText(q.value(10).toString());
    setSelectedFuelType(q.value(11).toString());
    m_client->setText(q.value(12).toString());
    m_phone->setText(q.value(13).toString());

    const QString mid = q.value(14).toString();
    int mi = m_master->findData(mid);
    if (mi >= 0) m_master->setCurrentIndex(mi);

    m_discount->setValue(q.value(15).toDouble());

refreshTotals();
}

void OrderDialog::setReadOnly(bool on)
{
    m_readOnly = on;

    const QList<QWidget*> fields = {m_opened, m_status, m_plate, m_vin, m_car, m_color, m_year, m_odometer, m_engineCode, m_engineVolume, m_fuelDiesel, m_fuelPetrol, m_fuelHybrid, m_fuelElectric, m_client, m_phone, m_master, m_discount};
    for (QWidget* w : fields) {
        if (!w) continue;
        w->setEnabled(!on);
    }
    if (m_num) m_num->setEnabled(false);
    if (m_workPartsPage) m_workPartsPage->setEnabled(!on);
}


void OrderDialog::exportPdfPreviewAndOpen()
{
    const QString outFile = orderPdfPreviewPath(m_orderNumber > 0 ? m_orderNumber : (m_num ? m_num->value() : 0));
    exportPdf(outFile);
    openPdfFileSafely(outFile, this);
}

void OrderDialog::openWorkPartsTab()
{
    if (m_tabs) {
        if (ensureDraftOrder()) {
            m_tabs->setCurrentIndex(1);
        }
    }
}

bool OrderDialog::ensureDraftOrder()
{
    if (m_orderNumber > 0) {
        return true;
    }

    int number = m_num ? m_num->value() : 0;
    QString plate = m_plate ? m_plate->text().trimmed() : QString();
    QString vin = m_vin ? m_vin->text().trimmed().toUpper() : QString();
    QString car = m_car ? m_car->text().trimmed() : QString();
    QString color = m_color ? m_color->text().trimmed() : QString();
    const int carYear = m_year ? m_year->value() : 0;
    const int odometer = m_odometer ? m_odometer->value() : 0;
    const QString engineType = m_engineCode ? m_engineCode->text().trimmed() : QString();
    const QString engineVolume = m_engineVolume ? m_engineVolume->text().trimmed() : QString();
    const QString fuelType = selectedFuelType();
    QString client = m_client ? m_client->text().trimmed() : QString();
    const QString phone = m_phone ? m_phone->text().trimmed() : QString();
    const QString masterId = m_master ? m_master->currentData().toString() : QString();

    const QStringList missing = collectMissingRequiredOrderFields(m_plate, m_vin, m_odometer, m_opened);
    if (!missing.isEmpty()) {
        QMessageBox::warning(this,
                             QString::fromUtf8("Обов'язкові поля не заповнені"),
                             requiredFieldsWarning(missing));
        if (m_tabs) m_tabs->setCurrentIndex(0);
        if (m_plate && m_plate->text().trimmed().isEmpty()) m_plate->setFocus();
        else if (m_vin && m_vin->text().trimmed().isEmpty()) m_vin->setFocus();
        else if (m_odometer && m_odometer->value() <= 0) m_odometer->setFocus();
        else if (m_opened) m_opened->setFocus();
        return false;
    }

    if (masterId.trimmed().isEmpty()) {
        QMessageBox::warning(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Оберіть майстра перед додаванням робіт або запчастин"));
        return false;
    }

    QSqlDatabase db = Database::db();
    if (!db.transaction()) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не можу відкрити транзакцію БД"));
        return false;
    }

    if (number <= 0) {
        QSqlQuery qn(db);
        if (!qn.exec("SELECT COALESCE(MAX(number),0) + 1 FROM work_orders")) {
            db.rollback();
            QMessageBox::critical(this, QString::fromUtf8("Помилка БД"), qn.lastError().text());
            return false;
        }
        if (qn.next()) number = qn.value(0).toInt();
    }

    const QString plateNorm = PlateUtils::normalizePlate(plate);
    plate = PlateUtils::formatPlateDisplay(plateNorm);
    vin = vin.trimmed().toUpper();
    car = titleCaseWords(car);
    color = capitalizeSentence(color);
    client = titleCaseWords(client);
    if (plate.isNull()) plate = QStringLiteral("");
    if (car.isNull()) car = QStringLiteral("");
    if (client.isNull()) client = QStringLiteral("");

    QSqlQuery q(db);
    q.prepare("INSERT INTO work_orders(number, opened_at, status, plate, plate_norm, vin, car, color, car_year, odometer, engine_type, engine_volume, fuel_type, client, client_phone, master_id, works_sum, parts_sum, discount) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    q.addBindValue(number);
    q.addBindValue((m_opened ? m_opened->dateTime() : QDateTime::currentDateTime()).toString(Qt::ISODate));
    q.addBindValue(m_status ? m_status->currentText() : QStringLiteral("open"));
    q.addBindValue(plate);
    q.addBindValue(plateNorm);
    q.addBindValue(vin);
    q.addBindValue(car);
    q.addBindValue(color);
    q.addBindValue(carYear);
    q.addBindValue(odometer);
    q.addBindValue(engineType);
    q.addBindValue(engineVolume);
    q.addBindValue(fuelType);
    q.addBindValue(client);
    q.addBindValue(phone);
    q.addBindValue(masterId);
    q.addBindValue(0.0);
    q.addBindValue(0.0);
    q.addBindValue(m_discount ? m_discount->value() : 0.0);
    if (!q.exec()) {
        db.rollback();
        QMessageBox::critical(this, QString::fromUtf8("Помилка БД"), q.lastError().text());
        return false;
    }

    if (!db.commit()) {
        db.rollback();
        QMessageBox::critical(this, QString::fromUtf8("Помилка БД"), QString::fromUtf8("Commit не вдався"));
        return false;
    }

    m_orderNumber = number;
    m_draftCreated = true;
    if (m_num) {
        m_num->setValue(number);
        m_num->setEnabled(false);
    }
    if (m_plate) m_plate->setText(plate);
    if (m_vin) m_vin->setText(vin);
    if (m_car) m_car->setText(car);
    if (m_color) m_color->setText(color);
    if (m_client) m_client->setText(client);

    if (m_workPartsPage) {
        delete m_workPartsPage;
        m_workPartsPage = nullptr;
        auto* tab = m_tabs->widget(1);
        auto* layout = qobject_cast<QVBoxLayout*>(tab->layout());
        m_workPartsPage = new WorkPartsDialog(tab, m_orderNumber);
        m_workPartsPage->setEmbedded(true);
        layout->addWidget(m_workPartsPage, 1);
        connect(m_workPartsPage, &WorkPartsDialog::requestOk, this, &OrderDialog::accept);
        connect(m_workPartsPage, &WorkPartsDialog::requestCancel, this, &OrderDialog::reject);
        connect(m_workPartsPage, &WorkPartsDialog::requestPdf, this, [this]() {
            const QString outFile = orderPdfPreviewPath(m_orderNumber);
            exportPdf(outFile);
            openPdfFileSafely(outFile, this);
        });
        connect(m_workPartsPage, &WorkPartsDialog::requestCloseOrder, this, [this]() {
            const int idx = m_status->findText(QStringLiteral("closed"));
            if (idx >= 0) m_status->setCurrentIndex(idx);
            accept();
        });
    }

    refreshTotals();
    return true;
}



static QStringList collectMissingRequiredOrderFields(QLineEdit* plate, QLineEdit* vin, QSpinBox* odometer, QDateTimeEdit* opened)
{
    QStringList missing;
    if (!plate || plate->text().trimmed().isEmpty()) {
        missing << QString::fromUtf8("номер авто");
    }
    if (!vin || vin->text().trimmed().isEmpty()) {
        missing << QString::fromUtf8("VIN номер");
    }
    if (!odometer || odometer->value() <= 0) {
        missing << QString::fromUtf8("одометр авто");
    }
    if (!opened || !opened->dateTime().isValid()) {
        missing << QString::fromUtf8("дату та час відкриття");
    }
    return missing;
}

void OrderDialog::showEvent(QShowEvent* event)
{
    QDialog::showEvent(event);
    if (!isMaximized()) {
        centerOnScreen();
    }
    if (m_plate) {
        QTimer::singleShot(0, m_plate, [this]() {
            if (!m_plate) return;
            m_plate->setFocus(Qt::OtherFocusReason);
            m_plate->selectAll();
        });
    }
}

bool OrderDialog::eventFilter(QObject* watched, QEvent* event)
{
    if (watched == m_discount && m_discount) {
        if (event->type() == QEvent::FocusIn || event->type() == QEvent::MouseButtonPress) {
            if (qFuzzyIsNull(m_discount->value())) {
                m_discount->clear();
                if (auto* le = m_discount->findChild<QLineEdit*>()) {
                    QTimer::singleShot(0, le, [le]() {
                        le->setCursorPosition(0);
                        le->deselect();
                    });
                }
            }
        }
    }
    return QDialog::eventFilter(watched, event);
}

void OrderDialog::centerOnScreen()
{
    QScreen* screen = nullptr;
    if (parentWidget() && parentWidget()->windowHandle() && parentWidget()->windowHandle()->screen()) {
        screen = parentWidget()->windowHandle()->screen();
    }
    if (!screen && windowHandle() && windowHandle()->screen()) {
        screen = windowHandle()->screen();
    }
    if (!screen) {
        screen = QGuiApplication::screenAt(QCursor::pos());
    }
    if (!screen) {
        screen = QGuiApplication::primaryScreen();
    }
    if (!screen) return;

    const QRect available = screen->availableGeometry();
    const QRect frame = frameGeometry();
    move(available.left() + (available.width() - frame.width()) / 2,
         available.top() + (available.height() - frame.height()) / 2);
}

void OrderDialog::reject()
{
    if (m_isNewOrder && m_draftCreated && m_orderNumber > 0) {
        QSqlDatabase db = Database::db();
        if (db.transaction()) {
            QSqlQuery q1(db);
            q1.prepare("DELETE FROM work_order_parts WHERE order_number=?");
            q1.addBindValue(m_orderNumber);
            q1.exec();

            QSqlQuery q2(db);
            q2.prepare("DELETE FROM work_order_services WHERE order_number=?");
            q2.addBindValue(m_orderNumber);
            q2.exec();

            QSqlQuery q3(db);
            q3.prepare("DELETE FROM work_orders WHERE number=?");
            q3.addBindValue(m_orderNumber);
            q3.exec();
            db.commit();
        }
    }
    QDialog::reject();
}



double OrderDialog::servicesTotal() const
{
    QSqlQuery q(Database::db());
    q.prepare("SELECT COALESCE(SUM(qty*price),0) FROM work_order_services WHERE order_number=?");
    q.addBindValue(m_orderNumber);
    if (!q.exec() || !q.next()) return 0.0;
    return q.value(0).toDouble();
}



double OrderDialog::partsTotal() const
{
    QSqlQuery q(Database::db());
    q.prepare("SELECT COALESCE(SUM(qty*price),0) FROM work_order_parts WHERE order_number=?");
    q.addBindValue(m_orderNumber);
    if (!q.exec() || !q.next()) return 0.0;
    return q.value(0).toDouble();
}



void OrderDialog::refreshTotals()
{
    if (!m_totals) return;
    const double w = servicesTotal();
    const double p = partsTotal();
    const double disc = m_discount ? m_discount->value() : 0.0;
    const double total = qMax(0.0, w + p - disc);

    m_totals->setText(
        QString::fromUtf8("Роботи: %1 грн   |   Запчастини: %2 грн   |   Знижка: %3 грн   |   Разом: %4 грн")
            .arg(FormatUtils::money(w, 2),
                 FormatUtils::money(p, 2),
                 FormatUtils::money(disc, 2),
                 FormatUtils::money(total, 2))
    );
}

void OrderDialog::exportPdf(const QString& outFile)
{
    QPdfWriter pdf(outFile);
    pdf.setPageSize(QPageSize(QPageSize::A4));
    pdf.setResolution(144);
    pdf.setPageMargins(QMarginsF(20, 10, 10, 10), QPageLayout::Millimeter);

    QPainter p(&pdf);
    p.setRenderHint(QPainter::Antialiasing, true);
    p.setRenderHint(QPainter::TextAntialiasing, true);

    const QRect page = p.viewport();
    const int left = 28;                   // widened ~5 mm from left edge
    const int right = page.width() - 1;    // widened to near right edge
    const int width = right - left;
    const int pageBottom = page.height() - 57;
    int y = 44;

    const QString brandName = Database::getSetting("settings.branding.name", QString::fromUtf8("CarServicePointG")).toString();
    const QString brandPhone = Database::getSetting("settings.branding.phone", QString::fromUtf8("0951425361")).toString();

    const QString plate = m_plate ? m_plate->text().trimmed() : QString();
    const QString car = m_car ? m_car->text().trimmed() : QString();
    const QString year = (m_year && m_year->value() > 0) ? QString::number(m_year->value()) : QString();
    const QString carDisplay = year.isEmpty() ? car : QString::fromUtf8("%1 (%2)").arg(car, year);
    const QString engine = m_engineCode ? m_engineCode->text().trimmed() : QString();
    QString engineVol = m_engineVolume ? m_engineVolume->text().trimmed() : QString();
    if (!engineVol.isEmpty() && !engineVol.contains(QString::fromUtf8("л"))) engineVol += QString::fromUtf8("л");
    const QString fuel = selectedFuelType();
    const QString color = m_color ? m_color->text().trimmed() : QString();
    const QString odometer = m_odometer ? QString::number(m_odometer->value()) : QString();
    const QString vin = m_vin ? m_vin->text().trimmed() : QString();
    const QString client = (m_client && !m_client->text().trimmed().isEmpty()) ? m_client->text().trimmed() : QString::fromUtf8("-");
    const QString master = m_master ? m_master->currentText() : QString();
    const QDateTime openedDt = m_opened ? m_opened->dateTime() : QDateTime();
    const QString opened = openedDt.isValid() ? openedDt.toString(QString::fromUtf8("dd.MM.yy HH:mm")) : QString();

    QString closedRaw;
    {
        QSqlQuery qClosed(Database::db());
        qClosed.prepare("SELECT COALESCE(closed_at,'') FROM work_orders WHERE number=?");
        qClosed.addBindValue(m_orderNumber);
        if (qClosed.exec() && qClosed.next()) closedRaw = qClosed.value(0).toString().trimmed();
    }
    QDateTime closedDt = QDateTime::fromString(closedRaw, Qt::ISODate);
    if (!closedDt.isValid()) closedDt = QDateTime::fromString(closedRaw, QStringLiteral("yyyy-MM-dd HH:mm:ss"));
    if (!closedDt.isValid()) closedDt = QDateTime::fromString(closedRaw, QStringLiteral("yyyy-MM-ddTHH:mm:ss"));
    if (!closedDt.isValid()) closedDt = QDateTime::fromString(closedRaw, QStringLiteral("dd.MM.yy HH:mm"));
    const QString closed = closedDt.isValid() ? closedDt.toString(QString::fromUtf8("dd.MM.yy HH:mm")) : QString();
    QString repairDuration = QString::fromUtf8("-");
    if (openedDt.isValid() && closedDt.isValid() && closedDt >= openedDt) {
        const qint64 totalMin = openedDt.secsTo(closedDt) / 60;
        const qint64 hh = totalMin / 60;
        const qint64 mm = totalMin % 60;
        repairDuration = QString::fromUtf8("%1:%2").arg(hh).arg(mm, 2, 10, QChar('0'));
    }

    auto money0 = [&](double v) { return QString::fromUtf8("%1 грн").arg(FormatUtils::money(v, 0)); };
    auto thinPen = [&](const QColor& c = QColor(138, 138, 138)) { return QPen(c, 0.5); };

    auto drawTextInRect = [&](const QRect& r, const QString& text, int pt, bool bold,
                              Qt::Alignment align = Qt::AlignLeft | Qt::AlignVCenter,
                              const QColor& color = QColor(24, 24, 24),
                              bool wordWrap = true,
                              const QString& family = QStringLiteral("Times New Roman")) {
        p.save();
        QFont f(family);
        f.setPointSize(pt);
        f.setBold(bold);
        p.setFont(f);
        p.setPen(color);
        int flags = int(align) | (wordWrap ? int(Qt::TextWordWrap) : 0);
        p.drawText(r, flags, text);
        p.restore();
    };

    auto drawBox = [&](const QRect& r, const QColor& fill = Qt::white, const QColor& border = QColor(150, 150, 150)) {
        p.save();
        p.setPen(thinPen(border));
        p.setBrush(fill);
        p.drawRect(r);
        p.restore();
    };

    auto elideToWidth = [&](const QString& text, int pt, bool bold, int maxWidth,
                            const QString& family = QStringLiteral("Times New Roman")) {
        QFont f(family);
        f.setPointSize(pt);
        f.setBold(bold);
        QFontMetrics fm(f);
        return fm.elidedText(text, Qt::ElideRight, maxWidth);
    };

    auto lineHeight = [&](int pt, bool bold, const QString& family = QStringLiteral("Times New Roman")) {
        QFont f(family);
        f.setPointSize(pt);
        f.setBold(bold);
        return QFontMetrics(f).height();
    };

    auto textRectHeight = [&](const QString& text, int pt, bool bold, int w,
                              const QString& family = QStringLiteral("Times New Roman")) {
        QFont f(family);
        f.setPointSize(pt);
        f.setBold(bold);
        QFontMetrics fm(f);
        return fm.boundingRect(QRect(0, 0, qMax(1, w), 3000), Qt::TextWordWrap, text).height();
    };

    auto ensurePageSpace = [&](int needed) {
        if (y + needed <= pageBottom - 90) return;
        pdf.newPage();
        p.setRenderHint(QPainter::Antialiasing, true);
        p.setRenderHint(QPainter::TextAntialiasing, true);
        y = 44;
    };

    auto drawSectionTitle = [&](const QString& title) {
        ensurePageSpace(40);
        drawTextInRect(QRect(left, y, width, 28), title, 18, true, Qt::AlignLeft | Qt::AlignVCenter,
                       QColor(18, 18, 18), false);
        p.save();
        p.setPen(thinPen(QColor(165, 165, 165)));
        p.drawLine(left, y + 30, right, y + 30);
        p.restore();
        y += 36;
    };

    struct TableCell {
        QString text;
        Qt::Alignment align = Qt::AlignLeft | Qt::AlignVCenter;
        QColor textColor = QColor(25, 25, 25);
    };


    auto scaledWidths = [&](const QVector<int>& baseWidths) {
        QVector<int> result;
        result.reserve(baseWidths.size());
        int baseSum = 0;
        for (int w : baseWidths) baseSum += w;
        if (baseSum <= 0) return baseWidths;
        int used = 0;
        for (int i = 0; i < baseWidths.size(); ++i) {
            int w = (i == baseWidths.size() - 1)
                        ? (width - used)
                        : qMax(40, int(qRound(double(baseWidths[i]) * double(width) / double(baseSum))));
            result.push_back(w);
            used += w;
        }
        if (!result.isEmpty()) result.last() += (width - used);
        return result;
    };
    auto drawTable = [&](const QVector<int>& colWidths,
                         const QStringList& headers,
                         const QVector<QVector<TableCell>>& rows) {
        ensurePageSpace(70);
        const int headerFontPt = 7;
        const int bodyFontPt = 9;
        int computedHeaderH = 34;
        for (int i = 0; i < colWidths.size() && i < headers.size(); ++i) {
            computedHeaderH = qMax(computedHeaderH, textRectHeight(headers[i], headerFontPt, true, colWidths[i] - 12) + 10);
        }
        const int headerH = computedHeaderH;
        int x = left;
        for (int i = 0; i < colWidths.size() && i < headers.size(); ++i) {
            p.save();
            p.setPen(thinPen(QColor(150, 150, 150)));
            p.setBrush(QColor(242, 242, 242));
            p.drawRect(QRect(x, y, colWidths[i], headerH));
            p.restore();
            drawTextInRect(QRect(x + 6, y + 3, colWidths[i] - 12, headerH - 6), headers[i], headerFontPt, true,
                           Qt::AlignCenter | Qt::AlignVCenter, QColor(28, 28, 28));
            x += colWidths[i];
        }
        y += headerH;

        for (int r = 0; r < rows.size(); ++r) {
            const auto& row = rows[r];
            int rowH = 24;
            for (int c = 0; c < row.size() && c < colWidths.size(); ++c) {
                rowH = qMax(rowH, textRectHeight(row[c].text, bodyFontPt, false, colWidths[c] - 12) + 8);
            }
            ensurePageSpace(rowH + 8);
            x = left;
            const QColor fill = (r % 2 == 0) ? QColor(255, 255, 255) : QColor(248, 248, 248);
            for (int c = 0; c < colWidths.size(); ++c) {
                p.save();
                p.setPen(thinPen(QColor(162, 162, 162)));
                p.setBrush(fill);
                p.drawRect(QRect(x, y, colWidths[c], rowH));
                p.restore();
                if (c < row.size()) {
                    drawTextInRect(QRect(x + 5, y + 2, colWidths[c] - 10, rowH - 4), row[c].text, bodyFontPt, false,
                                   row[c].align, row[c].textColor);
                }
                x += colWidths[c];
            }
            y += rowH;
        }
    };

    // Header
    {
        const int headerH = 152;
        drawBox(QRect(left, y, width, headerH), Qt::white, QColor(160, 160, 160));

        const int pad = 16;
        const int infoW = 387;
        const QRect logoRect(left + pad, y + 10, width - infoW - pad * 3, headerH - 20);
        const QRect infoRect(right - infoW - pad, y + 12, infoW, headerH - 24);
        drawBox(infoRect, QColor(252, 252, 252), QColor(165, 165, 165));

        drawTextInRect(QRect(logoRect.left(), logoRect.top() + 10, logoRect.width(), 28), brandName, 18, true,
                       Qt::AlignHCenter | Qt::AlignVCenter, QColor(18, 18, 18), false);
        drawTextInRect(QRect(logoRect.left(), logoRect.top() + 40, logoRect.width(), 30), QString::fromUtf8("НАРЯД-ЗАМОВЛЕННЯ"), 14, true,
                       Qt::AlignHCenter | Qt::AlignVCenter, QColor(26, 26, 26), false);
        drawTextInRect(QRect(logoRect.left(), logoRect.top() + 74, logoRect.width(), 18), QString::fromUtf8("Сервісний документ"), 9, false,
                       Qt::AlignHCenter | Qt::AlignVCenter, QColor(92, 92, 92), false, QStringLiteral("Arial"));

        const int labelX = infoRect.left() + 14;
        const int valueX = infoRect.left() + 132;
        const int rowH = 26;
        const int rowY = infoRect.top() + 8;
        drawTextInRect(QRect(labelX, rowY + rowH * 0, 110, rowH), QString::fromUtf8("№ наряду"), 10, true,
                       Qt::AlignLeft | Qt::AlignVCenter, QColor(70, 70, 70), false, QStringLiteral("Arial"));
        drawTextInRect(QRect(valueX, rowY + rowH * 0, infoRect.right() - valueX - 10, rowH), QString::number(m_orderNumber), 11, true,
                       Qt::AlignRight | Qt::AlignVCenter, QColor(18, 18, 18), false, QStringLiteral("Arial"));
        drawTextInRect(QRect(labelX, rowY + rowH * 1, 110, rowH), QString::fromUtf8("Дата"), 10, true,
                       Qt::AlignLeft | Qt::AlignTop, QColor(70, 70, 70), false, QStringLiteral("Arial"));
        const QString headerDateText = closed.isEmpty() ? opened : QString::fromUtf8("%1\n%2").arg(opened, closed);
        drawTextInRect(QRect(valueX, rowY + rowH * 1, infoRect.right() - valueX - 12, rowH * 2), headerDateText, 8, true,
                       Qt::AlignRight | Qt::AlignTop, QColor(18, 18, 18), true, QStringLiteral("Arial"));
        drawTextInRect(QRect(labelX, rowY + rowH * 3, 110, rowH), QString::fromUtf8("Тривалість"), 10, true,
                       Qt::AlignLeft | Qt::AlignVCenter, QColor(70, 70, 70), false, QStringLiteral("Arial"));
        drawTextInRect(QRect(valueX, rowY + rowH * 3, infoRect.right() - valueX - 12, rowH), repairDuration, 8, true,
                       Qt::AlignRight | Qt::AlignVCenter, QColor(18, 18, 18), false, QStringLiteral("Arial"));

        y += headerH + 12;
    }

    // Upper info block
    {
        struct InfoRow {
            QString label;
            QString value;
            int valuePt = 9;
            bool valueBold = false;
        };

        const int gap = 18;
        const int colW = (width - gap) / 2;
        const int leftLblW = 126;
        const int rightLblW = 138;
        const int valuePad = 6;
        const int titleH = 22;
        const int rowGap = 7;

        auto calcRowsHeight = [&](const QVector<InfoRow>& rows, int valueAreaWidth) {
            int totalH = 0;
            for (const auto& row : rows) {
                const int valueH = qMax(14, textRectHeight(row.value, row.valuePt, row.valueBold, valueAreaWidth));
                const int labelH = qMax(14, lineHeight(8, true, QStringLiteral("Arial")));
                totalH += qMax(valueH, labelH) + rowGap;
            }
            return totalH;
        };

        const QVector<InfoRow> leftRows = {
            {QString::fromUtf8("Номер авто:"), plate, 8, true},
            {QString::fromUtf8("Марка / модель:"), carDisplay, 8, true},
            {QString::fromUtf8("Двигун:"), engine, 8, false},
            {QString::fromUtf8("Об'єм:"), engineVol, 8, false},
            {QString::fromUtf8("Пальне:"), fuel, 8, false},
            {QString::fromUtf8("Колір:"), color, 8, false},
            {QString::fromUtf8("Одометр:"), odometer, 8, false}
        };
        const QVector<InfoRow> rightRows = {
            {QString::fromUtf8("Клієнт:"), client, 8, false},
            {QString::fromUtf8("Майстер:"), master, 8, false},
            {QString::fromUtf8("Дата відкриття:"), opened, 8, false},
            {QString::fromUtf8("VIN:"), vin, 8, true},
            {QString::fromUtf8("Роботи:"), money0(servicesTotal()), 8, false},
            {QString::fromUtf8("Запчастини:"), money0(partsTotal()), 8, false},
            {QString::fromUtf8("Разом:"), money0(servicesTotal() + partsTotal()), 8, false}
        };

        const int leftValueW = colW - 22 - leftLblW - valuePad;
        const int rightValueW = colW - 26 - rightLblW - valuePad;
        const int rowsHeight = qMax(calcRowsHeight(leftRows, leftValueW),
                                    calcRowsHeight(rightRows, rightValueW));
        const int blockH = qMax(235, titleH + 28 + rowsHeight + 32);

        const QRect block(left, y, width, blockH);
        drawBox(block, Qt::white, QColor(165, 165, 165));

        const QRect leftCol(left + 12, y + 10, colW - 18, blockH - 20);
        const QRect rightCol(left + colW + gap, y + 10, colW - 20, blockH - 20);

        drawTextInRect(QRect(leftCol.left(), leftCol.top(), leftCol.width(), titleH), QString::fromUtf8("Дані автомобіля"), 12, true,
                       Qt::AlignLeft | Qt::AlignVCenter, QColor(24, 24, 24), false);
        drawTextInRect(QRect(rightCol.left(), rightCol.top(), rightCol.width(), titleH), QString::fromUtf8("Дані клієнта / замовлення"), 12, true,
                       Qt::AlignLeft | Qt::AlignVCenter, QColor(24, 24, 24), false);

        p.save();
        p.setPen(thinPen(QColor(178, 178, 178)));
        p.drawLine(left + colW + gap / 2, y + 12, left + colW + gap / 2, y + blockH - 12);
        p.restore();

        auto drawInfoRows = [&](const QRect& col, const QVector<InfoRow>& rows, int lblW) {
            int yy = col.top() + titleH + 8;
            const int valueW = col.width() - lblW - valuePad;
            for (const auto& row : rows) {
                const int valueH = qMax(15, textRectHeight(row.value, row.valuePt, row.valueBold, valueW));
                const int rowH = qMax(valueH, lineHeight(8, true, QStringLiteral("Arial")) + 1);
                drawTextInRect(QRect(col.left(), yy, lblW, rowH), row.label, 8, true,
                               Qt::AlignLeft | Qt::AlignTop, QColor(70, 70, 70), false, QStringLiteral("Arial"));
                drawTextInRect(QRect(col.left() + lblW + valuePad, yy, valueW, rowH), row.value, row.valuePt, row.valueBold,
                               Qt::AlignLeft | Qt::AlignTop, QColor(20, 20, 20), true, QStringLiteral("Arial"));
                yy += rowH + rowGap;
            }
        };

        drawInfoRows(leftCol, leftRows, leftLblW);
        drawInfoRows(rightCol, rightRows, rightLblW);

        y += blockH + 12;
    }

    // Services data
    double worksTotal = 0.0;
    QVector<QVector<TableCell>> serviceRows;
    {
        QSqlQuery q(Database::db());
        q.prepare(
            "SELECT COALESCE(s.title,''), COALESCE(GROUP_CONCAT(COALESCE(NULLIF(m.name,''), NULLIF(sm.master_name_closed,'')), CHAR(10)), ''), "
            "COALESCE(s.qty,1), COALESCE(s.price,0) "
            "FROM work_order_services s "
            "LEFT JOIN service_masters sm ON sm.service_id=s.id "
            "LEFT JOIN masters m ON m.id=sm.master_id "
            "WHERE s.order_number=? "
            "GROUP BY s.id, s.title, s.qty, s.price "
            "ORDER BY s.id");
        q.addBindValue(m_orderNumber);
        if (q.exec()) {
            while (q.next()) {
                const QString title = q.value(0).toString().trimmed();
                if (title.isEmpty()) continue;
                const QString masters = q.value(1).toString().trimmed().isEmpty() ? master : q.value(1).toString().trimmed();
                const double qty = q.value(2).toDouble();
                const double price = q.value(3).toDouble();
                const double amount = qty * price;
                worksTotal += amount;
                serviceRows.push_back({
                    {title, Qt::AlignLeft | Qt::AlignVCenter},
                    {masters, Qt::AlignLeft | Qt::AlignVCenter},
                    {FormatUtils::money(price, 0), Qt::AlignCenter | Qt::AlignVCenter},
                    {FormatUtils::money(amount, 0), Qt::AlignCenter | Qt::AlignVCenter},
                    {QString::fromUtf8("Так"), Qt::AlignCenter | Qt::AlignVCenter}
                });
            }
        }
    }

    drawSectionTitle(QString::fromUtf8("Роботи"));
    drawTable(scaledWidths({690, 220, 135, 135, 95}),
              {QString::fromUtf8("Назва"), QString::fromUtf8("Майстри"),
               QString::fromUtf8("Ціна\n(грн)"), QString::fromUtf8("Сума\n(грн)"), QString::fromUtf8("Оплата")},
              serviceRows);

    y += 10;

    // Parts data
    double partsTotalVal = 0.0;
    QVector<QVector<TableCell>> partRows;
    {
        QSqlQuery q(Database::db());
        q.prepare("SELECT COALESCE(store,''), COALESCE(part_number,''), COALESCE(name,''), COALESCE(qty,1), COALESCE(price,0), COALESCE(amount,0), COALESCE(paid,0) FROM work_order_parts WHERE order_number=? ORDER BY id");
        q.addBindValue(m_orderNumber);
        if (q.exec()) {
            while (q.next()) {
                const QString name = q.value(2).toString().trimmed();
                if (name.isEmpty()) continue;
                const QString store = q.value(0).toString().trimmed();
                const QString partNo = q.value(1).toString().trimmed();
                const double qty = q.value(3).toDouble();
                const double price = q.value(4).toDouble();
                const double amount = q.value(5).toDouble();
                const bool paid = q.value(6).toInt() != 0;
                partsTotalVal += amount;
                partRows.push_back({
                    {store, Qt::AlignLeft | Qt::AlignVCenter},
                    {partNo, Qt::AlignLeft | Qt::AlignVCenter},
                    {name, Qt::AlignLeft | Qt::AlignVCenter},
                    {QString::number(qty, 'f', 1), Qt::AlignCenter | Qt::AlignVCenter},
                    {FormatUtils::money(price, 0), Qt::AlignCenter | Qt::AlignVCenter},
                    {FormatUtils::money(amount, 0), Qt::AlignCenter | Qt::AlignVCenter},
                    {paid ? QString::fromUtf8("Так") : QString::fromUtf8("Ні"), Qt::AlignCenter | Qt::AlignVCenter, paid ? QColor(25,25,25) : QColor(215, 55, 35)}
                });
            }
        }
    }

    drawSectionTitle(QString::fromUtf8("Запчастини"));
    drawTable(scaledWidths({180, 150, 520, 80, 95, 105, 90}),
              {QString::fromUtf8("Магазин"), QString::fromUtf8("ОЕМ"), QString::fromUtf8("Назва"),
               QString::fromUtf8("Кіл-ть"), QString::fromUtf8("Ціна\n(грн)"), QString::fromUtf8("Сума\n(грн)"), QString::fromUtf8("Оплата")},
              partRows);


    y += 18;

    // Summary block
    const double total = worksTotal + partsTotalVal;
    const int summaryW = 385;
    const int summaryH = 181;
    const QRect summaryRect(right - summaryW, y, summaryW, summaryH);
    drawBox(summaryRect, QColor(252, 252, 252), QColor(158, 158, 158));
    auto drawSummaryRow = [&](int rowIndex, const QString& label, const QString& value, bool bold = false, int pt = 13) {
        const int rowY = summaryRect.top() + 18 + rowIndex * 42;
        drawTextInRect(QRect(summaryRect.left() + 18, rowY, 210, 28), label, pt, bold,
                       Qt::AlignLeft | Qt::AlignVCenter, QColor(35, 35, 35), false, QStringLiteral("Arial"));
        drawTextInRect(QRect(summaryRect.right() - 170, rowY, 150, 28), value, pt, bold,
                       Qt::AlignRight | Qt::AlignVCenter, QColor(18, 18, 18), false, QStringLiteral("Arial"));
    };
    drawSummaryRow(0, QString::fromUtf8("Роботи"), FormatUtils::money(worksTotal, 0));
    drawSummaryRow(1, QString::fromUtf8("Запчастини"), FormatUtils::money(partsTotalVal, 0));
    p.save();
    p.setPen(thinPen(QColor(178, 178, 178)));
    p.drawLine(summaryRect.left() + 18, summaryRect.top() + 106, summaryRect.right() - 18, summaryRect.top() + 106);
    p.restore();
    drawSummaryRow(2, QString::fromUtf8("РАЗОМ"), FormatUtils::money(total, 0), true, 13);

    y += summaryH + 42;

    // Signatures
    const int signY = qMin(y, pageBottom - 70);
    const int signW = 300;
    const int leftSignX = left + 8;
    const int rightSignX = right - signW - 8;
    p.save();
    p.setPen(thinPen(QColor(145, 145, 145)));
    p.drawLine(leftSignX, signY, leftSignX + signW, signY);
    p.drawLine(rightSignX, signY, rightSignX + signW, signY);
    p.restore();
    drawTextInRect(QRect(leftSignX, signY + 6, signW, 20), QString::fromUtf8("Майстер / відповідальна особа"), 9, false,
                   Qt::AlignHCenter | Qt::AlignTop, QColor(85, 85, 85), false, QStringLiteral("Arial"));
    drawTextInRect(QRect(rightSignX, signY + 6, signW, 20), QString::fromUtf8("Клієнт"), 9, false,
                   Qt::AlignHCenter | Qt::AlignTop, QColor(85, 85, 85), false, QStringLiteral("Arial"));

    if (!brandPhone.trimmed().isEmpty()) {
        drawTextInRect(QRect(left, pageBottom - 18, width, 16), QString::fromUtf8("Контактний номер: %1").arg(brandPhone), 9, false,
                       Qt::AlignLeft | Qt::AlignVCenter, QColor(110, 110, 110), false, QStringLiteral("Arial"));
    }

    p.end();
}

void OrderDialog::accept()
{
    int number = m_num ? m_num->value() : m_orderNumber;

    const double worksSum = servicesTotal();
    const double partsSum = partsTotal();
    const double discount = m_discount ? m_discount->value() : 0.0;

    const QDateTime opened = m_opened ? m_opened->dateTime() : QDateTime::currentDateTime();
    const QString status = m_status ? m_status->currentText() : QStringLiteral("open");

    QString plate = m_plate ? m_plate->text().trimmed() : QString();
    QString vin = m_vin ? m_vin->text().trimmed() : QString();
    QString car = m_car ? m_car->text().trimmed() : QString();
    QString color = m_color ? m_color->text().trimmed() : QString();
    const int carYear = m_year ? m_year->value() : 0;
    const int odometer = m_odometer ? m_odometer->value() : 0;
    const QString engineType = m_engineCode ? m_engineCode->text().trimmed() : QString();
    const QString engineVolume = m_engineVolume ? m_engineVolume->text().trimmed() : QString();
    const QString fuelType = selectedFuelType();
    QString client = m_client ? m_client->text().trimmed() : QString();
    const QString phone = m_phone ? m_phone->text().trimmed() : QString();
    const QString masterId = m_master ? m_master->currentData().toString() : QString();

    const QStringList missing = collectMissingRequiredOrderFields(m_plate, m_vin, m_odometer, m_opened);
    if (!missing.isEmpty()) {
        QMessageBox::warning(this,
                             QString::fromUtf8("Обов'язкові поля не заповнені"),
                             requiredFieldsWarning(missing));
        if (m_tabs) m_tabs->setCurrentIndex(0);
        if (m_plate && m_plate->text().trimmed().isEmpty()) m_plate->setFocus();
        else if (m_vin && m_vin->text().trimmed().isEmpty()) m_vin->setFocus();
        else if (m_odometer && m_odometer->value() <= 0) m_odometer->setFocus();
        else if (m_opened) m_opened->setFocus();
        return;
    }

    if (masterId.trimmed().isEmpty()) {
        QMessageBox::warning(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Оберіть майстра"));
        return;
    }

    QSqlDatabase db = Database::db();
    if (!db.transaction()) {
        QMessageBox::critical(this, QString::fromUtf8("Помилка"), QString::fromUtf8("Не можу відкрити транзакцію БД"));
        return;
    }

    if (number <= 0) {
        QSqlQuery qn(db);
        if (!qn.exec("SELECT COALESCE(MAX(number),0) + 1 FROM work_orders")) {
            db.rollback();
            QMessageBox::critical(this, QString::fromUtf8("Помилка БД"), qn.lastError().text());
            return;
        }
        if (qn.next()) number = qn.value(0).toInt();
        if (m_num) m_num->setValue(number);
    }

    const QString plateNorm = PlateUtils::normalizePlate(plate);
    plate = PlateUtils::formatPlateDisplay(plateNorm);
    vin = vin.trimmed().toUpper();
    car = titleCaseWords(car);
    color = capitalizeSentence(color);
    client = titleCaseWords(client);
    if (plate.isNull()) plate = QStringLiteral("");
    if (car.isNull()) car = QStringLiteral("");
    if (client.isNull()) client = QStringLiteral("");

    bool isNew = true;
    {
        QSqlQuery chk(db);
        chk.prepare("SELECT 1 FROM work_orders WHERE number=? LIMIT 1");
        chk.addBindValue(number);
        if (chk.exec() && chk.next()) isNew = false;
    }

    QSqlQuery q(db);
    if (isNew) {
        q.prepare("INSERT INTO work_orders(number, opened_at, status, plate, plate_norm, vin, car, color, car_year, odometer, engine_type, engine_volume, fuel_type, client, client_phone, master_id, works_sum, parts_sum, discount) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        q.addBindValue(number);
        q.addBindValue(opened.toString(Qt::ISODate));
        q.addBindValue(status);
        q.addBindValue(plate);
        q.addBindValue(plateNorm);
        q.addBindValue(vin);
        q.addBindValue(car);
        q.addBindValue(color);
        q.addBindValue(carYear);
        q.addBindValue(odometer);
        q.addBindValue(engineType);
        q.addBindValue(engineVolume);
        q.addBindValue(fuelType);
        q.addBindValue(client);
        q.addBindValue(phone);
        q.addBindValue(masterId);
        q.addBindValue(worksSum);
        q.addBindValue(partsSum);
        q.addBindValue(discount);
    } else {
        q.prepare("UPDATE work_orders SET opened_at=?, status=?, plate=?, plate_norm=?, vin=?, car=?, color=?, car_year=?, odometer=?, engine_type=?, engine_volume=?, fuel_type=?, client=?, client_phone=?, master_id=?, works_sum=?, parts_sum=?, discount=? WHERE number=?");
        q.addBindValue(opened.toString(Qt::ISODate));
        q.addBindValue(status);
        q.addBindValue(plate);
        q.addBindValue(plateNorm);
        q.addBindValue(vin);
        q.addBindValue(car);
        q.addBindValue(color);
        q.addBindValue(carYear);
        q.addBindValue(odometer);
        q.addBindValue(engineType);
        q.addBindValue(engineVolume);
        q.addBindValue(fuelType);
        q.addBindValue(client);
        q.addBindValue(phone);
        q.addBindValue(masterId);
        q.addBindValue(worksSum);
        q.addBindValue(partsSum);
        q.addBindValue(discount);
        q.addBindValue(number);
    }

    if (!q.exec()) {
        db.rollback();
        QMessageBox::critical(this, QString::fromUtf8("Помилка БД"), q.lastError().text());
        return;
    }

    if (!db.commit()) {
        db.rollback();
        QMessageBox::critical(this, QString::fromUtf8("Помилка БД"), QString::fromUtf8("Commit не вдався"));
        return;
    }

    m_orderNumber = number;
    m_draftCreated = false;
    refreshTotals();

    if (m_isNewOrder) {
        QWidget* parentForEdit = parentWidget();
        const int createdOrderNumber = m_orderNumber;
        QTimer::singleShot(0, parentForEdit, [parentForEdit, createdOrderNumber]() {
            auto* detailDlg = new OrderDialog(parentForEdit, createdOrderNumber);
            detailDlg->setAttribute(Qt::WA_DeleteOnClose, true);
            detailDlg->setWindowTitle(QString::fromUtf8("Редагування наряду"));
            detailDlg->openWorkPartsTab();
            detailDlg->open();
        });
    }

    QDialog::accept();
}

