#include "ui/common/widgets/GlossyButton.h"

#include <QPainter>
#include <QStyleOptionButton>
#include <QStylePainter>
#include <QLinearGradient>
#include <QPainterPath>

GlossyButton::GlossyButton(const QString& text, QWidget* parent)
    : QPushButton(text, parent),
      m_textColor(245,245,245),
      m_outlineColor(25,25,25)
{
    setCursor(Qt::PointingHandCursor);
    setMinimumHeight(36);
    setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
    setFocusPolicy(Qt::StrongFocus);
}

void GlossyButton::paintEvent(QPaintEvent* e)
{
    Q_UNUSED(e);

    QStyleOptionButton opt;
    initStyleOption(&opt);
    const QString text = opt.text;
    opt.text.clear();

    QStylePainter p(this);

    // Background gradient
    QRect r = rect();
    QLinearGradient g(r.topLeft(), r.bottomLeft());
    if (isDown() || (opt.state & QStyle::State_Sunken)) {
        g.setColorAt(0.0, QColor(55,55,55));
        g.setColorAt(1.0, QColor(25,25,25));
    } else if (underMouse() || (opt.state & QStyle::State_MouseOver)) {
        g.setColorAt(0.0, QColor(95,95,95));
        g.setColorAt(1.0, QColor(45,45,45));
    } else {
        g.setColorAt(0.0, QColor(75,75,75));
        g.setColorAt(1.0, QColor(35,35,35));
    }

    p.setRenderHint(QPainter::Antialiasing, true);
    p.setPen(Qt::NoPen);
    p.setBrush(g);
    p.drawRoundedRect(r.adjusted(1,1,-1,-1), 10, 10);

    // Subtle highlight at top
    QLinearGradient hi(r.topLeft(), QPointF(r.left(), r.center().y()));
    hi.setColorAt(0.0, QColor(255,255,255,70));
    hi.setColorAt(1.0, QColor(255,255,255,0));
    p.setBrush(hi);
    p.drawRoundedRect(r.adjusted(2,2,-2,-2), 9, 9);

    // Border
    p.setBrush(Qt::NoBrush);
    p.setPen(QPen(QColor(0,0,0,120), 1));
    p.drawRoundedRect(r.adjusted(1,1,-1,-1), 10, 10);

    // Text (outlined)
    if (!text.isEmpty()) {
        QFont f = font();
        f.setBold(true);
        p.setFont(f);

        QPainterPath path;
        QRect tr = r.adjusted(10, 0, -10, 0);
        QPoint center = tr.center();

        QFontMetrics fm(f);
        int w = fm.horizontalAdvance(text);
        int h = fm.height();
        QPoint pos(center.x() - w/2, center.y() + h/4);

        path.addText(pos, f, text);
        p.setPen(QPen(m_outlineColor, 3, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        p.setBrush(Qt::NoBrush);
        p.drawPath(path);
        p.setPen(Qt::NoPen);
        p.setBrush(m_textColor);
        p.drawPath(path);
    }
}
