#pragma once

#include <QPushButton>
#include <QColor>

class GlossyButton : public QPushButton
{
    Q_OBJECT
public:
    explicit GlossyButton(const QString& text, QWidget* parent=nullptr);

protected:
    void paintEvent(QPaintEvent* e) override;

private:
    QColor m_textColor;
    QColor m_outlineColor;
};
