#include "ui/common/widgets/UnpaidBannerWidget.h"

#include <QPainter>
#include <QLinearGradient>
#include <QPainterPath>

UnpaidBannerWidget::UnpaidBannerWidget(QWidget* parent)
    : QWidget(parent)
{
    setMinimumHeight(120);
    setMaximumHeight(140);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);

    m_logo.load(":/assets/logo.jpg");
}

void UnpaidBannerWidget::setDebt(bool hasDebt, const QString& qtyText, const QString& sumText)
{
    m_hasDebt = hasDebt;
    m_qty = qtyText;
    m_sum = sumText;
    update();
}

void UnpaidBannerWidget::paintEvent(QPaintEvent* e)
{
    Q_UNUSED(e);

    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);

    QRect r = rect().adjusted(1,1,-1,-1);

    QLinearGradient g(r.topLeft(), r.bottomLeft());
    if (m_hasDebt) {
        g.setColorAt(0.0, QColor(140, 20, 20));
        g.setColorAt(1.0, QColor(60, 10, 10));
    } else {
        g.setColorAt(0.0, QColor(90, 90, 90));
        g.setColorAt(1.0, QColor(35, 35, 35));
    }

    p.setPen(QPen(QColor(0,0,0,140), 1));
    p.setBrush(g);
    p.drawRoundedRect(r, 14, 14);

    // Logo
    if (!m_logo.isNull()) {
        QRect lr = r.adjusted(10, 10, -10, -55);
        QSize target = QSize(lr.width(), lr.height());
        QPixmap scaled = m_logo.scaled(target, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        QPoint pos(lr.center().x() - scaled.width()/2, lr.center().y() - scaled.height()/2);
        p.drawPixmap(pos, scaled);
    }

    // Bottom text
    p.setPen(QColor(245,245,245));
    QFont f = font();
    f.setBold(true);
    f.setPointSize(10);
    p.setFont(f);

    QRect tr = r.adjusted(12, r.height()-46, -12, -10);
    QString t;
    if (m_hasDebt) {
        t = QString::fromUtf8("НЕ СПЛАЧЕНО\nЗапчастин: %1\nСума: %2 грн")
                .arg(m_qty, m_sum);
    } else {
        t = QStringLiteral("CarServicePointG");
    }
    p.drawText(tr, m_hasDebt ? (Qt::AlignLeft | Qt::AlignVCenter | Qt::TextWordWrap) : (Qt::AlignHCenter | Qt::AlignVCenter), t);
}
