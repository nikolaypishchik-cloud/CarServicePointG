#pragma once

#include <QWidget>
#include <QPixmap>

class UnpaidBannerWidget : public QWidget
{
    Q_OBJECT
public:
    explicit UnpaidBannerWidget(QWidget* parent=nullptr);

    void setDebt(bool hasDebt, const QString& qtyText, const QString& sumText);

protected:
    void paintEvent(QPaintEvent* e) override;

private:
    QPixmap m_logo;
    bool m_hasDebt = false;
    QString m_qty;
    QString m_sum;
};
