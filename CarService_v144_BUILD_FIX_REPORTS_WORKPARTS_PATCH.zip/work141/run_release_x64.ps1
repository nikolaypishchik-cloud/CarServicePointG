# CarService: build + deploy + run (MSVC x64, Qt)
$ErrorActionPreference = "Stop"

$qt    = "C:\Qt\6.10.2\msvc2022_64"
$vsDev = "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path (Join-Path $root "CMakeLists.txt"))) { throw "CMakeLists.txt not found рядом зі скриптом: $root" }
if (-not (Test-Path $qt)) { throw "Qt not found: $qt" }
if (-not (Test-Path $vsDev)) { throw "VsDevCmd.bat not found: $vsDev" }

cmd /c "`"$vsDev`" -arch=amd64 -host_arch=amd64 && set" | ForEach-Object {
  if ($_ -match "^(.*?)=(.*)$") { Set-Item -Path "Env:$($matches[1])" -Value $matches[2] }
}

$vcTools = Join-Path (Split-Path -Parent $vsDev) "..\..\VC\Tools\MSVC"
$vcBin = Get-ChildItem -Path $vcTools -Directory -ErrorAction SilentlyContinue |
  Sort-Object Name -Descending |
  ForEach-Object { Join-Path $_.FullName "bin\Hostx64\x64" } |
  Where-Object { Test-Path $_ } |
  Select-Object -First 1
if ($vcBin) { $env:PATH = "$vcBin;$env:PATH" }

Write-Host "cl = $((where.exe cl)[0])"
Set-Location $root
if (Test-Path build) { Remove-Item -Recurse -Force build }

$logDir = Join-Path $env:APPDATA "CarServicePointG\CarServicePointG\logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$buildLog = Join-Path $logDir ("build_" + (Get-Date -Format "yyyy-MM-dd_HH-mm-ss") + ".log")
$runLog   = Join-Path $logDir ("run_"   + (Get-Date -Format "yyyy-MM-dd_HH-mm-ss") + ".log")

"=== CONFIGURE $(Get-Date) ===" | Tee-Object -FilePath $buildLog | Out-Null
cmake -S . -B build -G "Ninja" -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$qt" *>&1 | Tee-Object -FilePath $buildLog -Append
if ($LASTEXITCODE -ne 0) { throw "CMake configure failed. Build log: $buildLog" }

"=== BUILD $(Get-Date) ===" | Tee-Object -FilePath $buildLog -Append | Out-Null
cmake --build build *>&1 | Tee-Object -FilePath $buildLog -Append
if ($LASTEXITCODE -ne 0) {
  Write-Host "Build failed. Full build log: $buildLog"
  throw "Build failed before CarService.exe creation"
}

$exeCandidates = @(
  (Join-Path $root "build\CarService.exe"),
  (Join-Path $root "build\Release\CarService.exe"),
  (Join-Path $root "build\bin\CarService.exe")
)
$exe = $exeCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $exe) {
  Write-Host "Build log: $buildLog"
  throw "CarService.exe not found in build, build\Release or build\bin"
}

& "$qt\bin\windeployqt.exe" --release --no-translations $exe *>&1 | Tee-Object -FilePath $buildLog -Append | Out-Null

"=== RUN $(Get-Date) ===" | Tee-Object -FilePath $runLog | Out-Null
& $exe *>&1 | Tee-Object -FilePath $runLog -Append
"ExitCode: $LASTEXITCODE" | Tee-Object -FilePath $runLog -Append
Write-Host "Build log: $buildLog"
Write-Host "Run log: $runLog"
